/*
 *				GemSight: Messages Text management 
 *				
 *	Author  : FunShip
 *	File	: Messages.C
 *	Date    : 29 June 1995
 *	Revision: 27 Juillet 1995
 *	Version : 1.0
 *
 *	
 */

#include <stdio.h>

#include "F:\Aads.030\Include\PcAads.h"

#include "GsDef.h"

/*
 *	From GemSight.C
 */
 
extern	int	Suivante;
extern	char	Tampon[NBLINE][NBCOL];
extern	int 	TargetWindow,TargetOwner;
extern	int	WHandle;

/*
 *	Texts for standards messages received by GemSight
 */

#define	NBMESSAGE	90
#define	SUBARROWED	8
#define	LGTEXTE		200
 
static 	char	MessagList[NBMESSAGE+1][LGTEXTE]
		={"",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "MN_SELECTED by Sender: %d Menu Title %d  Entry selected %d",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "WM_REDRAW   by Sender: %d Window %d  x=%d y=%d w=%d h=%d",
		  "WM_TOPPED   by Sender: %d Window %d",
		  "WM_CLOSED   by Sender: %d Window %d",
		  "WM_FULLED   by Sender: %d Window %d",
		  "WM_ARROWED  by Sender: %d Window %d Action %s",
		  "WM_HSLID    by Sender: %d Window %d New position %d",
		  "WM_VSLID    by Sender: %d Window %d New position %d",
		  "WM_SIZED    by Sender: %d Window %d  x=%d y=%d w=%d h=%d",
		  "WM_MOVED    by Sender: %d Window %d  x=%d y=%d w=%d h=%d",
		  "",
		  "WM_UNTOPPED by Sender: %d Window %d",
		  "WM_ONTOP    by Sender: %d Window %d",
		  "",
		  "WM_BOTTOM   by Sender: %d Window %d",
		  "WM_ICONIFY  by Sender: %d Window %d x=%d y=%d w=%d h=%d",
		  "WM_UNICONIFY  by Sender: %d Window %d x=%d y=%d w=%d h=%d",
		  "WM_ALLICONIFY by Sender: %d Window %d x=%d y=%d w=%d h=%d",
		  "WM_TOOLBAR  by Sender: %d Window %d Object %d Number of clicks %d Shift state %d",
		  "",
		  "",
		  "AC_OPEN     by Sender: %d Accessory Aes Pid=%d",
		  "AC_CLOSE    by Sender: %d Accessory Aes Pid=%d",
		  "",
		  "",
		  "",
		  "",
		  "",
 		  "",
		  "",
		  "",
		  "AP_TERM     by Sender: %d Reason=%d",
		  "AP_TFAIL    Error Code %d",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "AP_RESCHG   by Sender: %d",
		  "",
		  "",
		  "SHUT_COMPLETED  by Sender: %d",
		  "RESCH_COMPLETED by Sender: %d Error code: %d",
		  "",
		  "AP_DRAGDROP by Sender: %d  Window %d  x=%d y=%d Shift State=%d Pipe=0x%X",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "SH_WDRAW    by Sender: %d Drive Number: %d",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "CH_EXIT     by Sender: %d Child identifier: %d Exit Code: %d"
		 };

/*
 *	Texts for patched messages received by GemSight form AES patch code
 */
 
static 	char	PatchList[NBMESSAGE+1][LGTEXTE]
		={"",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "MN_SELECTED PID sender %d to PID %d Menu Title %d  Entry selected %d",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "WM_REDRAW   PID sender %d to PID %d Window %d  x=%d y=%d w=%d h=%d",
		  "WM_TOPPED   PID sender %d to PID %d Window %d",
		  "WM_CLOSED   PID sender %d to PID %d Window %d",
		  "WM_FULLED   PID sender %d to PID %d Window %d",
		  "WM_ARROWED  PID sender %d to PID %d Window %d  Action %s",
		  "WM_HSLID    PID sender %d to PID %d Window %d New position %d",
		  "WM_VSLID    PID sender %d to PID %d Window %d New position %d",
		  "WM_SIZED    PID sender %d to PID %d Window %d  x=%d y=%d w=%d h=%d",
		  "WM_MOVED    PID sender %d to PID %d Window %d  x=%d y=%d w=%d h=%d",
		  "",
		  "WM_UNTOPPED PID sender %d to PID %d Window %d",
		  "WM_ONTOP    PID sender %d to PID %d Window %d",
		  "",
		  "WM_BOTTOM   PID sender %d to PID %d Window %d",
		  "WM_ICONIFY  PID sender %d to PID %d Window %d x=%d y=%d w=%d h=%d",
		  "WM_UNICONIFY  PID sender %d to PID %d Window %d x=%d y=%d w=%d h=%d",
		  "WM_ALLICONIFY PID sender %d to PID %d Window %d x=%d y=%d w=%d h=%d",
		  "WM_TOOLBAR  PID sender %d to PID %d Window %d Object %d Number of clicks %d Shift state %d",
		  "",
		  "",
		  "AC_OPEN     PID sender %d to PID %d Accessory Aes Pid=%d",
		  "AC_CLOSE    PID sender %d to PID %d Accessory Aes Pid=%d",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "AP_TERM     PID sender %d to PID %d Reason=%d",
		  "AP_TFAIL    Error Code %d to PID %d",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "AP_RESCHG   PID sender %d to PID %d",
		  "",
		  "",
		  "SHUT_COMPLETED  PID sender %d to PID %d",
		  "RESCH_COMPLETED PID sender %d to PID %d Error Code %d",
		  "",
		  "AP_DRAGDROP PID sender %d to PID %d Window %d  x=%d y=%d Shift State %d Pipe 0x%X",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "SH_WDRAW    PID sender %d to PID %d Drive Number %d",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "",
		  "CH_EXIT     PID sender %d to PID %d Child Identifier %d  Exit Code %d"
		 };

/*
 *	Sub-Messages for Arrowed Main Messages
 */

static 	char	ArrowedList[SUBARROWED][LGTEXTE]
		={"WA_UPPAGE",
		  "WA_DNPAGE",
		  "WA_UPLINE",
		  "WA_DNLINE",
		  "WA_LFPAGE",
		  "WA_RTPAGE",
		  "WA_LFLINE",
		  "WA_RTLINE"
		 };

/*
 * ---------------------------------------------------------------------------------------
 *				Miscallenous Procedures
 */

int	IsKnowMessage(int MessageType)
/*
	Return True if Message's type is knowing else False
*/
{
  switch(MessageType)
  {
   	case   MN_SELECTED:
	case   WM_REDRAW :
	case   WM_TOPPED:
	case   WM_CLOSED:
	case   WM_FULLED:
	case   WM_ARROWED:
	case   WM_HSLID:
	case   WM_VSLID:
	case   WM_SIZED:
	case   WM_MOVED:  
	case   WM_UNTOPPED:
	case   WM_ONTOP:
	case   WM_BOTTOMED:
	case   WM_ICONIFY:
	case   WM_UNICONIFY:
	case   WM_ALLICONIFY:
	case   WM_TOOLBAR:
	case   AC_OPEN:   
	case   AC_CLOSE:  
	case   AP_TERM:
	case   AP_TFAIL:
	case   AP_RESCHG:
	case   SHUT_COMPLETED:
	case   RESCHG_COMPLETED:
	case   AP_DRAGDROP:
	case   SH_WDRAW:
	case   CH_EXIT:
				return(TRUE);
	default:
				return(FALSE);

  }
}

/*
 * ---------------------------------------------------------------------------------------
 *				Write Messages Text Procedures
 */

void PtchWrite(void)
/*
	Writing a patched message in text with its parameters into display window
	(value A_Message[2] always contains the PID of Receiver Application,
	 inserted by the AesPatch)

	Input:	Use Global array A_Message
	Output:	Window Display text buffer receive one more text line
*/
{
  switch(A_Message[0] & (~FlagGS))			/* Selon le message re�u */
  {
	/*	
	 *	Affiche A_Message[0..7] 
	 */
	case   WM_SIZED:
	case   WM_MOVED:  
	case   WM_ICONIFY:
	case   WM_UNICONIFY:
	case   WM_ALLICONIFY:
	case   WM_REDRAW :	
	case   AP_DRAGDROP:
			sprintf(Tampon[Suivante++],
				PatchList[A_Message[0] & (~FlagGS)],
	              		A_Message[1],A_Message[2],A_Message[3],
				A_Message[4],A_Message[5],A_Message[6],
				A_Message[7]);
			break;
	/*
	 *	Affiche A_Message[0..6] 
	 */
	case   WM_TOOLBAR:
			sprintf(Tampon[Suivante++],
				PatchList[A_Message[0] & (~FlagGS)],
		        	A_Message[1],A_Message[2],A_Message[3],
				A_Message[4],A_Message[5],A_Message[6]);
			break;
	/*
	 *	Affiche A_Message[0..4] 
	 */
	
   	case   MN_SELECTED:	
	case   WM_HSLID:
	case   WM_VSLID:
	case   CH_EXIT:
			sprintf(Tampon[Suivante++],
				PatchList[A_Message[0] & (~FlagGS)],
		          	A_Message[1],A_Message[2],A_Message[3],
				A_Message[4]);
			break;
	/*
	 *	Affiche A_Message[0..3] 
	 */
	case   WM_TOPPED:	
	case   WM_CLOSED:
	case   WM_FULLED:
	case   WM_UNTOPPED:
	case   WM_ONTOP:
	case   WM_BOTTOMED:
	case   AC_CLOSE:  
	case   RESCHG_COMPLETED:
	case   SH_WDRAW:
			sprintf(Tampon[Suivante++],
				PatchList[A_Message[0] & (~FlagGS)],
		        	A_Message[1],A_Message[2],A_Message[3]);
			break;
	/*
	 *	Affiche A_Message[0..2] 
	 */
	case   AP_TFAIL:
	case   AP_RESCHG:
	case   SHUT_COMPLETED:
			sprintf(Tampon[Suivante++],
				PatchList[A_Message[0] & (~FlagGS)],
		        	A_Message[1],A_Message[2]);
			break;
	/*	
	 *	Affiche A_Message[0,1,2,4] 
	 */
	case   AC_OPEN:   
			sprintf(Tampon[Suivante++],
				PatchList[A_Message[0] & (~FlagGS)],
		          	A_Message[1],A_Message[2],A_Message[4]);
			break;
	/*	
	 *	Affiche A_Message[0,1,2,5] 
	 */
	case   AP_TERM:  
			sprintf(Tampon[Suivante++],
				PatchList[A_Message[0] & (~FlagGS)],
		           	A_Message[1],A_Message[2],A_Message[5]);
			break;
	/*
	 *	Affiche A_Message[0..3] et A_Message[4] de ArrowedList
	 */
	case   WM_ARROWED:
			sprintf(Tampon[Suivante++],
				PatchList[A_Message[0] & (~FlagGS)],
		          	A_Message[1],A_Message[2],A_Message[3],
				ArrowedList[A_Message[4]]);
			break;
	/*	
	 *	Unknow Message: return
	 */
	default:	break;
  }  
  W_Printf(WHandle,Tampon[Suivante-1]);
}

void StdWrite(void)
/*
	Writing a standart message in text with its parameters into display window
	(Value A_Message[2] is never writing because always equal to zero, 
	in standard system messages)

	Input:	Use Global array A_Message
	Output:	Window Display text buffer receive one more text line
*/
{
  switch(A_Message[0])				/* Selon le message re�u */
  {
	/*	
	 *	Affiche A_Message[0..7] 
	 */
	case   WM_SIZED:
	case   WM_MOVED:  
	case   WM_ICONIFY:
	case   WM_UNICONIFY:
	case   WM_ALLICONIFY:
	case   WM_REDRAW :	
	case   AP_DRAGDROP:
			sprintf(Tampon[Suivante++],
				MessagList[A_Message[0]],
	              		A_Message[1],A_Message[3],
				A_Message[4],A_Message[5],A_Message[6],
				A_Message[7]);
			break;
	/*
	 *	Affiche A_Message[0..6] 
	 */
	case   WM_TOOLBAR:
			sprintf(Tampon[Suivante++],
				MessagList[A_Message[0]],
		        	A_Message[1],A_Message[3],
				A_Message[4],A_Message[5],A_Message[6]);
			break;
	/*
	 *	Affiche A_Message[0..4] 
	 */
   	case   MN_SELECTED:	
	case   WM_HSLID:
	case   WM_VSLID:
	case   CH_EXIT:
			sprintf(Tampon[Suivante++],
				MessagList[A_Message[0]],
		          	A_Message[1],A_Message[3],
				A_Message[4]);
			break;
	/*
	 *	Affiche A_Message[0..3] 
	 */
	case   WM_TOPPED:	
	case   WM_CLOSED:
	case   WM_FULLED:
	case   WM_UNTOPPED:
	case   WM_ONTOP:
	case   WM_BOTTOMED:
	case   AC_CLOSE:  
	case   RESCHG_COMPLETED:
	case   SH_WDRAW:
			sprintf(Tampon[Suivante++],
				MessagList[A_Message[0]],
		        	A_Message[1],A_Message[3]);
			break;
	/*
	 *	Affiche A_Message[0..2] 
	 */
	case   AP_TFAIL:
	case   AP_RESCHG:
	case   SHUT_COMPLETED:
			sprintf(Tampon[Suivante++],
				MessagList[A_Message[0]],
		        	A_Message[1]);
			break;
	/*	
	 *	Affiche A_Message[0,1,2,4] 
	 */
	case   AC_OPEN:   
			sprintf(Tampon[Suivante++],
				MessagList[A_Message[0]],
		          	A_Message[1],A_Message[4]);
			break;
	/*	
	 *	Affiche A_Message[0,1,2,5] 
	 */
	case   AP_TERM:  
			sprintf(Tampon[Suivante++],
				MessagList[A_Message[0]],
		           	A_Message[1],A_Message[5]);
			break;
	/*
	 *	Affiche A_Message[0..3] et A_Message[4] de ArrowedList
	 */
	case   WM_ARROWED:
			sprintf(Tampon[Suivante++],
				MessagList[A_Message[0]],
		          	A_Message[1],A_Message[3],
		          	ArrowedList[A_Message[4]]);
			break;
	/*	
	 *	Unknow Message: return
	 */
	default:	break;
  }  
  W_Printf(WHandle,Tampon[Suivante-1]);
}

