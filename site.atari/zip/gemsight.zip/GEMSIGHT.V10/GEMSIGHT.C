/*
 *				GemSight, to have a look to system's messages 
 *				
 *	Author  : FunShip
 *	File	: Gemsight.C
 *	Date    : 29 June 1995
 *	Revision: 27 Juillet 1995
 *	Version : 1.0
 *
 *	
 */

#include <stdio.h>
#include <tos.h>
#include <string.h>

#include "F:\Aads.030\Include\PCAADS.h"

#include "GmSightF.h"
#include "GsDef.h"
#include "Messages.h"

/*
 * ---------------------------------------------------------------------------------------
 *			External defintions from Window.C 
 */

extern	int	CalculNext(int Suivante,int Handle);
extern	void	Quitter(int Handle);
extern	void	WContenu(int Handle);

/*
 * ---------------------------------------------------------------------------------------
 *			External defintions from Formular.C 
 */

extern	Type_Form_List	FormMain[];
extern	int		NombreClicPhoto;

/*
 * ---------------------------------------------------------------------------------------
 *			Locals and globals Variables
 */

		 
int		acc_id;				/* Acessory ID */

char		Tampon[NBLINE][NBCOL];		/* Messages buffer */
int		Suivante;

int		WHandle;			/* Handle of display window */
int		Sortir;				/* To exit GemSight */
int		GSEvnt;				/* Defined how GS is working */
int 		TargetWindow,
		TargetOwner;

/*
 * ---------------------------------------------------------------------------------------
 *			
 */
 
int Targeting(int *TargetWindow,int *TargetOwner)
/*
	This procedure allow the user to target a window to obtain 
	its Window Handle and AES Pid Owner.
	Working with a wait for a Top message patched catch.
*/
{
  int	Buffer[8];
  
  /*
   *	Waiting a message
   */
  evnt_mesag(Buffer);
  
  if(Buffer[0] & FlagGS)
  {
    if((Buffer[0] & ~FlagGS) & WM_TOPPED)
    {
      *TargetWindow = Buffer[3];
      *TargetOwner = Buffer[2];
      return(TRUE);
    }
    else
      form_alert(1,"[0][ A mouse selected was waiting ][Ok]");
  }
  else
    form_alert(1,"[0][ Another window was waiting ][Ok]");

  return(FALSE);
}

/*
 * ---------------------------------------------------------------------------------------
 *				Patch Procedures
 */
 
extern void (*oldaes)();
extern void (newaes)();

void Patch(void)
/*
	Install the patch program to catch all appl_write() call into Aes system
*/
{
  oldaes=Setexc(0x22,newaes);
}

void UnPatch(void)
/*
	Delete the patch program and replace the original entry point into Aes.
*/
{
  Setexc(0x22,oldaes);
}

/*
 * ---------------------------------------------------------------------------------------
 *					Messages processing
 */

void RecordMsg(void)
{
  Suivante = CalculNext(Suivante,WHandle);

  if(A_Event & MU_MESAG)					/* Event is a message */
  {
    if(IsKnowMessage(A_Message[0] & (~FlagGS)))			/* If is know */
    {
      if((A_Message[0] & FlagGS) && (GSEvnt & GS_OTHER)		/* Patched messages */
      	  && !(GSEvnt & GS_FIXMODE))
      {
        PtchWrite();
      }			
      else if(GSEvnt & GS_FIXMODE)				/* Target Mode */ 
      {
        if((A_Message[2] == TargetOwner) && (A_Message[3] == TargetWindow))
        {
          PtchWrite();
        }
      }
      else if(GSEvnt & GS_MESSAG)				/* Standards messages */
      {
        StdWrite();
      }
      else
        ;
    }
    else							/* Unknow message */
    {
      sprintf(Tampon[Suivante++],"Unknow message(0x%X) Sender: %d, %d %d %d %d %d %d",
  		  A_Message[0] & (~FlagGS),A_Message[1],A_Message[2],A_Message[3],
  		  A_Message[4],A_Message[5],A_Message[6],A_Message[7]);
	    
      W_Printf(WHandle,Tampon[Suivante-1]);
    }
    if(A_Message[0] == AC_CLOSE)
    {  
      W_Redraw(WHandle);
      Quitter(WHandle);
    }
    if(A_Message[0] == WM_CLOSED)
    {  
      W_Redraw(WHandle);
    }
  }
  else if((A_Event & MU_KEYBD) && (GSEvnt & GS_EVENT))	/* Event is a keyboard event */																/* Event is another thing */
  {
    sprintf(Tampon[Suivante++],"Keyboard Event");
    W_Printf(WHandle,Tampon[Suivante-1]);
  }
  else if((A_Event & MU_BUTTON) && (GSEvnt & GS_EVENT))	/* Event is a mouse event */																					/* Event is another thing */
  {
    sprintf(Tampon[Suivante++],"Mouse button Event");
    W_Printf(WHandle,Tampon[Suivante-1]);
  }
  else if(A_Event & MU_TIMER)			/* Event is a timer event */
  {
    /* Nothing to do */     
  }
  else						/* unknow event */
    ;
}

/*
 * ---------------------------------------------------------------------------------------
 */

int OuvrirFenetre(void)
/*
	Open the GemSight window display messages
*/
{
  Type_Parameter_Window		*parameter;
  int	Handle;
  
  parameter = W_GetParameter();				/* Get a blok to create */
  strcpy(parameter->titre," GemSight V1.0 ");
  parameter->x	= 0;
  parameter->y	= DesktopMenu;
  parameter->w	= VdiInfo.LargeurStation / 2;
  parameter->h	= DesktopH;
  parameter->attributs	= NAME|INFO|CLOSER|FULLER|MOVER|SIZER|SMALLER;
  parameter->op_redraw	= WContenu;
  parameter->op_close 	= Quitter;
  Handle		= W_Open(parameter);
  Mfree(parameter);
  return(Handle);
}
 
void Principal(void)
/*
	Main program: Open a window and enter into an event message loop
*/
{
  OBJECT			*Arbre;
 
  WHandle = OuvrirFenetre();   
  /*
   *
   */
  F_Open(FMAIN,"Menu",F_WIND,NOTEXT,FormMain);		/* Fenetre principale	*/

  /*
   *	Event messages loop
   */
  rsrc_gaddr(R_TREE,ABOUTME,&Arbre);			/* Cache la photo */
  Arbre[FUNSHIP].ob_flags |= HIDETREE;
  Arbre[FUNFLO].ob_flags |= HIDETREE;
  NombreClicPhoto = 1;					/* Compte pour Photo cach�e */

  Sortir	= FALSE;
  Suivante	= 0;
 
  /*
   *	Initial GemSight work
   */
  GSEvnt = GS_OTHER;					/* Foreign messages only */
    
  Patch();
  do
  {
    A_WaitEvent();					/* Waiting an event	*/
    RecordMsg();
    if(A_Message[0] & FlagGS)				/* Patched message 	*/
      appl_write(A_Message[2],16,A_Message);		/* Re-send it		*/
    else
    {
      F_Event();					/* Form Event 		*/
      W_Event();					/* Window Event		*/
    }
  }
  while(!Sortir);
  UnPatch();
}

/*
 * ---------------------------------------------------------------------------------------
 */

int ExistProcessus(void)
/*
	Install a cookie identification and check if doesn't exist previous process
	of GemSight application
*/
{
  Type_Cookie	Cookie;
  
  if(!J_Exist())					/* If doesn't exist a Cookie jar */
    J_Install(CK_SLOTS);

  if(J_Search(CK_ID,&Cookie))				/* Exist another process */
    return(TRUE);

  strcpy(Cookie.identification,CK_ID);	/* Process identification */
  Cookie.information.mot_long = CK_VER;	/* Version number	  */

  if(!J_Insert(&Cookie))				/* Not enought free slots */
    J_Install(2*(int)J_Size());				/* Making a new Cookie Jar*/
  
  J_Insert(&Cookie);					/* And insert our cookie   */
  return(FALSE);					/* No previous process */
}

int main(void)
/*
	Install program as an accessory or standard application
*/
{
  int	Correct;
  int	TamponMessage[8];
    
  Correct = FALSE;
  if(!A_Open(RSC_NAME))
    form_alert(1,"[0][ GemSight Aes Error | Doesn't work ][Sorry]");
  else if(MchInfo.Processor < M68020)
    form_alert(1,"[0][ Gemsight Error | CPU 68020 and above only ][Sorry]");
  else if(AesInfo->ap_version < AES40)
    form_alert(1,"[0][ GemSight Aes Error | AES 4.0 and above only ][Sorry]");
  else
    Correct = TRUE;

  /*
   *	Initialisation d'AADS
   */  
  W_Init();  
  F_Init();						/* Init Form    */
  graf_mouse(ARROW,NULL);

  if(_app == 0)						/* L'appli. est un .ACC */
  {
    fprintf(stdout,"\n\n\033pGemSight V1.0 by FunShip\n\033q");
    acc_id = menu_register(AesHandle,ACC_NAME);
    if(acc_id != -1)					/* Au moins une entr�e de libre */
      fprintf(stdout,"Loading Ok\n");
    else
      fprintf(stdout,"Loading Failled, not enough menu entry\n");
    
    while(1)						/* Boucle infinie Acc�ssoire */
    {
      evnt_mesag(TamponMessage);			/* Attendre un message */
      if(TamponMessage[4] == acc_id)
      {
        switch(TamponMessage[0])
        {
          case AC_OPEN:	if(Correct)
          		{
            		  if(ExistProcessus())
			    form_alert(1,"[0][ Another GemSight's Process | is running ][Ok]");
    			  else
			  {
			    Principal(); 
			    J_Delete(CK_ID);		/* Remove Cookie identification */
			  }
			}
            		else
            		  form_alert(1,"[0][ GemSight Error | doesn't work ! ][Sorry]");
            		break;
          case AC_CLOSE:J_Delete(CK_ID);		/* When resolution is changing */
          		break;
          default:	break; 
        }
      }
    }
  }
  else if(Correct)					/* L'appli. est un .PRG */
  {
    if(ExistProcessus())
      form_alert(1,"[0][ Another GemSight's Process | is running ][Ok]");
    else
    {
      Principal(); 
      J_Delete(CK_ID);					/* Remove Cookie identification */
    }
  }
  else
    ;
    
  A_Close();
  W_Exit();  
  F_Exit();						/* Init Form    */
  return(0);
}

