/*
 *			Contain the methods program to manage the window
 *				
 *	Author  : FunShip
 *	File	: Window.C
 *	Date    : 29 June 1995
 *	Revision: 23 Juillet 1995
 *	Version : 1.0
 *
 *	
 */
#include <stdio.h>

#include "F:\Aads.030\Include\PCAADS.h"

#include "GmSightF.h"
#include "GsDef.h"

extern	int	Sortir;
extern	int	acc_id;				/* Acessory ID */

extern	char	Tampon[NBLINE][NBCOL];		/* Messages buffer */
extern	int	Suivante;

#include "GsDef.h"

int CalculNext(int Suivante,int Handle)
/*
	Calculate the next line to write the text message into the buffer
*/
{
  if(Suivante >= NBLINE || Suivante > W_GMaxLine(Handle))
  {
    Suivante = 0;
    W_Redraw(Handle); 
  }
  return(Suivante);
}

/*
 * ---------------------------------------------------------------------------------------
 *			Window's methods: Display and exit procedure
 */

void Quitter(int Handle)
/*
	Procedure called by closer button of display window
*/
{
  Sortir = TRUE;
  W_Close(Handle);				/* Close ALL possible window */
  F_Close(FMAIN);
  F_Close(ABOUTME);
  F_Close(CONFIG);
  F_Close(FLOOK);
}

void WContenu(int Handle)
/*
	Writing into window the messages recorded
*/
{
  int	NbLine, Indice,dummy;
  char	Texte[100];    
  
  NbLine = W_GMaxLine(Handle);

  sprintf(Texte,"Aes=%d Vdi=%d Window=%d Acc=%d",
  	  AesHandle,VdiHandle,Handle,acc_id); 
  wind_set(Handle,WF_INFO,Texte,&dummy,&dummy);
    
  W_ClrScr(Handle);
  W_HomeCursor(Handle);
  Indice = 0;
  while(Indice < NbLine && Indice < Suivante)
  {
    W_Printf(Handle,Tampon[Indice++]);
  }
}

