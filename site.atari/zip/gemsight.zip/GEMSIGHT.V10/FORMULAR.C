/*
 *			Contain the methods program to manage the Formulars
 *				
 *	Author  : FunShip
 *	File	: Formular.C
 *	Date    : 29 June 1995
 *	Revision: 23 Juillet 1995
 *	Version : 1.0
 *
 *	
 */
#include <stdio.h>

#include "F:\Aads.030\Include\PCAADS.h"

#include "GmSightF.h"					/* Ressource descriptor */
#include "GsDef.h"

/*
 * ---------------------------------------------------------------------------------------
 *				External definitions from GemSight.C
 */

extern	int	GSEvnt,					/* GS Working mode */
	 	TargetWindow,
		TargetOwner,
		Sortir,					/* To exit program */
		WHandle;				/* handle of Display Window */

extern	int	Targeting(int *TargetWindow,int *TargetOwner);
extern	void	Quitter(int Handle);

/*
 * ---------------------------------------------------------------------------------------
 *			Locals and globals variables in this modules
 */
 
int	NombreClicPhoto;


/*
 * ---------------------------------------------------------------------------------------
 *				Methods's definitions
 */
 
void MainExit(void);
void CallInfo(void);
void CallSetup(void);
void MainHide(void);
void CallLook(void);

Type_Form_List
FormMain[]=	{	{MAINEXIT	,MainExit	,NULL},
			{MAINHIDE	,MainHide	,NULL},
			{CALLABOUT	,CallInfo	,NULL},
			{CALLSETUP	,CallSetup	,NULL},
			{CALLLOOK	,CallLook	,NULL},
			FORM_END
		};

/* ---------------------------------------------------------------------------------------*/

void InfoExit(void);
void PhotoCachee(void);

Type_Form_List
FormInfo[]=	{	{INFOEXIT	,InfoExit	,PhotoCachee},
			FORM_END
		};

/* ---------------------------------------------------------------------------------------*/

void ConfigExit(void);
void SetGS(void);

Type_Form_List
FormConfig[]=	{	{CONFIGEXIT	,ConfigExit	,NULL},
			{GSMESSAGE	,SetGS		,NULL},
			{GSEVENT	,SetGS		,NULL},
			{GSOTHER	,SetGS		,NULL},
			{FIXWINDOW	,SetGS		,NULL},
			{GSFIXMODE	,SetGS		,NULL},
			FORM_END
		};

/* ---------------------------------------------------------------------------------------*/

void FLook(void);

Type_Form_List
FormLook[]=	{	{LOOKEXIT	,FLook		,NULL},
			{SEEK		,FLook		,NULL},
			FORM_END
		};

/*
 * ---------------------------------------------------------------------------------------
 *			Procedures to manage all GEM formulars
 */

/*	
 * ---------------------------------------------------------------------------------------
 *				Information formular 
 */
 
void PhotoCachee(void)
/*
	Called by Double-Clic on Exit button of about me window
*/
{
  OBJECT	*Arbre;
  
  if(NombreClicPhoto == 3)			/* Rendre la photo visible */
  {
      rsrc_gaddr(R_TREE,ABOUTME,&Arbre);	/* Bit cach� Off */
      Arbre[FUNSHIP].ob_flags &= ~HIDETREE;	
      Arbre[FUNFLO].ob_flags &=~ HIDETREE;
      F_RedrawObject(Arbre,FUNSHIP);		/* Redessiner la photo */
      F_RedrawObject(Arbre,FUNFLO);
      NombreClicPhoto = 1;
  } 
  else						/* Compter le nombre de DbClics */
    NombreClicPhoto++;
}

void InfoExit(void)
/*
	Procedure called by exit button of about me window
*/
{
  OBJECT	*Arbre;
  
  rsrc_gaddr(R_TREE,ABOUTME,&Arbre);			/* Cache la photo */
  Arbre[FUNSHIP].ob_flags |= HIDETREE;
  Arbre[FUNFLO].ob_flags |= HIDETREE;
  F_Close(ABOUTME);
}

/*	
 * ---------------------------------------------------------------------------------------
 *					Main Formular 
 */

void CallSetup(void)
/*
	Procedure called by Setup button of main menu
*/
{
  F_Open(CONFIG,"GemSight Setup",F_WIND,NOTEXT,FormConfig);	/* Setup window */  
}

void CallLook(void)
/*
	Procedure called by Setup button of main menu
*/
{
  F_Open(FLOOK,"Look...",F_WIND,NOTEXT,FormLook);		/* Look window */  
}

void CallInfo(void)
/*
	Procedure called by Info button of main menu
*/
{
  F_Open(ABOUTME,"About me...",F_WIND,NOTEXT,FormInfo);	/* Information window */
  F_WriteText(ABOUTME,VERSION,GS_VERSION);		/* Write version number */
}
 
void MainHide(void)
/*
	Close main formular but without exit program
*/
{
  F_Close(FMAIN);
}

void MainExit(void)
/*
	Procedure called by exit button of main menu: Close really application
*/
{
  Quitter(WHandle);			/* Call Quitter procedure of display window */
}

/*
 * ---------------------------------------------------------------------------------------
 *					Setup Formular 
 */

void ConfigExit(void)
/*
	Procedure called by exit button of if setup window
*/
{
  F_Close(CONFIG);
}

void SetGS(void)
/*
	Procedure called by all Setup window's button to set how GemSight does work
*/
{
  switch(F_NameObject)
  {
    /*
     *		defined GemSight workik mode
     */
    case GSMESSAGE:	if(GSEvnt & GS_MESSAG)				/* GS's messages */
    			{
    			  GSEvnt &=~GS_MESSAG;
    			  F_WriteText(CONFIG,COCHE1,"  ");
    			}
    			else
    			{
    			  GSEvnt |=GS_MESSAG;	
    			  F_WriteText(CONFIG,COCHE1," \010");
    			}
    			break;
    case GSEVENT:	if(GSEvnt & GS_EVENT)				/* GS's events */
    			{
    			  GSEvnt &=~GS_EVENT;
    			  F_WriteText(CONFIG,COCHE2,"  ");
    			}
    			else
    			{
    			  GSEvnt |=GS_EVENT;
  			  F_WriteText(CONFIG,COCHE2," \010");
    			}
    			break;
    case GSOTHER:	if(GSEvnt & GS_OTHER)				/* Other messages */
    			{
    			  GSEvnt &=~GS_OTHER;
    			  F_WriteText(CONFIG,COCHE3,"  "); 
    			}
    			else
    			{
    			  GSEvnt |=GS_OTHER;
    			  F_WriteText(CONFIG,COCHE3," \010");
    			}
    			break;
    /*
     *		Working with a Target Window
     */
    case FIXWINDOW:	F_Select(CONFIG,FIXWINDOW);
    			if(!Targeting(&TargetWindow,&TargetOwner))	/* Select a window */
    			{
    			  GSEvnt &=~GS_FIXMODE;
    			  F_WriteText(CONFIG,COCHE4,"  ");
    			}
    			F_UnSelect(CONFIG,FIXWINDOW);
    			break;
    case GSFIXMODE:	if(GSEvnt & GS_FIXMODE)				/* Switch Target mode */
    			{
    			  GSEvnt &=~GS_FIXMODE;
    			  F_WriteText(CONFIG,COCHE4,"  "); 
    			}
    			else
    			{
    			  GSEvnt |=GS_FIXMODE;
    			  F_WriteText(CONFIG,COCHE4," \010");
    			}
    			break;
    default:		break;
  }
}

/*
 * ---------------------------------------------------------------------------------------
 *					Look Formular 
 */

void FLook(void)
{
  int	TargetWindow,TargetOwner;
  char	Owner[10],Handle[10];
  
  switch(F_NameObject)
  {
    case LOOKEXIT:	F_Close(FLOOK);
    			break;
    case SEEK:		if(Targeting(&TargetWindow,&TargetOwner))
	    		{
    			  sprintf(Owner,"%d",TargetOwner);
	    		  sprintf(Handle,"%d",TargetWindow);
    			  F_WriteText(FLOOK,OWNER,Owner);
    			  F_WriteText(FLOOK,HANDLE,Handle);
    			}
    			break;
    default:		break;
  }
}