/*
 *
 *	Primitives de gestion de la table des symboles
 *
 * 	Auteur : FAVARD Laurent
 *	Fichier: TSYMBOLE.C
 *	Pays   : FRANCE
 *	Date   : 20 Mars 1994
 *	Revision: 1 Avril 1994
 *	Version : 1.0
 *	Release : 1.2
 *	Machine : ATARI Falcon030 TOS 4.2
 *	Processeur cible: MC68705 P3S (Famille 6805)
 */

#include <stdio.h>
#include <string.h>

#include "assemble.h"
#include "p68705.h"

typedef struct {			/* Type entr�e TableSymbole */
		 char lexeme[TAILLEID];	/* Lexeme associ� */
		 int  valeur;		/* valeur OU Adresse */
	       } Type_Symbole;

static int		TbSymDebut;	/* D�but des entr�es libres Users */
static int		TbSymIndice=0;	/* Prochainne entr�e libre */
static Type_Symbole	TableSymbole[TAILLETBLSYMBOLE];	/* La Table */

/*
  ----------------------- Primitives priv�es ------------------------------
*/

static int RechercheSymbole(char *lexeme)
/*
	Retourne l'indice dans la table o� se trouve le lexeme.
	ATTENTION, � n'appeler qu'ap�s avoir v�rifier si le lexeme
	�tait bien pr�sent.
*/
{
  int i=0;
  
  while(i<TbSymIndice && strcmp(lexeme,TableSymbole[i].lexeme)!=0)
    i++;
  return(i);
}

/*
  ----------------------- Primitives publiques ------------------------------
*/

void ViderSymbole(void)
{
  TbSymIndice = 0;
}

int EstPresentSymbole(char *lexeme)
/*
	Retourne TRUE si le lexeme est d�j� pr�sent dans la table des
	symboles.
*/
{
  int i=0;
  int retour;
  
  while(i<TbSymIndice && strcmp(lexeme,TableSymbole[i].lexeme)!=0)
    i++;
  retour = strcmp(TableSymbole[i].lexeme,lexeme)==0 && i < TbSymIndice 
  	   ? TRUE : FALSE;  
  return(retour);
}

void AjouterSymbole(char *lexeme)
/*
	Ajoute le lexeme dans la table des symboles si il n'est pas d�j�
	pr�sent, sinon aucune action.
*/
{
  if(!EstPresentSymbole(lexeme) && TbSymIndice < TAILLETBLSYMBOLE)
    strcpy(TableSymbole[TbSymIndice++].lexeme,lexeme);
}

void LierSymbole(char *lexeme,int valeur)
/*
	Attache au symbole lexeme la valeur numerique pass�e.
*/
{
  int entree;
  
  entree = RechercheSymbole(lexeme);
  TableSymbole[entree].valeur = valeur;
}

int ValSymbole(char *lexeme)
/*
	Retourne la valeur num�rique associ�e � l'identificateur
	lexeme rang� dans la table des symboles.
	Attention: L'identificateur DOIT exist� !
*/
{
  return(TableSymbole[RechercheSymbole(lexeme)].valeur);
}

/*
  ----------------------- Primitives particuli�res -------------------
*/

void InitKeyWords(int Processeur)
/*
	Ajoute dans la table des symboles, les mots clefs correspondants
	aux mots r�serv�s pour d�signer les registres plac�s en m�moire
	du Micro-Conrtolleur, tel que PortA, DDRA, etc...
*/
{
  /* Processeur de base: P3 */
  AjouterSymbole("PORTA"); LierSymbole("PORTA",0x00);
  AjouterSymbole("PORTB"); LierSymbole("PORTB",0x01);
  AjouterSymbole("PORTC"); LierSymbole("PORTC",0x02);
  AjouterSymbole("DDRA");  LierSymbole("DDRA", 0x04);
  AjouterSymbole("DDRB");  LierSymbole("DDRB", 0x05);
  AjouterSymbole("DDRC");  LierSymbole("DDRC", 0x06);
  AjouterSymbole("TDR");   LierSymbole("TDR",  0x08);
  AjouterSymbole("TCR");   LierSymbole("TCR",  0x09);
  AjouterSymbole("PCR");   LierSymbole("PCR",  0x0B);
  
  /* Processeurs sup�rieurs: U3 et R3 */
  if( Processeur >= P68705U3 )
  {
    AjouterSymbole("PORTD"); LierSymbole("PORTD",0x03);
    AjouterSymbole("MR"); LierSymbole("MR",0x0A);
  }
  if( Processeur >= P68705R3 )
  {
    AjouterSymbole("ADCR"); LierSymbole("ADCR",0x0E);
    AjouterSymbole("ADR"); LierSymbole("ADR",0x0F);
  }

  TbSymDebut = TbSymIndice;		/* D�but entr�es libres */
}

void PrintTable(void)
/*
	Imprime la table des symboles dans le fichier FileOut
*/
{
  int i;
  fprintf(FileLST,"\n\nContenu Table Symbole\n");
  fprintf(FileLST,"---------------------\n");
  for(i=TbSymDebut;i<TbSymIndice;i++)
  {
    fprintf(FileLST," %s",TableSymbole[i].lexeme);
    fprintf(FileLST,"\t\t$%X\n",TableSymbole[i].valeur);
  }
}
