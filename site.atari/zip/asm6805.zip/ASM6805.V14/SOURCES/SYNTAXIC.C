/*
 *
 *	Sch�ma de traduction pour langage d'assemblage 68705
 *	construit sur une grammaire de type LL(1).
 *
 * 	Auteur : FAVARD Laurent
 *	Fichier: SYNTAXIC.C
 *	Pays   : FRANCE
 *	Date   : 20 Mars 1994
 *	Revision: 3 Avril 1994
 *	Version : 1.0
 *	Release : 1.4
 *	Machine : ATARI Falcon030 TOS 4.2
 *	Processeur cible: MC68705 P3S (Famille 6805)
 */

#include <tos.h>			/* Header du langage */
#include <stdio.h>			/* et syst�me Atari  */
#include <stdlib.h>
#include <string.h>

#include "assemble.h"			/* Entete global */
#include "lexicale.h"			/* Interface avec le lexical */
#include "codeur.h"			/* Primitives de production */
#include "tsymbole.h"

#include "erreur.h"

/* 
  ----------------------- D�finitions des types ------------------------
*/

typedef struct {			/* Type d'un attribut h�rit� */
		 int  valeur;
		 char lexeme[TAILLEID];
		 int  defini;
	       } Type_Hvaleur;

typedef struct Tposte
	       {
		 int 		Adresse;
		 char		Etiquette[TAILLEID];
		 long		Ligne;
		 struct Tposte	*Next;
	       } Type_Poste;

/* 
  -------------------------- Donn�es publiques  ------------------------
*/

int	  		symbole;	/* Contient l'unit� lexicale courante */
int			CompteurAssemblage=STARTCODEDEFAULT;

/* 
  --------------------------- Donn�es priv�es  -------------------------
*/

static int  		Exsymbole;	/* Pr�c�dente unit� lexicale  */
static Type_ValLex	ExValLex;	/* Pr�c�dente valeur lexicale */
static Type_Poste	*FileBra,*FileDirect;

/*
	D�fini dans Main.c
*/

extern 		int  WindHandle;

/*
  -------- Prototypes des fonctions de l'analyseur syntaxique ----------
*/

int Axiome(void);
static int Def(void);
static int Code(void);
static int LignInst(void);
static int Adressage(char *hinst);
static int Symbole(void);
static int Complement(char *hinst,Type_Hvaleur *hvaleur);
static int CompSecond(char *hinst,Type_Hvaleur *hvaleur1,Type_Hvaleur *hvaleur2);
static int Term(void);
static int Data(void);
static int DataDesc(void);
static int Suite(void);


/*
		Primitives bas niveaux pour l'analyseur
*/


static void PrintLexeme(int symbole,Type_ValLex *ValLex)
/*
	Affiche l'unit� lexicale qui vient d'etre accept�.
*/
{
  if(symbole == NB)
    fprintf(FileLST," 0x%X ",ValLex->numerique);
  else if(symbole == FDL)
    fprintf(FileLST,"\n");
  else if(symbole == ID)
    fprintf(FileLST," %s",ValLex->lexeme);
  else if(symbole == INST)
    fprintf(FileLST,"\t%s ",ValLex->lexeme);
  else 
    fprintf(FileLST," %s ",ValLex->lexeme);
}

static int Accepter(int unitelex)
/*
	Accepte l'unit� lexicale courante et lit la prochainne.
	Ici est r�alis� l'interface avec l'analyseur lexical.
*/
{
  if(symbole == unitelex)
  {
    Exsymbole = symbole;		/* devient pr�c�dente */
    ExValLex.numerique = ValLex.numerique;
    strcpy(ExValLex.lexeme, ValLex.lexeme);
    symbole   = AnalyseLex();		/* prochainne unite lex. */
    if(symbole == LEXERREUR)
      return(FALSE); 
    PrintLexeme(Exsymbole,&ExValLex);
  }
  else
  {
    SYNerreur();
    return(FALSE);
  }
  return(TRUE);
}

static int AvancerCompteur(int addition)
/*
	Avance le compteur d'assemblage de 'addition' octets et
	controle que celui-ci n'exc�de pas la limite autoris�e
	par l'espace m�moire du Motorola.
*/
{
  CompteurAssemblage += addition;
  if(CompteurAssemblage >= TailleTamponPRG)
  {
    SEMerreur(ERR_CPTASM,Lexline,"");
    return(FALSE);
  }
  return(TRUE);
}

static int InitCompteur(int valeur)
{
  CompteurAssemblage = valeur;
  if(CompteurAssemblage >= TailleTamponPRG)
  {
    SEMerreur(ERR_CPTASM,Lexline,"");
    return(FALSE);
  }
  return(TRUE);
}

/*
	Implantation de l'analyseur syntaxique pr�dictif par descente 
	r�cursive.
*/

static void CalculAttSyn(int symbole,Type_ValLex *valLex,Type_Hvaleur *valeur)
/*
	Calcul le futur attribut h�rit� valeur fonction de l'unit� 
	lexicale pass�e.
	En retour on obtient la valeur num�rique si d�fini
	Sinon le lexeme.
*/
{
  if(symbole == NB)				/* Est un chiffre */			
  {
    valeur->valeur = valLex->numerique;
    valeur->defini = TRUE;
  }
  else if(symbole == ID && EstPresentSymbole(valLex->lexeme))
  {
    valeur->valeur  = ValSymbole(valLex->lexeme);
    valeur->defini  = TRUE;
  }
  else						/* ID non encore d�fini */
  {
    strcpy(valeur->lexeme,valLex->lexeme);	/* Copier �tiquette */
    valeur->defini = FALSE;			/* non d�fini encore */ 
  }
}

static int EstOctet(int operande)
/*
	Retourne TRUE si la valeur de l'op�rande est sur un octet.
*/
{
  int retour;
  
  retour = (unsigned int)operande <= (unsigned int)0xFF ? TRUE: FALSE;
  return(retour);
}

static int EstSigneOctet(int operande)
/*
	Retourne TRUE si la valeur de l'op�rande est une valeur 8 bits
	sign�e
*/
{
  int retour;
  
  retour = operande < -128 || operande > 127 ? FALSE : TRUE;
  return(retour);
}

static Type_Poste *Emfiler(Type_Poste *File,int ComptAsm,long ligne,char *lexeme)
/*
*/
{        		
  Type_Poste	*poste;
  
  poste = malloc(sizeof(Type_Poste));
  poste->Next    = File;
  poste->Adresse = ComptAsm;
  poste->Ligne   = ligne;
  strcpy(poste->Etiquette,lexeme);
  return(poste);
}

/*
  -------------------------- Analyseur Syntaxique -----------------------------
*/

int Axiome(void)
{
  /*
  	Initialise les files pour la r�solution des @ssages 
  	post-d�finis: On stocke les valeurs du compteur d'assemblage
  	correspondant aux emplacements d'@ direct/relative non calcul�es
  */
  FileBra    = NULL;
  FileDirect = NULL;
  Lexline    = 0L;
  
  if(!Def())
    return(FALSE);
  if(!Accepter(TEXT))
    return(FALSE);
  if(!Code())
    return(FALSE);
  if(!Term())
    return(FALSE);
  return(TRUE);
}

static int Def(void)
{
  char  etiquette[TAILLEID];
    
  if(symbole == ID)
  {
    if(!Accepter(ID))
      return(FALSE);	
    if(EstPresentSymbole(ExValLex.lexeme))		/* Ajout ID Table */
    {
      SEMerreur(ERR_DEFINE,Lexline,ExValLex.lexeme);
      return(FALSE);
    }
    else
    {
      AjouterSymbole(ExValLex.lexeme);
      strcpy(etiquette,ExValLex.lexeme);
    }
    if(!Accepter(EQU))
      return(FALSE);
    if(!Symbole())
      return(FALSE);
    if(Exsymbole == NB)					/* xx equ nb */
      LierSymbole(etiquette,ExValLex.numerique);
    else if(EstPresentSymbole(ExValLex.lexeme))		/* xx equ yy */
      LierSymbole(etiquette,ValSymbole(ExValLex.lexeme));
    else
    {
      SEMerreur(ERR_NODEFINE,Lexline,ExValLex.lexeme); 
      return(FALSE);
    }
    if(!Accepter(FDL))
      return(FALSE);
    if(!Def())
      return(FALSE);
  }
  else if(symbole == FDL)
  {
    if(!Accepter(FDL))
      return(FALSE);
    if(!Def())
      return(FALSE);
  }
  else
  {
    /* E-Production */
  }
  return(TRUE);
}

static int Code()
{
  if(symbole == ORG)
  {
    if(!Accepter(ORG))
      return(FALSE);
    if(!Accepter(NB))
      return(FALSE);
    if(!InitCompteur(ExValLex.numerique))
      return(FALSE);
    if(!Accepter(FDL))
      return(FALSE);
    if(!Code())
      return(FALSE);
  }
  else if(symbole == ID)
  {
    if(!Accepter(ID))
      return(FALSE);
    if(EstPresentSymbole(ExValLex.lexeme))
    {
      SEMerreur(ERR_DEFINE,Lexline,ExValLex.lexeme);
      return(FALSE);
    }
    else
    {
      AjouterSymbole(ExValLex.lexeme);
      LierSymbole(ExValLex.lexeme, CompteurAssemblage);
    }
    if(!Accepter(DBP))
      return(FALSE);
    if(symbole == INST)
    {
      if(!LignInst())
        return(FALSE);
      if(!Accepter(FDL))
        return(FALSE);
      if(!Code())
        return(FALSE);
    }
    else if(symbole == FDL)
    {
      if(!Accepter(FDL))
        return(FALSE);
      if(!Code())
        return(FALSE);
    }
    else
    {
      SYNerreur();
      return(FALSE);
    }
  }
  else if(symbole == INST)
  {
    if(!LignInst())
      return(FALSE);
    if(!Accepter(FDL))
      return(FALSE);
    if(!Code())
      return(FALSE);
  }
  else if(symbole == FDL)
  {
    if(!Accepter(FDL))
      return(FALSE);
    if(!Code())
      return(FALSE);
  }
  else
  { 
    /* Vide */
  }
  return(TRUE);
}

static int LignInst()
{
  char instruction[6];
  
  if(!Accepter(INST))
    return(FALSE);
  strcpy(instruction,ExValLex.lexeme);	/* Recopie */
  if(!Adressage(instruction))		/* Adressage.hinst <- instruction */
    return(FALSE);
  return(TRUE);
}

static int Adressage(char *hinst)
/*
  Entree: hinst: attribut h�rit� instruction
*/
{
  int		CodeHexa;			/* Recoit le code machine */
  int		Operande;			/* Recoit op�rande pour l'imm�diat */
  Type_Hvaleur  hvaleur;			/* att. h�rit� */
      
  if(symbole == DIESE)					/* ADRESSAGE IMMEDIAT */
  {
    if(!Accepter(DIESE))
      return(FALSE);
    if(!Symbole())
      return(FALSE);
    if(Exsymbole == ID && !EstPresentSymbole(ExValLex.lexeme))
    {
      SEMerreur(ERR_NODEFINE,Lexline,ExValLex.lexeme);	/* L'op�rande doit etre d�finie */
      return(FALSE);
    }
    if(Immediat(hinst,&CodeHexa))			/* Code existant ? */
    {
      if(Exsymbole == ID)				/* Si ID rechercher la valeur */
        Operande = ValSymbole(ExValLex.lexeme); 
      else						/* Sinon d�j� disponible */
        Operande = ExValLex.numerique;
      if(EstOctet(Operande))				/* valeur sur 8 bits */
        Coder2("Imm�diat",CodeHexa,0x00FF & Operande);	/* mode @ssage interdit */
      else
      {
        SEMerreur(ERR_DATASUP8,Lexline,"");
        return(FALSE);
      }
      if(!AvancerCompteur(2))
        return(FALSE);
    }    
    else
    {
      SEMerreur(ERR_IMMEDIAT,Lexline,hinst);
      return(FALSE);
    }
  }
  else if(symbole == ID || symbole == NB)		/* AUTRE ADRESSAGE */
  {
    if(!Symbole())
      return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&hvaleur);
    if(!Complement(hinst,&hvaleur))
      return(FALSE);
  }
  else							/* ADRESSAGE INHERANT */
  {
    /* E-production */
    if(Inherant(hinst,&CodeHexa))		/* Code h�xa. de l'instruction */
      Coder1("Inh�rant",CodeHexa);		/* Coder avec 0 op�randes */
    else
    {
      SEMerreur(ERR_INHERANT,Lexline,hinst);	/* mode @ssage interdit */
      return(FALSE);
    }
    if(!AvancerCompteur(1))
      return(FALSE);
  }
  return(TRUE);
}

static int Complement(char *hinst,Type_Hvaleur *hvaleur)
/*
  Entr�e: hinst   = Instruction h�rit�
  	  hvaleur = Valeur du premier symbole h�rit�
*/
{
  int		CodeHexa;
  int		Offset=0;
  Type_Hvaleur 	hvaleur2;				/* att. h�rit� */
        
  if(symbole == VIRG)
  {
    if(!Accepter(VIRG))
      return(FALSE);
    if(!Symbole())
      return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&hvaleur2);
    if(!CompSecond(hinst,hvaleur,&hvaleur2))
      return(FALSE);
  }
  else
  {
    /* E-Production */
    if(Relatif(hinst,&CodeHexa))			/* ADRESSAGE RELATIF */
    {
      if(hvaleur->defini)
      {
        Offset = hvaleur->valeur - CompteurAssemblage - 2;
        if(!EstSigneOctet(Offset))			/* out of range ! */
        {
          SEMerreur(ERR_OFFSET,Lexline,"");
          return(FALSE);
        }
        Offset &= 0x00FF;				/* passage 8 bits */
      }
      else
        Offset = 0x00;
      Coder2("Relatif",CodeHexa,Offset);
      if(!hvaleur->defini)				/* Symbole non d�fini */
      {
        FileBra = Emfiler(FileBra,CompteurAssemblage+1,
        			  Lexline,
        			  hvaleur->lexeme);
      }
      if(!AvancerCompteur(2))
        return(FALSE);
    }
    else if(Direct(hinst,&CodeHexa) || Etendu(hinst,&CodeHexa))		
    {
      if(hvaleur->defini)
      {
        if((unsigned int)hvaleur->valeur <= (unsigned int)0xFF)	/* Sur 8 bits */
        {
          if(!Direct(hinst,&CodeHexa))			/* ADRESSAGE DIRECT */
          {
            SEMerreur(ERR_DIRECT,Lexline,hinst);
            return(FALSE);
          }
          Coder2("Direct",CodeHexa,0x00FF & hvaleur->valeur);
          if(!AvancerCompteur(2))
            return(FALSE);
        }
        else						/* Sur 16 Bits */
        {
          if(!Etendu(hinst,&CodeHexa))			/* ADRESSAGE ETENDU */
          {
            SEMerreur(ERR_ETENDU,Lexline,hinst);
            return(FALSE);
          }
          Coder3("Etendu",CodeHexa,
          		  0x00FF & (hvaleur->valeur>>8),
          		  0x00FF & hvaleur->valeur);
          if(!AvancerCompteur(3))
            return(FALSE);
        }
      }
      else						/* valeur non d�fini */
      {
        if(!Etendu(hinst,&CodeHexa))			/* ADRESSAGE ETENDU */
        {
          SEMerreur(ERR_ETENDU,Lexline,hinst);
          return(FALSE);
        }
        Coder3("Etendu",CodeHexa,0x00,0x00);
        FileDirect = Emfiler(FileDirect,CompteurAssemblage+1,
        				Lexline,
        				hvaleur->lexeme);
        if(!AvancerCompteur(3))
          return(FALSE);
      }
    }
    else
    {
      SEMerreur(ERR_DIRECT,Lexline,hinst);
      return(FALSE);
    }
  }
  return(TRUE);
}

static int CompSecond(char *hinst,Type_Hvaleur *hvaleur1,Type_Hvaleur *hvaleur2)
{
  int		CodeHexa;
  Type_Hvaleur	valeur3;
  int		Offset;
      
  if(symbole == VIRG)
  {
    if(!Accepter(VIRG))
      return(FALSE);
    if(!Symbole())
      return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur3);	/* Calcul l'att. synth�tis� */
    if(hvaleur1->defini && hvaleur2->defini)
    {						/* BIT TEST AND BRANCH */
      if(BitTestBranch(hinst,hvaleur1->valeur,&CodeHexa))
      {
        if(hvaleur1->valeur < 0 || hvaleur1->valeur > 7)
        {
          SEMerreur(ERR_BIT,Lexline,"");	/* n'est pas dans [0,7] */
          return(FALSE);
        }
        if(!EstOctet(hvaleur2->valeur))		/* valeur non sur 8 bits */
        {
   	  SEMerreur(ERR_DATASUP8,Lexline,"");
   	  return(FALSE);
   	}
        if(valeur3.defini)			/* @ branch connue */
        {
          Offset = valeur3.valeur - CompteurAssemblage - 3;
          if(!EstSigneOctet(Offset))		/* out of range ! */
          {
            SEMerreur(ERR_OFFSET,Lexline,"");
            return(FALSE);
          }
          Offset &= 0x00FF;			/* passage 8 bits */
        }
        else					/* @ branch inconnue */
          Offset = 0x00;      
        Coder3("Bit Test And Branch",CodeHexa,hvaleur2->valeur,Offset);
        if(!valeur3.defini)
        {
          FileBra = Emfiler(FileBra,CompteurAssemblage+2,
	        		    Lexline,
        			    valeur3.lexeme); 
        }
        if(!AvancerCompteur(3))
          return(FALSE);
      }
      else
      {
        SEMerreur(ERR_BTB,Lexline,hinst);
        return(FALSE);
      }
    }
    else	/* hvaleur1 ou hvaleur2 non d�fini */
    {
      if(!hvaleur2->defini)      
      {
        SEMerreur(ERR_NODEFINE,Lexline,hvaleur2->lexeme);
        return(FALSE);
      }
      else
      {
        SEMerreur(ERR_NODEFINE,Lexline,hvaleur1->lexeme);
        return(FALSE);
      }
    }
  }
  else
  {
    /* E-Production */
    if(hvaleur1->defini)				/* Doit etre d�fini */ 
    {
      if(BitSetClear(hinst,hvaleur1->valeur,&CodeHexa))	/* BIT SET/CLEAR */
      {
        if(hvaleur1->valeur < 0 || hvaleur1->valeur > 7)
        {
          SEMerreur(ERR_BIT,Lexline,"");		/* n'est pas dans [0,7] */
          return(FALSE);
        }
        if(hvaleur2->defini)
        {
          if(!EstOctet(hvaleur2->valeur))		/* valeur non sur 8 bits */
          {
	    SEMerreur(ERR_DATASUP8,Lexline,"");
	    return(FALSE);
	  }
          Coder2("Bit Set/Clear",CodeHexa,0x00FF & hvaleur2->valeur);
        }
        else
        {
          SEMerreur(ERR_NODEFINE,Lexline,hvaleur2->lexeme);	/* L'op�rande doit etre d�finie */
          return(FALSE);
        }
        if(!AvancerCompteur(2))
          return(FALSE);
      }
      else if(Index0(hinst,&CodeHexa) ||		/* INDEXE */
      	      Index8(hinst,&CodeHexa) ||
      	      Index16(hinst,&CodeHexa))
      {
        if(strcmp(hvaleur2->lexeme,"X") == 0)		/* ref. reg. X */
        {
          if(hvaleur1->valeur == 0x00)			/* Index nul */
          {
            if(Index0(hinst,&CodeHexa))
              Coder1("Index� NUL",CodeHexa);
            else
            {
              SEMerreur(ERR_INDEX0,Lexline,hinst);	/* Index nul interdit */
              return(FALSE);
            }
            if(!AvancerCompteur(1))
              return(FALSE);
          }						/* Index sur 8 bits */
          else if(EstOctet(hvaleur1->valeur))	
          {
            if(Index8(hinst,&CodeHexa))
              Coder2("Index� 8 bits",CodeHexa,0x00FF & hvaleur1->valeur);
            else
            {
              SEMerreur(ERR_INDEX8,Lexline,hinst);	/* Index 8 bits interdit */
              return(FALSE);
            }
            if(!AvancerCompteur(2))
              return(FALSE);
          }
          else						/* Index sur 16 bits */
          {           
            if(Index16(hinst,&CodeHexa))
              Coder3("Index� 16 bits",CodeHexa,
              			      0x00FF & (hvaleur1->valeur>>8),
              			      0x00FF & hvaleur1->valeur);
            else
            {
              SEMerreur(ERR_INDEX16,Lexline,hinst);	/* Index 16 bits interdit */
              return(FALSE);
            }
            if(!AvancerCompteur(3))
              return(FALSE);
          }          
        }
        else
        {
          SEMerreur(ERR_REGX,Lexline,"");
          return(FALSE);
        }
      }
      else					/* Modes interdits */
      {
        SEMerreur(ERR_INDEX,Lexline,hinst);
        return(FALSE);
      }
      
    }
    else
    {
      SEMerreur(ERR_NODEFINE,Lexline,hvaleur1->lexeme);	/* L'op�rande doit etre d�finie */    
      return(FALSE);
    }
  }
  return(TRUE);
}

static int Term()
{
  if(symbole == DATA)
  {
    if(!Accepter(DATA))
      return(FALSE);
    if(!Accepter(FDL))
      return(FALSE);
    if(!Data())
      return(FALSE);
    if(!Accepter(END))
      return(FALSE);
  }
  else if(symbole == END)
  {
    if(!Accepter(END))
      return(FALSE);
  }
  else
  {
    SYNerreur();
    return(FALSE);
  }
  return(TRUE);
}

static int Data()
{
  if(symbole == ORG)
  {
    if(!Accepter(ORG))
      return(FALSE);
    if(!Accepter(NB))
      return(FALSE);
    if(!InitCompteur(ExValLex.numerique))
      return(FALSE);;				/* nouvelle @ */ 
    if(!Accepter(FDL))
      return(FALSE);
    if(!Data())
      return(FALSE);
  }
  else if(symbole == ID)
  {
    if(!Accepter(ID))
      return(FALSE);
    if(EstPresentSymbole(ExValLex.lexeme))	/* Ajout ID Table */
    {
      SEMerreur(ERR_DEFINE,Lexline,ExValLex.lexeme);
      return(FALSE);
    }
    else
    {
      AjouterSymbole(ExValLex.lexeme);
      LierSymbole(ExValLex.lexeme, CompteurAssemblage);
    }
    if(!Accepter(DBP))
      return(FALSE);
    if(!DataDesc())
      return(FALSE);
    if(!Accepter(FDL))
      return(FALSE);
    if(!Data())
      return(FALSE);
  }
  else if(symbole == FDL)
  {
    if(!Accepter(FDL))
      return(FALSE);
    if(!Data())
      return(FALSE);
  }
  else
  {
    /* Vide */
  }
  return(TRUE);
}

static int DataDesc()
/*
	Analyse et assemble les donnees
*/
{
  Type_Hvaleur valeur;

  if(symbole == DCB)				/* x: dcb 1,2,3[,n...] */
  {  
    if(!Accepter(DCB))
      return(FALSE);
    if(!Symbole())
      return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur);	/* Calcul l'att. synth�tis� */
    if(!valeur.defini)				/* Doit etre d�fini ! */
    {
      SEMerreur(ERR_NODEFINE,Lexline,valeur.lexeme);
      return(FALSE);
    }
    Coder1("",valeur.valeur);
    CompteurAssemblage++;			/* Un octet de plus */
    if(!Suite())
      return(FALSE);
  }
  else if(symbole == DSB)			/* x: dsb 5 ; 5 octets */
  {
    if(!Accepter(DSB))
      return(FALSE);
    if(!Symbole())
      return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur);
    if(!valeur.defini)				/* Doit etre d�fini */
    {
      SEMerreur(ERR_NODEFINE,Lexline,valeur.lexeme);
      return(FALSE);
    }
    CompteurAssemblage += valeur.valeur;
  }
  else						/* Erreur */
  {
    SYNerreur();
    return(FALSE);
  }
  return(TRUE);
}

static int Suite()
{
  Type_Hvaleur valeur;
  
  if(symbole == VIRG)
  {
    if(!Accepter(VIRG))
      return(FALSE);
    if(!Symbole())
      return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur);	/* Calcul l'att. synth�tis� */
    if(!valeur.defini)				/* Doit etre d�fini ! */
    {
      SEMerreur(ERR_NODEFINE,Lexline,valeur.lexeme);
      return(FALSE);
    }
    Coder1("",valeur.valeur);
    CompteurAssemblage++;			/* Un octet de plus */
    if(!Suite())
      return(FALSE);
  }
  else
  {
    /* E-Production */
  }
  return(TRUE);
}

static int Symbole()
/*
	Identifie un symbole qui peut etre une valeur num�rique NB ou
	un identificateur ID.
*/
{
  if(symbole == ID)
  {
    if(!Accepter(ID))
      return(FALSE);
  }
  else if(symbole == NB)
  {
    if(!Accepter(NB))
      return(FALSE);
  }
  else
  {
    SYNerreur();
    return(FALSE);
  }
  return(TRUE);
}

/*
  ---------------------- Traitements deuxi�me passe -------------------------
*/

int ResolutionAdressage(void)
/*
	Parcour des listes des adresses fautives Relatives et Directes
	et remplace les valeurs non calcul�es par les valeurs rang�es
	dans la table des symboles.
*/
{
  Type_Poste	*pointeur;
  int		Offset;
    
  pointeur = FileBra;		/* @ relative UN octet */
  while(pointeur!=NULL)
  {
    if(EstPresentSymbole(pointeur->Etiquette))
    {
      
      Offset = ValSymbole(pointeur->Etiquette)-(pointeur->Adresse-1) -2;
      if(Offset < -128 || Offset > 127)	/* out of range ! */
      {
        SEMerreur(ERR_OFFSET,pointeur->Ligne,pointeur->Etiquette);
        return(FALSE);
      }
      Offset &= 0x00FF;			/* passage 8 bits */
      TamponPRG[pointeur->Adresse] = Offset;
    }
    else
    {
      SEMerreur(ERR_NODEFINE,pointeur->Ligne,pointeur->Etiquette);
      return(FALSE);
    }
    pointeur = pointeur->Next;
    free(FileBra);
    FileBra  = pointeur;
  }
  
  pointeur = FileDirect;	/* @ directe DEUX octets */
  while(pointeur!=NULL)
  {
    if(EstPresentSymbole(pointeur->Etiquette))
    {
      TamponPRG[pointeur->Adresse]   = (0xFF00 & ValSymbole(pointeur->Etiquette)) >>8;
      TamponPRG[pointeur->Adresse+1] =  0x00FF & ValSymbole(pointeur->Etiquette);
    }
    else
    {
      SEMerreur(ERR_NODEFINE,pointeur->Ligne,pointeur->Etiquette);
      return(FALSE);
    }
    pointeur = pointeur->Next;
    free(FileDirect);
    FileDirect  = pointeur;
  }
  return(TRUE);
}