/*
 *
 *			Assembleur Motorola 68705
 *
 * 	Auteur : FAVARD Laurent
 *	Fichier: ASSEMBLE.C
 *	Pays   : FRANCE
 *	Date   : 20 Mars 1994
 *	Revision: 11 Mai 1994
 *	Version : 1.0
 *	Release : 1.6
 *	Machine : ATARI Falcon030 TOS 4.2
 *	Processeur cible: MC68705 P3S (Famille 6805)
 *
 */

#include <tos.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "F:\Aads.030\Include\PCAads.h"

#include "lexicale.h"
#include "syntaxic.h"
#include "tsymbole.h"

#include "p68705.h"

/*
  ---------------------- Messages Multi-Langues ---------------------------
*/
static 
char	Messages[10][3][80]={{"Logiciel domaine publique pour compatible Falcon",
			      "Public domain software for Falcon compatible",
			      "Public domain software for Falcon compatible"},
			     {"Version Novembre 1994-95",
			      "Version of November 1994-95",
			      "Version of November 1994-95"},
			     {"Fichier non trouv�",
			      "File not found, job aborted",
			      "File not found, job aborted"},
			     {"Premi�re passe, parcour du fichier et assemblage",
			      "First Pass, reading and assemble",
			      "First Pass, reading and assemble"},
			     {"Deuxi�me passe, r�solution des post-d�finitions",
			      "Second Pass, solve undefined reference",
			      "Second Pass, solve undefined reference"},
			     {"Creation du fichier Eprom .PRM",
			      "Making Eprom file .PRM",
			      "Making Eprom file .PRM"},
			     {"Creation du fichier Ascii .TBL",
			      "Making Ascii file .TBL",
			      "Making Ascii file .TBL"},
			     {"Erreur d'acc�s en �criture",
			      "Output write error",
			      "Output write error"}
			    };
			      
/*
  ------------------------- Donn�es publiques  ---------------------------
*/

int		ListingScreen;			/* Affiche 1ere passe */
FILE 		*fichier;			/* Fichier source 68705 */
FILE 		*FileLST;			/* source+assembl� */

char		*TamponPRG;
int		TailleTamponPRG;

#define	PATHLONG	256

int		langage;

char		CheminPrm[PATHLONG]="\0",	/* Chemin �ventuels d'�critures */
		CheminTbl[PATHLONG]="\0",
		CheminLst[PATHLONG]="\0";

/*
  ------------------------- Primitives priv�es ---------------------------
*/

static void CreerTBL(FILE *fichier,char *titre)
{
  int i,j;

  fprintf(fichier,"Motorola Assembleur 68705, pour ordinateurs ATARI\n");
  fprintf(fichier,"Version 1.40, Copyright FRANCE 1994-95 par FunShip\n");
  fprintf(fichier,"\nAssemblage du code source %s\n",titre);
  	    
  fprintf(fichier,"\nContenu M�moire d'assemblage: Eprom 2Ko\n");
  fprintf(fichier,"----------------------------------------\n");
  for(i=0;i<128;i++)
  {
    for(j=0;j<16;j++)
      fprintf(fichier,"%2X ",0x00FF & TamponPRG[i*16+j]);
    fprintf(fichier,"\n");
  }      
}/*EndCreerTBL*/

static char *Allouer(size_t TailleTamponPRG)
/*
	Alloue un tampon d'octets initialis�s � 0xFF
	(Contenu d'Eprom vierge)
*/	
{
  char	*Tampon;
  int	i;
  
  Tampon = malloc(TailleTamponPRG);		/* Taille Mem. 68705xx */
  for(i=0;i<TailleTamponPRG;i++)
    Tampon[i] = 0xFF;
  return(Tampon);  
}/*EndAllouer*/

static void CreerPRM(int fichier, int TailleTamponPRG)
/*
	Ecrit dans le fichier le tampon PRG assembl�
*/
{ 
  /*                   0123456701234567012345670123456701234567012345670123456701234567 */
  char	copyright[61]=" Atari  Assemble  6805  FRANCE  1995    par     FunShip\0";
			
  strcpy(TamponPRG,copyright);  
  write(fichier,TamponPRG,TailleTamponPRG); 
}/*EndCreerPRM*/

static void EcrireTitre(FILE *Fichier)
/*
	Ecrit un titre dans le fichier code source+Asm
*/
{
  fprintf(Fichier,"ASSEMBLE 6805                    Compatibles Atari ST\n");
  fprintf(Fichier,"Version 1.40 Copyright (c) France 1994,95 par FunShip\n");
  fprintf(Fichier,"\n");
}/*EndEcrireTitre*/

/*
  ----------------------- Primitive publique ----------------------------------
*/

int Assemble(char *Filename,char *Extension,int Processeur,int ListingOn,int Langue)
{
  char 		FilenameIn[255],		/* Chemin de lecture source */
       		FilenameLST[255],		/* Chemin d'�criture des LST */
       		FilenamePRM[255],		/* Chemin d'�criture des PRM */
       		FilenameTBL[255],		/* Chemin d'�criture des TBL */
       		*Pointeur;
  int		FilePRM;			/* code binaire Eprom */
  FILE		*FileTBL;			/* code ASCII Eprom   */
  int		AnalyseOk,			/* retour de Axiome   */
  		ResolOk,			/* retour resolution  */
  		FichierOk;			/* Erreurs creation fichiers */
  int		retour;				/* Code de retour assemble() */
      
  
  langage = Langue;
  
  EcrireMessage("Assemble-6805          Copyright FRANCE 1994-95");
  EcrireMessage("");
  EcrireMessage( Messages[0][langage]);
  EcrireMessage( Messages[1][langage]);
  
  strcpy(FilenameIn,Filename);
  strcat(FilenameIn,Extension+1);

  if( (fichier = fopen(FilenameIn,"r")) == NULL )
  {
    EcrireMessage("");
    EcrireMessage( Messages[2][langage]);
  }
  else
  {
    if(strlen(CheminLst) != 0)					/* Si chemin LST saisie */
    {
      strcpy(FilenameLST,CheminLst);				/* Copier chemin d'�criture */
      Pointeur = strrchr(Filename,'\\');			/* Rechercher nom fichier */
      strcat(FilenameLST,Pointeur);				/* Le copier ... */
    }
    else							/* Sinon pas de chemin */
      strcpy(FilenameLST,Filename);				/* Prendre celui de source */
    strcat(FilenameLST,".lst");					/* Ajouter le '.lst' */

    if(strlen(CheminPrm) != 0)					/* Si chemin PRM saisie */
    {
      strcpy(FilenamePRM,CheminPrm);				/* Copier chemin d'�criture */
      Pointeur = strrchr(Filename,'\\');			/* Rechercher nom fichier */
      strcat(FilenamePRM,Pointeur);				/* Le copier ... */
    }
    else							/* Sinon pas de chemin */
      strcpy(FilenamePRM,Filename);
    strcat(FilenamePRM,".prm");

    if(strlen(CheminTbl) != 0)					/* Si chemin TBL saisie */
    {
      strcpy(FilenameTBL,CheminTbl);				/* Copier chemin d'�criture */
      Pointeur = strrchr(Filename,'\\');			/* Rechercher nom fichier */
      strcat(FilenameTBL,Pointeur);				/* Le copier ... */
    }
    else							/* Sinon pas de chemin */
      strcpy(FilenameTBL,Filename);
    strcat(FilenameTBL,".tbl");
    
    if( (FileLST = fopen(FilenameLST,"w")) == NULL)
      FichierOk = FALSE;
    else if( (FileTBL = fopen(FilenameTBL,"w")) == NULL)
      FichierOk = FALSE;
    else if( (FilePRM = (int)creat(FilenamePRM,0666)) == -1)
      FichierOk = FALSE;
    else
      FichierOk = TRUE;

    if(FichierOk)
    {
      EcrireTitre(FileLST);  					/* Ecrit quelque infos */
      switch(Processeur)
      {
        case P68705P3:	TailleTamponPRG = 2048;			/* ROM de 2 Ko */
			break;
        case P68705U3: 
        case P68705R3:
			TailleTamponPRG = 4096;			/* ROM de 4 Ko */
			break;
        default:	TailleTamponPRG = 2048;
      }
      ListingScreen   = ListingOn;
      InitKeyWords(Processeur);					/* placer les mots r�serv�s */
      Lexline   = 0L;
      TamponPRG = Allouer(TailleTamponPRG);			/* Alloue et initialise � 0xFF */
    
      EcrireMessage("");
      EcrireMessage( Messages[3][langage]);
    
      symbole  = AnalyseLex();			/* lire premiere unit� lexicale */
      AnalyseOk = Axiome();			/* Analyse syntaxique+g�n�ration */
    
      if(AnalyseOk)				/* Pas d'erreurs...*/
      {
        EcrireMessage("");
        EcrireMessage( Messages[4][langage]);
        ResolOk = ResolutionAdressage();	/* Resolution des @ post-d�finies */
      
        if(ResolOk)
        {
          PrintTable();				/* fichier assembl� <- Tab. Sym. */

          EcrireMessage("");
          EcrireMessage( Messages[5][langage]);
          CreerPRM(FilePRM,TailleTamponPRG);	/* Produit le fichier binaire */
    
          EcrireMessage( Messages[6][langage]);
          CreerTBL(FileTBL,FilenameIn);		/* fichier ASCII code hexa. */
        }
      }
      ViderSymbole();				/* Vider la table des symboles */ 
      fclose(fichier);
      fclose(FileLST);
      fclose(FileTBL);
      close(FilePRM);
    }
    else
    {
      fclose(fichier);
      EcrireMessage("");
      EcrireMessage(Messages[7][langage]);
    }
  }
  
  retour = (AnalyseOk && ResolOk && FichierOk) ? TRUE : FALSE;
  return(retour);
}
/*EndAssemble*/