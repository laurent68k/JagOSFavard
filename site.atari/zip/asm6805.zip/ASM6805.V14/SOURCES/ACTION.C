/*
 *
 *				Assembleur Motorola 6805 Version 1.4
 *				Pour Tout Atari Compatible ST
 *
 * 	Auteur : FunShip
 *	Fichier: Action.C
 *	Date   : 6  Avril 1994
 *	Revision: 07 Octobre 1995
 *	Version : 1.4
 *
 *				Copyright (c) - France 1995
 */

#include <tos.h>
#include <stdio.h>
#include <string.h>
#include "F:\Aads.030\Include\PcAads.h"

/*
 * ---------------------------------------------------------------------------------------
 *			 
 */

#include "Asm6805F.h"			
#include "p68705.h"
#include "Action.h"

/*
 * ---------------------------------------------------------------------------------------
 *			Fonction point d'entr�e de l'assembleur 
 */
 
extern int Assemble(char *SourcePathName,char *Extension,int Processeur,int ListingScreen,int Langue);


/*
 * ---------------------------------------------------------------------------------------
 *			
 */

#define		LOADGO			0
#define		TOS14			0x0104

/*
 * ---------------------------------------------------------------------------------------
 *			
 */

extern	int	WHandle;
extern	char	EditName[];
extern	OBJECT	*Message;					/* Tree's messages */

/*
 * ---------------------------------------------------------------------------------------
 *			
 */

static	char	CheminSource[PATHLONG] ="\0";
static	char	CheminEdit[PATHLONG] ="\0";
		

/*
 * ---------------------------------------------------------------------------------------
 *					Proc�dures
 */

int GetFile(char *FileName)
/*
	Appel le s�lecteur de fichier source.
*/
{
  char	Sauvegarde[PATHLONG],Name[NAMELONG]="\0",Extension[EXTLONG]="*.S\0";

  strcpy(Sauvegarde,FileName);
  if(!A_FileSelector(FileName,Name,Extension,CheminSource,Message[MSG10].ob_spec.free_string))
  {
    strcpy(FileName,Sauvegarde);
    return(FALSE);
  }
  return(TRUE);
}

int GetEdit(void)
{
  char	Sauvegarde[PATHLONG],Name[NAMELONG]="\0",Extension[EXTLONG]="*.*\0";
  
  strcpy(Sauvegarde,EditName);
  strcpy(Name,"");
  A_FileSelector(EditName,Name,Extension,CheminEdit,Message[MSG11].ob_spec.free_string);

  if(strlen(Name) == 0)					/* Rien de s�lectionn� */
  {
    form_alert(1,Message[MSG12].ob_spec.free_string);
    strcpy(EditName,Sauvegarde);  			/* Restaurer ancien �diteur */
    return(FALSE);
  }
  return(TRUE);
}

/*
 * ---------------------------------------------------------------------------------------
 *				Appel respectif de Asm ou Editeur
 */

void Editeur(char *FileName)
/*
	Appel de l'�diteur de texte s�par� avec ou sans un fichier � �diter.
*/
{
  char	OldPath[PATHLONG],NewName[PATHLONG];
  int	OldLecteur;
  char	*Pointeur,envp[1]="\0";

  OldLecteur = Dgetdrv();				/* Lecteur Actuel */
  OldPath[0] = Dgetdrv()+'A';				/* Lettre du lecteur actuel */
  OldPath[1] = ':';
  Dgetpath(OldPath+2,0);				/* Chemin courant */
  
  if(strlen(FileName) != 0)				/* Si un fichier est donn� */
  {
    Pointeur = strrchr(FileName,'\\'); 			/* Set new path */
    if(Pointeur != NULL)
    {
      Dsetdrv(FileName[0]-'A');				/* Fixe le lecteur du source */
      *Pointeur = '\0';
      Dsetpath(FileName);				/* Path is the file's path */
      *Pointeur = '\\';
    }
    else
      Dsetpath("\\");					/* else main root path */

    strcpy(NewName," ");				/* Insert a space before !! */
    Pointeur = strrchr(FileName,'\\');			/* searching last \ */
    strcat(NewName,Pointeur+1);				/* Extraire que le nom fichier */
    Pexec(LOADGO,EditName,NewName,envp);		/* Call editer with file name */
    Dsetdrv(OldLecteur);				/* Fixe l'ancien lecteur */
  }
  else
    Pexec(LOADGO,EditName,envp,envp);			/* Call editer without file name */
    
  Dsetpath(OldPath);					/* Restore previous current path */
}

void CallAsm(char *FileName,int CPUCible)
/*
	Call assemble process with file name and CPU asked.
*/
{
  char	Source[PATHLONG],Extension[EXTLONG],*Pointeur;
  int	AsmLangue;
  
  Pointeur = strrchr(FileName,'.');			/* rechercher l'extension */
  if(Pointeur != NULL)					/* Si existe */
  {
    *Pointeur = '\0';
    strcpy(Extension,"*.");				/* Copier l'extension */
    strcat(Extension,Pointeur+1);
    strcpy(Source,FileName);
    *Pointeur = '.';
  }
  else							/* Pas d'extension */
  {
    strcpy(Extension,"*.");
    strcpy(Source,FileName);
  }
  /*
   *	D�termine la langue � demander � l'assembleur 
   *	(Il soutient Anglais,Allemand & Fran�ais)
   */
  switch(MchInfo.Language)				/* D'apr�s cookie jar */
  {							/* Demande la meme assembleur */
    case LG_F:	AsmLangue = FRANCAIS;			
    		break;
    case LG_D:	AsmLangue = DEUTSCH;
    		break;
    case LG_GB:	AsmLangue = ENGLISH;
    		break;
    default:	AsmLangue = ENGLISH;    		
    		break;
  }
  Assemble(Source,Extension,CPUCible,FALSE,AsmLangue);	
}

/*
 * ---------------------------------------------------------------------------------------
 *				S�lecteur de fichier pour parcourir
 */

static void FselInput(char *Prefix,char *Dummy,int *Bouton,char *Label)
/*
	Appel le s�lecteur de fichiers �tendue si le TOS actuel le permet.
	(TOS >= 1.4)
*/
{
  if(MchInfo.TosVersion < TOS14)
    fsel_input(Prefix,Dummy,Bouton);
  else
    fsel_exinput(Prefix,Dummy,Bouton,Label); 
}

void ParcourPath(char *Chemin,char *Label)
/*	
	Appel le s�lecteur de fichiers pour designer un chemin complet r�pertoire.
	Si un nouveau est valid�, Chemin prend cette valeur, sinon Chemin conserve
	son ancienne valeur.
*/
{
  char	Prefix[PATHLONG],Dummy[14],*Prochain;
  int	Bouton;
    
  strcpy(Prefix,Chemin);				/* Lit le chemin par pass� */
  if(strlen(Prefix) == 0)				/* Si vide */
  {
    Prefix[0] = Dgetdrv()+'A';				/* Disque courant */
    Prefix[1] = ':';
    Dgetpath(Prefix+2,0);				/* Chemin courant */
  }
  strcat(Prefix,"\\*.*");
  strcpy(Dummy,"\0");

  FselInput(Prefix,Dummy,&Bouton,Label);
  if(Bouton)
  {
    Prochain = strrchr(Prefix,'\\');
    *(Prochain) = '\0';				/* Supprimer le \*.* � la fin */
    
    strcpy(Chemin,Prefix);			/* Recopier le nouveau chemin */
  }
}
