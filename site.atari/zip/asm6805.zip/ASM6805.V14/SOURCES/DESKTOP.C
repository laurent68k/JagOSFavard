/*
 *
 *				Assembleur Motorola 6805 Version 1.4
 *				Pour Tout Atari Compatible ST
 *
 * 	Auteur : FunShip
 *	Fichier: Desktop.C
 *	Date   : 6  Avril 1994
 *	Revision: 29 Septembre 1995
 *	Version : 1.4
 *
 *				Copyright (c) - France 1995
 */

#include <stdio.h>
#include <stdlib.h>
#include <tos.h>
#include <string.h>

#include "F:\Aads.030\Include\PcAads.h"

#include "Asm6805F.h"
#include "Action.h"
#include "p68705.h"

#define		RHORIZ			8
#define		RVERT			7

#define		DESKFILE		"Asm6805.inf"


/*
 * ---------------------------------------------------------------------------------------
 *				Variables externes de Assemble.c
 */

extern	char		CheminPrm[],				/* Chemin �ventuels d'�critures */
			CheminTbl[],
			CheminLst[];
extern	OBJECT		*Message;				/* Tree's messages */

/*
 * ---------------------------------------------------------------------------------------
 *				Proc�dure externe de Main.c
 */

extern	void InsertName(char *Name, int Option);

/*
 * ---------------------------------------------------------------------------------------
 *				Variables globales externes
 */

extern	char			EditName[PATHLONG];		/* Editeur ASCII */
extern	char			FileName[PATHLONG];		/* Fichier source asm */
extern	int			CPUCible;			/* Processeur cible */
extern	int			SaveOnExit;
extern	Type_Parameter_Window	*Parameter;			/* Parametre W_Open() */
extern	Type_Bureau_List	Bureau[];			/* Desktop's list */
extern	Type_Parameter_Menu	MainMenu[];			/* Menu's list */

/*
 * ---------------------------------------------------------------------------------------
 *				Programmes Lecture/Ecriture ASM6805.CFG
 */

void Default(void)
/*
	Configuration par d�faut de l'assembleur.
*/
{
  int		DixiemeH,DixiemeV;				/* Dixi�me Vert/Horiz */
  OBJECT	*Arbre;
  TEDINFO	*Ted;
  
  rsrc_gaddr(R_TREE,FSETUP,&Arbre);			/* Adr formulaire FSETUP */
  /*
   *		Configuration de l'assembleur
   */  
  CPUCible = P68705P3;					/* CPU 705P3 */
  strcpy(FileName,"");					/* Pas de fichier source */
  strcpy(EditName,"");					/* Pas d'�diteur */
  SaveOnExit = FALSE;					/* Ne pas sauver Desktop automati. */
  strcpy(CheminPrm,"\0");
  strcpy(CheminTbl,"\0");
  strcpy(CheminLst,"\0");

  Arbre[PROCP3].ob_state = SELECTED;			/* Processeur par d�faut 705P3 */

  Ted=(TEDINFO *) Arbre[PATHPRM].ob_spec.tedinfo;
  strcpy (Ted->te_ptext,CheminPrm);			/* Place le chemin */
  Ted=(TEDINFO *) Arbre[PATHTBL].ob_spec.tedinfo;
  strcpy (Ted->te_ptext,CheminTbl);			/* Place le chemin */
  Ted=(TEDINFO *) Arbre[PATHLST].ob_spec.tedinfo;
  strcpy (Ted->te_ptext,CheminLst);			/* Place le chemin */

  /*
   *		Fenetre
   */
  strcpy(Parameter->titre,FileName);
  strcpy(Parameter->info,"Motorola 68705 P3");
  DixiemeH = (DesktopH-DesktopMenu)/RHORIZ;
  DixiemeV = DesktopW/RVERT;
  Parameter->x = DixiemeV;
  Parameter->y = (DesktopMenu)+(DixiemeH);
  Parameter->w = DesktopW-(2*DixiemeV);
  Parameter->h = DesktopH-DesktopMenu-(2*DixiemeH);

  /*
   *		Cacher les icones Fichier & Editeur
   */
  rsrc_gaddr(R_TREE,BUREAU,&Arbre);			/* Cache l'icone fichier */
  Arbre[IFILE].ob_flags |= HIDETREE;
  Arbre[IEDIT].ob_flags |= HIDETREE;
  MainMenu[5].State = DISABLED;				/* D�sactiver option �diteur menu */
  InsertName(FileName,EDITE);				/* Mettre le noms vides */
  InsertName(FileName,COMPILE);
}

int ReadCFG(void)
/*
	Read if exist the desktop file to set the Source,Editer,CPU,Window's size and
	icons position (and states).
*/
{
  FILE		*Fichier;
  OBJECT	*Arbre;
  TEDINFO	*Ted;
  char		*Pointeur;
    
  if((Fichier = fopen(DESKFILE,"r")) != NULL)
  {
    fscanf(Fichier,"%s\n",FileName);			/* Fichier source */
    if(strcmp(FileName,"nofile") == 0)			/* Si c'est la sentinelle */
      strcpy(FileName,"");				/* Pas de fichier */
    fscanf(Fichier,"%s\n",EditName);			/* Editeur */
    if(strcmp(EditName,"noediter") == 0)		/* Si c'est la sentinelle */
      strcpy(EditName,"");				/* Pas de fichier */
    fscanf(Fichier,"%s\n",CheminPrm);			/* Editeur */
    if(strcmp(CheminPrm,"nopathprm") == 0)		/* Si c'est la sentinelle */
      strcpy(CheminPrm,"");				/* Pas de fichier */
    fscanf(Fichier,"%s\n",CheminTbl);			/* Editeur */
    if(strcmp(CheminTbl,"nopathtbl") == 0)		/* Si c'est la sentinelle */
      strcpy(CheminTbl,"");				/* Pas de fichier */
    fscanf(Fichier,"%s\n",CheminLst);			/* Editeur */
    if(strcmp(CheminLst,"nopathlst") == 0)		/* Si c'est la sentinelle */
      strcpy(CheminLst,"");				/* Pas de fichier */
    fscanf(Fichier,"%d\n",&SaveOnExit);			/* Save desktop at every end */
    fscanf(Fichier,"%d\n",&CPUCible);			/* Cpu cible */
    fscanf(Fichier,"%d\n",&Parameter->x);		/* Window's pos and size */
    fscanf(Fichier,"%d\n",&Parameter->y);
    fscanf(Fichier,"%d\n",&Parameter->w);
    fscanf(Fichier,"%d\n",&Parameter->h);

    /*
     *		Lire la position des icones du desktop
     */
    fscanf(Fichier,"%d\n",&Bureau[0].x);
    fscanf(Fichier,"%d\n",&Bureau[0].y);
    fscanf(Fichier,"%d\n",&Bureau[1].x);
    fscanf(Fichier,"%d\n",&Bureau[1].y);
    fscanf(Fichier,"%d\n",&Bureau[2].x);
    fscanf(Fichier,"%d\n",&Bureau[2].y);
    fscanf(Fichier,"%d\n",&Bureau[3].x);
    fscanf(Fichier,"%d\n",&Bureau[3].y);
    fscanf(Fichier,"%d\n",&Bureau[4].x);
    fscanf(Fichier,"%d\n",&Bureau[4].y);
    fclose(Fichier);

    /*
     *		Calcul si affiche ou non certain icones
     */    
    rsrc_gaddr(R_TREE,BUREAU,&Arbre);			/* Adr arbre bureau  */
    if(strlen(FileName) == 0)				/* Si pas de fichier source */
    {
      Arbre[IFILE].ob_flags |= HIDETREE;		/* Hide icon */
      MainMenu[5].State = DISABLED;			/* D�sactiver option �diteur */
      InsertName(FileName,EDITE);			/* Ecrit du vide */
      InsertName(FileName,COMPILE);
    }
    else						/* Si oui */
    {
      Pointeur = strrchr(FileName,'\\');  		/* Chercher nom fichier */
      strcpy(Bureau[1].Titre,Pointeur+1); 		/* Ecrire nom dans icone */
      InsertName(Pointeur+1,EDITE);			/* Ecrit le nom */
      InsertName(Pointeur+1,COMPILE);
    }
    if(strlen(EditName) == 0)				/* Si pas d'�diteur d�fini */
    {
      Arbre[IEDIT].ob_flags |= HIDETREE;
      MainMenu[5].State = DISABLED;			/* D�sactiver option �diteur */
    }
    
    /*
     *		Calcul suivant type processeur
     */
    strcpy(Parameter->titre,FileName);			/* window setup */
    rsrc_gaddr(R_TREE,FSETUP,&Arbre);			/* Place la coche et nom uP */    
    switch(CPUCible)
    {
      case P68705P3:	strcpy(Parameter->info,Message[MSG3].ob_spec.free_string);
			Arbre[PROCP3].ob_state = SELECTED;
      			break;
      case P68705R3:	strcpy(Parameter->info,Message[MSG4].ob_spec.free_string);
			Arbre[PROCR3].ob_state = SELECTED;
      			break;
      case P68705U3:	strcpy(Parameter->info,Message[MSG5].ob_spec.free_string);
			Arbre[PROCU3].ob_state = SELECTED;
      			break;
      default:		CPUCible = P68705P3;
      			strcpy(Parameter->info,Message[MSG3].ob_spec.free_string);
			Arbre[PROCP3].ob_state = SELECTED;
      			break;
    }

    Ted=(TEDINFO *) Arbre[PATHPRM].ob_spec.tedinfo;
    strcpy (Ted->te_ptext,CheminPrm);			/* Place le chemin */
    Ted=(TEDINFO *) Arbre[PATHTBL].ob_spec.tedinfo;
    strcpy (Ted->te_ptext,CheminTbl);			/* Place le chemin */
    Ted=(TEDINFO *) Arbre[PATHLST].ob_spec.tedinfo;
    strcpy (Ted->te_ptext,CheminLst);			/* Place le chemin */
    return(TRUE);
  }
  else
    return(FALSE);
}

void SaveCFG(void)
/*
	Read from current disk the desktop file.
*/
{
  FILE		*Fichier;
  OBJECT	*Arbre;

  graf_mouse(BUSYBEE,NULL);				/* just for fun */
  
  if((Fichier = fopen(DESKFILE,"w")) != NULL)
  {
    if(strlen(FileName) != 0)				/* Si fichier d�fini */
      fprintf(Fichier,"%s\n",FileName);			/* Fichier source */
    else
      fprintf(Fichier,"nofile\n");			/* Pas de fichier */
    if(strlen(EditName) != 0)				/* Si fichier d�fini */
      fprintf(Fichier,"%s\n",EditName);			/* Fichier source */
    else
      fprintf(Fichier,"noediter\n");			/* Pas d'�diteur d�fini */
    if(strlen(CheminPrm) != 0)				/* Si fichier d�fini */
      fprintf(Fichier,"%s\n",CheminPrm);		/* Fichier source */
    else
      fprintf(Fichier,"nopathprm\n");			/* Pas d'�diteur d�fini */
    if(strlen(CheminTbl) != 0)				/* Si fichier d�fini */
      fprintf(Fichier,"%s\n",CheminTbl);		/* Fichier source */
    else
      fprintf(Fichier,"nopathtbl\n");			/* Pas d'�diteur d�fini */
    if(strlen(CheminLst) != 0)				/* Si fichier d�fini */
      fprintf(Fichier,"%s\n",CheminLst);		/* Fichier source */
    else
      fprintf(Fichier,"nopathlst\n");			/* Pas d'�diteur d�fini */
    fprintf(Fichier,"%d\n",SaveOnExit);			/* Sauver automati. desktop */
    fprintf(Fichier,"%d\n",CPUCible);			/* CPU cible */
    fprintf(Fichier,"%d\n",Parameter->x);		/* Window's pos and size */
    fprintf(Fichier,"%d\n",Parameter->y);
    fprintf(Fichier,"%d\n",Parameter->w);
    fprintf(Fichier,"%d\n",Parameter->h);

    rsrc_gaddr(R_TREE,BUREAU,&Arbre);			/* Cache l'icone fichier */
    fprintf(Fichier,"%d\n",Arbre[IDISK].ob_x);
    fprintf(Fichier,"%d\n",Arbre[IDISK].ob_y);
    fprintf(Fichier,"%d\n",Arbre[IFILE].ob_x);
    fprintf(Fichier,"%d\n",Arbre[IFILE].ob_y);
    fprintf(Fichier,"%d\n",Arbre[IEDIT].ob_x);
    fprintf(Fichier,"%d\n",Arbre[IEDIT].ob_y);
    fprintf(Fichier,"%d\n",Arbre[IASM].ob_x);
    fprintf(Fichier,"%d\n",Arbre[IASM].ob_y);
    fprintf(Fichier,"%d\n",Arbre[ITRASH].ob_x);
    fprintf(Fichier,"%d\n",Arbre[ITRASH].ob_y);

    fclose(Fichier);
  }
  graf_mouse(ARROW,NULL);				/* just for fun */
}
