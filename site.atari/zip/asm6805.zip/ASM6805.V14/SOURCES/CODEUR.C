/*
 *
 *	Primitives de gestion de g�n�rations de codes machines.
 *	Retourne les codes en fonctions des mnemoniques et 
 *	produit le code dans le fichier de sortie.
 *
 * 	Auteur : FAVARD Laurent
 *	Fichier: CODEUR.C
 *	Pays   : FRANCE
 *	Date   : 20 Mars 1994
 *	Revision: 29 Mars 1994
 *	Version : 1.0
 *	Release : 1.0
 *	Machine : ATARI Falcon030 TOS 4.2
 *	Processeur cible: MC68705 P3S (Famille 6805)
 */

#include <stdio.h>
#include <string.h>
#include "assemble.h"
#include "tableasm.h"			/* Tables d'assemblages h�xa.*/
#include "syntaxic.h"

/*
  -------------------------- PRIMITIVES PUBLIQUES -----------------------------

  ----------------- Primitives de calcul des codes machines -------------------
*/

int Inherant(char *instruction,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode inh�rant.
*/
{
  int indice=0;
  int retour;
  
  while(strcmp(TableInherant[indice].Inst,"")!=0 &&
  	strcmp(TableInherant[indice].Inst,instruction)!=0)
    indice++;
  retour = strcmp(TableInherant[indice].Inst,instruction)==0 ? TRUE : FALSE;
  *CodeHexa = TableInherant[indice].CodeMachine;
  return(retour);
}

int Immediat(char *instruction,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode imm�diat.
*/
{
  int indice=0;
  int retour;
  
  while(strcmp(TableImmediat[indice].Inst,"")!=0 &&
  	strcmp(TableImmediat[indice].Inst,instruction)!=0)
    indice++;

  retour = strcmp(TableImmediat[indice].Inst,instruction)==0 ? TRUE : FALSE;
  *CodeHexa = TableImmediat[indice].CodeMachine;
  return(retour);
}

int Direct(char *instruction,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode direct.
*/
{
  int indice=0;
  int retour;
  
  while(strcmp(TableDirect[indice].Inst,"")!=0 &&
  	strcmp(TableDirect[indice].Inst,instruction)!=0)
    indice++;

  retour = strcmp(TableDirect[indice].Inst,instruction)==0 ? TRUE : FALSE;
  *CodeHexa = TableDirect[indice].CodeMachine;
  return(retour);
}

int Etendu(char *instruction,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode �tendu.
*/
{
  int indice=0;
  int retour;
  
  while(strcmp(TableEtendu[indice].Inst,"")!=0 &&
  	strcmp(TableEtendu[indice].Inst,instruction)!=0)
    indice++;

  retour = strcmp(TableEtendu[indice].Inst,instruction)==0 ? TRUE : FALSE;
  *CodeHexa = TableEtendu[indice].CodeMachine;
  return(retour);
}

int Relatif(char *instruction,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode relatif.
*/
{
  int indice=0;
  int retour;
  
  while(strcmp(TableRelatif[indice].Inst,"")!=0 &&
  	strcmp(TableRelatif[indice].Inst,instruction)!=0)
    indice++;

  retour = strcmp(TableRelatif[indice].Inst,instruction)==0 ? TRUE : FALSE;
  *CodeHexa = TableRelatif[indice].CodeMachine;
  return(retour);
}

int BitSetClear(char *hinst,char valeur,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode Bit Set/Clear.
*/
{
  if(strcmp(hinst,"BSET") == 0)
  {
    *CodeHexa = 0x00FF & (0x10 + 2 * valeur);
    return(TRUE);
  }
  else if(strcmp(hinst,"BCLR") == 0)
  {
    *CodeHexa = 0x00FF & (0x11 + 2 * valeur);
    return(TRUE);
  }
  else
    return(FALSE);
}

int Index0(char *instruction,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode index� 0 bits.
*/
{
  int indice=0;
  int retour;
  
  while(strcmp(Table0Index[indice].Inst,"")!=0 &&
  	strcmp(Table0Index[indice].Inst,instruction)!=0)
    indice++;

  retour = strcmp(Table0Index[indice].Inst,instruction)==0 ? TRUE : FALSE;
  *CodeHexa = Table0Index[indice].CodeMachine;
  return(retour);
}

int Index8(char *instruction,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode index� 8 bits.
*/
{
  int indice=0;
  int retour;
  
  while(strcmp(Table8Index[indice].Inst,"")!=0 &&
  	strcmp(Table8Index[indice].Inst,instruction)!=0)
    indice++;

  retour = strcmp(Table8Index[indice].Inst,instruction)==0 ? TRUE : FALSE;
  *CodeHexa = Table8Index[indice].CodeMachine;
  return(retour);
}

int Index16(char *instruction,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode index� 16 bits.
*/
{
  int indice=0;
  int retour;
  
  while(strcmp(Table16Index[indice].Inst,"")!=0 &&
  	strcmp(Table16Index[indice].Inst,instruction)!=0)
    indice++;

  retour = strcmp(Table16Index[indice].Inst,instruction)==0 ? TRUE : FALSE;
  *CodeHexa = Table16Index[indice].CodeMachine;
  return(retour);
}

int BitTestBranch(char *hinst,char valeur,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode Bit Test And Branch.
*/
{
  if(strcmp(hinst,"BRSET") == 0)
  {
    *CodeHexa = 0x00FF & (2 * valeur);
    return(TRUE);
  }
  else if(strcmp(hinst,"BRCLR") == 0)
  {
    *CodeHexa = 0x00FF & (1 + 2 * valeur);
    return(TRUE);
  }
  else
    return(FALSE);
}

/*
  ----------------------- Primitives de production ------------------------
*/

void Coder1(char *texte,int CodeHexa)
/*
	Primitive pour coder une instruction sur UN octet.
*/
{
  fprintf(FileLST,"\tAdr=$%X: $%X\t\t; %s",CompteurAssemblage,CodeHexa,
  				     texte);
  TamponPRG[CompteurAssemblage] = (char)(CodeHexa);  				 
}

void Coder2(char *texte,int CodeHexa,int operande)
/*
	Primitive pour coder une instruction sur DEUX octets
*/
{
  fprintf(FileLST,"\tAdr=$%X: $%X,$%X\t\t; %s",CompteurAssemblage,CodeHexa,
  				 	 operande,texte);
  TamponPRG[CompteurAssemblage]   = (char)(CodeHexa);
  TamponPRG[CompteurAssemblage+1] = (char)(operande);  				
}

void Coder3(char *texte,int CodeHexa,int op1,int op2)
/*
	Primitive pour coder une instruction sur TROIS octets
*/
{
  fprintf(FileLST,"\tAdr=$%X: $%X,$%X,$%X\t; %s",CompteurAssemblage,CodeHexa,
  					     op1,op2,texte);
  TamponPRG[CompteurAssemblage]   = (char)(CodeHexa);
  TamponPRG[CompteurAssemblage+1] = (char)(op1);  				
  TamponPRG[CompteurAssemblage+2] = (char)(op2);
}
