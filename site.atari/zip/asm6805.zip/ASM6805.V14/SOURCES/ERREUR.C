/*
 *
 *	Gestion des erreurs dans les trois langues.
 *	Allemand, Francais et Anglais.
 *
 * 	Auteur : FAVARD Laurent
 *	Fichier: ERREUR.C
 *	Pays   : FRANCE
 *	Date   : 10 Avril 1994
 *	Revision: 11 Avril 1994
 *	Version : 1.0
 *	Release : 0.4
 *	Machine : ATARI Falcon030 TOS 4.2
 *	Processeur cible: MC68705 P3S (Famille 6805)
 */

#include <stdio.h>
#include <tos.h>

#include "lexicale.h"
#include "syntaxic.h"
#include "erreur.h"			/* Pour avoir les constantes d'erreurs */
#include "p68705.h"

#define FRANCAIS	0			/* Langues supportees */
#define DEUTSCH		1
#define ENGLISH		2

extern	int WindHandle;
extern	int langage;

/*
  ------------- Messages d'erreurs standarts lexicales ------------------
*/
static 
char Mess_Lex[6][3][80]={{"Identificateur trop long",			  
			  "Too long identifier",
			  "Too long identifier"},
			 {"Caractere ill�gal rencontr�",
			  "Illegal character found",
			  "Illegal character found"},
			 {"Valeur d�cimale trop grande",
			  "Too large decimal Value",
			  "Too large decimal Value"},
			 {"Valeur hexad�cimale trop grande",
			  "Too large Hexadecimal value",
			  "Too large Hexadecimal value"},
			 {"Valeur binaire trop grande",
			  "Too large binary value",
			  "Too large binary value"},
			 {"Identificateur d�j� d�clar�",
			  "Redeclaration of identifier",
			  "Redeclaration of identifier"}
			};

/*
  ------------ Messages d'erreurs standarts syntaxiques ----------------
*/
static 
char Mess_Syn[10][3][80]={{"Valeur non attendue",
			   "Unexpected value found",
			   "Unexpected value found"},
			  {"Fin de ligne non attendue",
			   "Unexpected end of ligne",
			   "Unexpected end of ligne"},
			  {"Fin de fichier rencontr� sans directive 'End'",
			   "EOF unexpected whitout End keyword",
			   "EOF unexpected whitout End keyword"},
			  {"Instruction non attendue ",
			   "Unexpected intsruction found ",
			   "Unexpected intsruction found "},
			  {"Identificateur non attendu ",
			   "Unexpected identifier found ",
			   "Unexpected identifier found "},
			  {"Texte non attendu: ",
			   "Unexpected texte found: ",
			   "Unexpected texte found: "},
			 };			  

/*
  ------------ Messages d'erreurs standarts s�mantiques ----------------
*/
static 
char Mess_Sem[20][3][80]={{"Identificateur d�j� d�fini",
			   "Redeclaration of identifier",
			   "Redeclaration of identifier"},
			  {"Identificateur non d�fini",
			   "No define indentifier",
			   "No define indentifier"},
			  {"Adressage inh�rant interdit pour",
			   "Not allow inherant adressing mode",
			   "Not allow inherant adressing mode"},
			  {"Adressage imm�diat interdit pour",
			   "Not allow immediat adressing mode",
			   "Not allow immediat adressing mode"},
			  {"Adressage relatif interdit pour",
			   "Not allow relatif adressing mode",
			   "Not allow relatif adressing mode"},
			  {"Adressage direct interdit pour",
			   "Not allow direct adressing mode",
			   "Not allow direct adressing mode"},
			  {"Adressage �tendu interdit pour",
			   "Not allow extend adressing mode",
			   "Not allow extend adressing mode"},
			  {"Adressage index� interdit pour",
			   "Not allow indexed mode",
			   "Not allow indexed mode"},
			  {"Adressage index� nul interdit pour",
			   "Not allow nul indexed mode",
			   "Not allow nul indexed mode"},
			  {"Adressage index� 8 bits interdits pour",
			   "Not allow 8 bits indexed adressing mode",
			   "Not allow 8 bits indexed adressing mode"},
			  {"Adressage index� 16 bits interdits pour",
			   "Not allow 16 bits indexed adressing mode",
			   "Not allow 16 bits indexed adressing mode"},
			  {"Le registre d'index doit etre X",
			   "Index register must be X-Register",
			   "Index register must be X-Register"},
			  {"Adressage Bit Test And Branch interdit pour",
		 	   "Not allow Bit Test And branch adressing mode",
			   "Not allow Bit Test And branch adressing mode"},
			  {"L'op�rande d�passe la taille de 8 bits",
			   "Operand greater than 8 bits size",
			   "Operand greater than 8 bits size"},
			  {"Le d�placement d�passe un octet sign�",
			   "Operand couldn't be a signed byte",
			   "Operand couldn't be a signed byte"},
			  {"Programme trop grand pour le processeur cible",
			   "Too long Program for target processor",
			   "Too long Program for target processor"},
			  {"Le bit sp�cifi� d�passe les valeurs [0,7]",
			   "Specified bit must be beetwen [0,7]",
			   "Specified bit must be beetwen [0,7]"}
		         };

/*
  -------------------- Gestion d'erreurs S�mantique -------------------------
*/

void SEMerreur(int no_erreur,long ligne,char *information)
{
  char	texte1[80],
  	texte2[80];
  
  switch(langage)
  {
    case FRANCAIS:sprintf(texte1,"Erreur s�mantique � la ligne %ld, ",ligne);
    		  sprintf(texte2,"%s %s",Mess_Sem[no_erreur][langage],information);
    		  break;
    case DEUTSCH: sprintf(texte1,"Semantic error at line %ld, ",ligne);
    		  sprintf(texte2,"%s %s",Mess_Sem[no_erreur][langage],information);
    		  break;
    default:	  sprintf(texte1,"Semantic error at line %ld, ",ligne);
    		  sprintf(texte2,"%s %s",Mess_Sem[no_erreur][langage],information);
    		  break;
  }
  EcrireMessage( texte1);
  EcrireMessage( texte2);
}

/*
  ------------------- Gestion d'erreurs Syntaxique --------------------------
*/

void SYNerreur(void)
/*
	Module de gestion d'erreur
*/
{
  char	texte[80];
  
  switch(langage)
  {
    case FRANCAIS: sprintf(texte,"Erreur syntaxique � la ligne %ld",Lexline);
    		   break;
    case DEUTSCH:  sprintf(texte,"Syntaxic error at line %ld",Lexline);
    		   break;
    default:	   sprintf(texte,"Syntaxic error at line %ld",Lexline);
    		   break;    		     	
  }    		
  EcrireMessage( texte);
  
  if(symbole == NB)
  {
    sprintf(texte," %d",Mess_Syn[0][langage],ValLex.numerique);
    EcrireMessage( texte);
  }
  else if(symbole == FDL)
    EcrireMessage( Mess_Syn[1][langage]);
  else if(symbole == FDF)
    EcrireMessage( Mess_Syn[2][langage]);
  else if(symbole == INST)
  {
    sprintf(texte,"%s %s",Mess_Syn[3][langage],ValLex.lexeme);
    EcrireMessage( texte);
  }
  else if(symbole == ID)
  {
    sprintf(texte,"%s %s",Mess_Syn[4][langage],ValLex.lexeme);
    EcrireMessage( texte);
  }
  else
  {
    sprintf(texte,"%s %s",Mess_Syn[5][langage],ValLex.lexeme);
    EcrireMessage( texte);
  }
}

/*
  -------------------- Gestion d'erreurs Lexicales -----------------------
*/

void LEXerreur(int no_erreur)
/*
	Procedure d'affichage des messages standarts d'erreurs pendant
	la phase d'analyse lexicale.
*/
{
  char	texte[80];

  switch(langage)
  {
    case FRANCAIS:sprintf(texte,"Erreur lexicale � la ligne %ld, %s",
    			   Lexline,Mess_Lex[no_erreur][langage]);
    	          break;
    case DEUTSCH: sprintf(texte,"Lexical error at line %ld, %s",
    			   Lexline,Mess_Lex[no_erreur][langage]);
    	          break;
    default:	  sprintf(texte,"Lexical error at line %ld, %s",
    			   Lexline,Mess_Lex[no_erreur][langage]);
    	          break;
    	       
  }    
  EcrireMessage("");
  EcrireMessage( texte);
}
