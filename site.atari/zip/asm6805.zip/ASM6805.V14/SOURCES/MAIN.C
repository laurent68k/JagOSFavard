/*
 *
 *			  Assembleur Motorola 6805 Version 1.4
 *			     Pour Tout Atari Compatible ST
 *
 * 	Author  : FunShip
 *	File    : Main.C
 *	Date    : 6  Avril 1994
 *	Release : 12 Octobre 1995
 *	Version : 1.2
 *	Country : FRANCE
 *			
 *
 *	Note:	Le programme est ex�cutable sur tout Atari, seul le ressource doit
 *		etre adapt� en raison des icones couleurs non support�s par les 
 *		AES inf�rieur au 3.3, soit les TOS < 2.0
 *
 *			  - Copyright Atari FunShip (c) 1995 -
 *	 		     - ATARI ST/STE/TT & Falcon -
 * -----------------------------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <tos.h>
#include <string.h>

#include "F:\Aads.030\Include\PcAads.h"

/*
 * ---------------------------------------------------------------------------------------
 *				Fichiers sp�cifiques � inclure
 */

#include "Asm6805F.h"			
#include "p68705.h"
#include "Action.h"
#include "Desktop.h"

/*
 * ---------------------------------------------------------------------------------------
 *				Defines du programme
 */

#define		VERSNUMBER		"1.40"
#define		VERSDATE		"1610199495"
#define		FILERSC			"Asm6805?.Rsc"

#define		WATTRIBUTS		NAME|FULLER|MOVER|INFO|SIZER|SMALLER

#define		NON_ERROR		0
#define		RSC_ERROR		-1
#define		SCR_ERROR		-2

#define		LargeurMin		639
#define		HauteurMin		399

/*
 * ---------------------------------------------------------------------------------------
 *				Variables externes de Assemble.c
 */

extern char		CheminPrm[],			/* Chemin �ventuels d'�critures */
			CheminTbl[],
			CheminLst[];

/*
 * ---------------------------------------------------------------------------------------
 *				Variables globales publiques
 */

char			EditName[PATHLONG];		/* Editeur ASCII */
char			FileName[PATHLONG];		/* Fichier source asm */
int			CPUCible;			/* Processeur cible */
int			SaveOnExit;			/* Sauvegarder en quittant ? */
Type_Parameter_Window	*Parameter;			/* Parametre W_Open() */

OBJECT			*Message;			/* Tree's messages */

/*
 * ---------------------------------------------------------------------------------------
 *				Variables globales priv�es
 */

 
static	int		Sortir = FALSE;			/* Pour quitter l'appli. */
static	int		WHandle;			/* Handle de la fenetre */
static	int		WHInfo,WHExit,WHSetup;		/* Wind handle formulars */

#define	LIGNEMAX	39				/* Nombre de lignes */
#define	DEBUT		0
static	int		NextLine=DEBUT;			/* Prochaine ligne libre */
static	char		Texte[LIGNEMAX][80];		/* Tampon des messages */

static	int		NombreClicPhoto;		/* Compte clic photo */

/*
 * ---------------------------------------------------------------------------------------
 *			Description de l'interfa�e graphique
 */
 
void	AboutMe(void);
void	Ouvrir(void);
void	Fermer(void);
void	Quitter(void);
void	Compile(void);
void	EditeAvec(void);
void	OpnSetup(void);
void	SlctEdit(void);
void	SaveQuit(void);

Type_Parameter_Menu
MainMenu[]={	
		{APROPOS,INITIAL,AboutMe},			/* A propos... */
		{OFFNEN	,INITIAL,Ouvrir},			/* Ouvrir un fichier */
		{FERMER	,INITIAL,Fermer},			/* Fermer un fichier */
	  	{QUITTE	,INITIAL,Quitter},			/* Quitter ASM6805 */
	  	{COMPILE,INITIAL,Compile},			/* Assemblage */
	  	{EDITE	,INITIAL,EditeAvec},			/* Edite le fichier */
	  	{SETPROC,INITIAL,OpnSetup},			/* Select uP */
	  	{SETEDIT,INITIAL,SlctEdit},			/* Select Editeur */
	  	{SAVQUIT,INITIAL,SaveQuit},			/* Save desktop at end */
	  	{SAVDESK,INITIAL,SaveCFG},			/* Save desktop now */
	  	MENU_END
	   };

/*
 * ---------------------------------------------------------------------------------------
 */

void DbClicIcon(void);
void Move(int typemove,int target);

Type_Bureau_List
Bureau[]=  {	
		{IDISK	,25  ,0,"DISQUES"	,NULL,DbClicIcon,Move,Move},
		{IFILE	,25 ,50,"FICHIER ASM"	,NULL,DbClicIcon,Move,NULL},
		{IEDIT	,25,100,"EDITEUR"	,NULL,DbClicIcon,Move,Move},
		{IASM	,25,150,"ASSEMBLER"	,NULL,DbClicIcon,Move,Move},
		{ITRASH	,25,200,"CORBEILLE"	,NULL,DbClicIcon,Move,Move},
		BUREAU_END
	   };

/*
 * ---------------------------------------------------------------------------------------
 */

void QuitAction(void);

static Type_Form_List
FormExit[]=	{	{CANCEL,QuitAction,NULL},
			{OK,QuitAction,NULL},
			FORM_END
		};

void AboutOk(void);
void PhotoCachee(void);

static Type_Form_List
FormInfo[]=	{	{INFOK,AboutOk,PhotoCachee},
			FORM_END
		};

void Setup(void);
void SetPath(void);

static Type_Form_List
FormSetup[]=	{	{SETOK	,Setup,Setup},
			{PROCP3	,Setup,Setup},
			{PROCR3	,Setup,Setup},
			{PROCU3	,Setup,Setup},
			{PARCPRM,SetPath,NULL},
			{PARCTBL,SetPath,NULL},
			{PARCLST,SetPath,NULL},
			FORM_END
		};


/*
 * ---------------------------------------------------------------------------------------
 *				M�thodes pour les icones
 */

void PhotoCachee(void)
/*
	Called by Double-Clic on Exit button of about me window
*/
{
  OBJECT	*Arbre;
  
  if(NombreClicPhoto == 3)				/* Rendre la photo visible */
  {
      rsrc_gaddr(R_TREE,FINFO,&Arbre);			/* Bit cach� Off */
      Arbre[FUNSHIP].ob_flags &= ~HIDETREE;	
      F_RedrawObject(Arbre,FUNSHIP);			/* Redessiner la photo */
      NombreClicPhoto = 1;
  } 
  else							/* Compter le nombre de DbClics */
    NombreClicPhoto++;
}

void EditeAvec(void);					/* Just a prototype */
void Edite(void);					/* same... */

void DbClicIcon(void)
/*
	Appel� quand un icone est cliqu� ou double-cliqu�.
*/
{  	
  switch(I_Name)
  {
    case IDISK:  	Ouvrir();
    			break;
    case IFILE:		EditeAvec();			/* Edite le fichier ouvert */
  			break;
    case IEDIT:		Edite();
    			break;
    case IASM:		Compile();
    			break;
    case ITRASH:	form_alert(1,Message[MSG1].ob_spec.free_string);
    			break;
    default:		break;    
  }
}

void Move(int Movment,int Target)
{
  switch(Movment)
  {
    case ICON2ICON:	if(I_Name == IFILE && Target == IASM)
    			  Compile();			/* Assemble le fichier */
    			else if(I_Name == IFILE && Target == IEDIT)
    			  EditeAvec();			/* Edite le fichier ouvert */
    			else if(I_Name == IFILE && Target == ITRASH)
    			  Fermer();			/* Ferme le fichier ouvert */
    			else
    			  ;
    			break;
    default:		
    			break;	
  }
}

/*
 * ---------------------------------------------------------------------------------------
 *			M�thodes du Menu Principal et Boites de dialogues
 */

void AboutMe(void)
/*
	Ouvre le formulaire A propos de ...
*/
{
  Type_Formular_Parameter	*Parameter;
  int				Handle;
    
  Parameter = F_GetParameter();
  if(Parameter != NULL)
  {
    Parameter->TreeName = FINFO;
    Parameter->Title	= Message[MSG2].ob_spec.free_string;	/* Formular's title */
    Parameter->Mode	= F_WIND;				/* Opening mode */
    Parameter->FirstEdit= NOTEXT;				/* First Editable Text */
    Parameter->List	= FormInfo;				/* Event list */
    Parameter->FormIcon = IINFO;
    if((Handle = F_XOpen(Parameter)) != FALSE)
    {
      WHInfo = Handle;
      F_WriteText(FINFO,VERSION,VERSNUMBER);
      F_WriteText(FINFO,DATEVER,VERSDATE);
    }
    free(Parameter);
  }
}

void AboutOk(void)
{
  OBJECT	*Arbre;
  
  rsrc_gaddr(R_TREE,FINFO,&Arbre);				/* Tree address */
  Arbre[FUNSHIP].ob_flags |= HIDETREE;				/* Hide photo */
  F_Close(FINFO);
}


void Quitter(void)
/*
	Ouvre le formulaire de demande de quitter
*/
{
  int	Handle;
  
  Handle = F_Open(FEXIT,"",F_WIND,NOTEXT,FormExit);
  if(Handle != FALSE)
    WHExit = Handle;
}

void QuitAction(void)
/*
	Assigne la variable 'Sortir' d'apr�s le choix de l'utilisateur dans le
	formulaire quitter.
*/
{
  Sortir = (F_NameObject == OK) ? TRUE : FALSE;		/* suivant bouton */
  if(Sortir)						/* Si quitter choisi */
  {
    F_Close(FSETUP);					/* Fermer */
    F_Close(FINFO);					/* Fermer */
  }
  F_Close(FEXIT);					/* Fermer toujours ! */
}

void Setup(void)
/*
	Appel� par les objets s�lectables du formulaire SETUP.
	Configure le processeur cible d'assemblage.
*/
{
  /*
   *	Analyse le processeur cible s�lectionn�
   */
  switch(F_NameObject)
  {
    case PROCP3:CPUCible = P68705P3;
		strcpy(Parameter->info,Message[MSG3].ob_spec.free_string);
		F_Select(FSETUP,PROCP3);
		F_UnSelect(FSETUP,PROCR3);
		F_UnSelect(FSETUP,PROCU3);
    		break;
    case PROCR3:CPUCible = P68705R3;
		strcpy(Parameter->info,Message[MSG4].ob_spec.free_string);
		F_UnSelect(FSETUP,PROCP3);
		F_Select(FSETUP,PROCR3);
		F_UnSelect(FSETUP,PROCU3);
    		break;
    case PROCU3:CPUCible = P68705U3;
		strcpy(Parameter->info,Message[MSG5].ob_spec.free_string);
		F_UnSelect(FSETUP,PROCP3);
		F_UnSelect(FSETUP,PROCR3);
		F_Select(FSETUP,PROCU3);
    		break;
    case SETOK:	F_Close(FSETUP);
    		break;
    default:	break;
  }
  wind_set(WHandle,WF_INFO,Parameter->info,0,0);  
  /*
   *	Lecture des chemins d'�critures des fichiers �ventuellement saisies.
   */
  F_ReadText(FSETUP,PATHPRM,CheminPrm);			/* Pour ePRoM */
  F_ReadText(FSETUP,PATHTBL,CheminTbl);			/* Pour TaBLeau ASCII */
  F_ReadText(FSETUP,PATHLST,CheminLst);			/* LiSTing d�buggage */
}

void SetPath(void)
/*
	A partir du fomulaire FSETUP, appel du s�lecteur de fichier pour parcourir.
*/
{
  switch(F_NameObject)
  {
    case PARCPRM:	ParcourPath(CheminPrm,Message[MSG6].ob_spec.free_string);
    			F_WriteText(FSETUP,PATHPRM,CheminPrm);
    			break;
    case PARCTBL:	ParcourPath(CheminTbl,Message[MSG7].ob_spec.free_string);
    			F_WriteText(FSETUP,PATHTBL,CheminTbl);
    			break;
    case PARCLST:	ParcourPath(CheminLst,Message[MSG8].ob_spec.free_string);
    			F_WriteText(FSETUP,PATHLST,CheminLst);
    			break;
    default:		break;
  }
}

void OpnSetup(void)
/*
	Entr� Assembleur du menu Option.
*/
{
  Type_Formular_Parameter	*Parameter;
  int				Handle;
  
  Parameter = F_GetParameter();
  if(Parameter != NULL)
  {
    Parameter->TreeName = FSETUP;
    Parameter->Title	= Message[MSG9].ob_spec.free_string;	/* Formular's title */
    Parameter->Mode	= F_WIND;				/* Opening mode */
    Parameter->FirstEdit= PATHPRM;				/* First Editable Text */
    Parameter->List	= FormSetup;				/* Event list */
    Parameter->FormIcon = ISETUP;
    if((Handle = F_XOpen(Parameter)) != FALSE)
      WHSetup = Handle;
    free(Parameter);
  }
}

void SlctEdit(void)
/*
	Appele la s�lection de l'�diteur de texte
*/
{
  OBJECT	*Arbre;
  
  if(GetEdit())						/* Si un �diteur est choisi */
  {
    rsrc_gaddr(R_TREE,BUREAU,&Arbre);			/* Affiche l'icone fichier */
    Arbre[IEDIT].ob_flags &= ~HIDETREE;
    F_RedrawObject(Arbre,IEDIT);
    if(strlen(FileName) != 0)  				/* Si fichier source d�fini */
      M_Enable(MAINMENU,EDITE);				/* Activer l'option de menu �diteur */
  }
}

void SaveQuit(void)
/*
	S�lectionne ou d�selectionne la sauvegarde automatique du bureau
	(et de la configuration assembleur) � chaque fin du programme.
*/
{
  if(SaveOnExit)					/* Enl�ve ou place un checkmark */
    M_UnChecked(MAINMENU,SAVQUIT);
  else
    M_Checked(MAINMENU,SAVQUIT);
  SaveOnExit = 0x0001 & (~SaveOnExit);			/* Compl�mente SaveOnExit */
}

/*
 * ---------------------------------------------------------------------------------------
 *				Gestion de la fenetre des messages
 */

void WAffiche(int handle)
/*
	Proc�dure d'affichage du contenu du tampon texte.
*/
{
  int Ligne;
  
  W_HomeCursor(handle);
  Ligne = DEBUT;
  while(Ligne < NextLine)
  {
    W_Printf(handle,Texte[Ligne]);
    Ligne++;
  }
}

void WGetxywh(int handle)
/*
	Met � jour le block Parameter de la fenetre au niveau coordon�es et taille,
	Pour la prochainne fermeture/ouverture.
*/
{
  wind_get(handle,WF_CURRXYWH,&Parameter->x,&Parameter->y,&Parameter->w,&Parameter->h);
}

void EcrireMessage(char *message)
/*
	Ecrit un message sur la fenetre resultat.
*/
{
  if( NextLine < LIGNEMAX)
  {
    strcpy(Texte[NextLine++], message);
  }
  else
  {
    W_ClrScr(WHandle);
    strcpy(Texte[0], message);
    NextLine = DEBUT;
  } 
  W_Printf(WHandle,message);
}

/*
 * ---------------------------------------------------------------------------------------
 *					Divers
 */

void InsertName(char *Name, int Option)
/*
	Ajoute dans une option 'Option' du menu principal le nom 'Name' entre
	les deux guillemets.
	Attention: Les deux guillemets doivent exister dans le texte du menu !
	tel que < Make "" >
	
	Ex:	Make "" devient Make "Source.S"
*/
{
  OBJECT	*ArbreMenu;
  char		NewTexte[50],*Pointeur;
  int		Indice;
    
  rsrc_gaddr(R_TREE,MAINMENU,&ArbreMenu);
  
  Pointeur = strchr(ArbreMenu[Option].ob_spec.free_string,'"');	/* Premier guillemet */
  *(++Pointeur) = '\0';						
  strcpy(NewTexte,ArbreMenu[Option].ob_spec.free_string);	/* Copier debut texte */
  *Pointeur = '"';
  
  strcat(NewTexte,Name);					/* Ajoute le new text */
  
  for(Indice = 12-(int)strlen(Name);Indice>0;Indice--)		/* Combler avec espaces */
    strcat(NewTexte," ");

  Pointeur = strrchr(ArbreMenu[Option].ob_spec.free_string,'"');/* Dernier guillemet */
  strcat(NewTexte,Pointeur);					/* Ajoute la fin texte */
  menu_text(ArbreMenu,Option,NewTexte);				/* Mettre en place */
}

void Ouvrir(void)
/*
	Appel� par l'entr�e Ouvrir du menu Fichier. Si un fichier est r�ellement ouvert,
	son nom sera �crit dans la barre titre de la fenetre, un icone fichier sera
	affich� ainsi que son nom dans le texte icone.
*/
{
  OBJECT	*Arbre;
  char		*Pointeur;
  
  if(GetFile(FileName))					/* Si un fichier est choisi */
  {
    rsrc_gaddr(R_TREE,BUREAU,&Arbre);			/* Adr Formulaire FSETUP */

    Pointeur = strrchr(FileName,'\\');  		/* Chercher nom fichier */
    strcpy(Arbre[IFILE].ob_spec.iconblk->ib_ptext,Pointeur+1);	/* Ecrire nom dans icone */

    InsertName(Pointeur+1,EDITE);			/* Ajoute nom menu edite */
    InsertName(Pointeur+1,COMPILE);
    
    Arbre[IFILE].ob_flags &= ~HIDETREE;			/* Rendre Visible icone */
    F_RedrawObject(Arbre,IFILE);			/* Redessiner icone */
    
    strcpy(Parameter->titre,FileName);			/* Ecrire son nom dans la fenetre */
    wind_set(WHandle,WF_NAME,Parameter->titre,0,0);

    if(strlen(EditName) != 0)  				/* Si �diteur d�fini */
      M_Enable(MAINMENU,EDITE);				/* Activer l'option de menu �diteur */
  }
}

void Fermer(void)
/*
	Appel� par l'entr�e Fermer du menu Fichier.
*/
{
  OBJECT	*Arbre;
  
  rsrc_gaddr(R_TREE,BUREAU,&Arbre);			/* Cache la icone fichier */
  Arbre[IFILE].ob_flags |= HIDETREE;
  form_dial(FMD_FINISH,0,0,0,0,Arbre[IFILE].ob_x,Arbre[IFILE].ob_y,Arbre[IFILE].ob_width,Arbre[IFILE].ob_height*2);

  strcpy(FileName,"");
  strcpy(Parameter->titre,FileName);
  wind_set(WHandle,WF_NAME,Parameter->titre,0,0);

  InsertName(FileName,EDITE);				/* Mettre le noms vides */
  InsertName(FileName,COMPILE);
  
  M_Disable(MAINMENU,EDITE);				/* D�sactiver l'option de menu �diteur */
}

void Compile(void)
/*
	Appele l'assemblage du fichier source courant. Si il n'existe pas
	assemblage abandonn�e.
*/
{
  graf_mouse(BUSYBEE,NULL);					/* just for fun */
  W_HomeCursor(WHandle);					/* Home Cursor */
  W_ClrScr(WHandle);						/* Clear Screen on window */
  NextLine = DEBUT;						/* Text Tampon at bottom */
  CallAsm(FileName,CPUCible);					/* Assemble... */
  graf_mouse(ARROW,NULL);					/* just for fun */
}

void Edite(void)
/*
	Appele l'�diteur de texte sans param�tre de fichier.
*/
{
  graf_mouse(BUSYBEE,NULL);					/* just for fun */
  M_Close(MAINMENU);
  Editeur("");							/* Sans param�tre */
  M_Open(MAINMENU,MainMenu);
  W_Redraw(WHandle);						/* Redraw window */
  W_Redraw(WHInfo);						/* Redraw window */
  W_Redraw(WHExit);						/* Redraw window */
  W_Redraw(WHSetup);						/* Redraw window */
  graf_mouse(ARROW,NULL);					/* just for fun */
}

void EditeAvec(void)
/*
	Appele l'�diteur de texte avec un fichier � �diter.
*/
{
  graf_mouse(BUSYBEE,NULL);					/* just for fun */
  M_Close(MAINMENU);
  F_Close(FINFO);						/* ils peuvent etrent ouvert ! */
  F_Close(FEXIT);
  F_Close(FSETUP);
  Editeur(FileName);						/* Avec param�tre */
  M_Open(MAINMENU,MainMenu);
  W_Redraw(WHandle);						/* Redraw window */
  graf_mouse(ARROW,NULL);					/* just for fun */
}

/*
 * ---------------------------------------------------------------------------------------
 *				Corps du programme principal
 */

int main(void)
{
  OBJECT	*Arbre;
  
  if(!A_Open(FILERSC))
  {
    form_alert(1,"[1][ | Asm6805?.Rsc not found ][ Ok ]");
    A_Close();
    return(RSC_ERROR);						/* Quit immediatly */
  }
  if(VdiInfo.HauteurStation < HauteurMin || VdiInfo.LargeurStation < LargeurMin)		
  {
    form_alert(1,"[1][ Bad Screen Rezolution | 640 x 400 needed ][ Ok ]");
    A_Close();
    return(SCR_ERROR);
  } 

  W_Init();							/* Init Window  */
  M_Init();							/* Init Menu    */
  F_Init();							/* Init Form    */
  graf_mouse(ARROW,NULL);					/* just for fun */
  W_SetIconApp(IAPPLI);						/* Set Icon Form Appli. */
  
  /*
   *	Calcul l'adresse de l'arbre d'objets des messages en langue actulle.
   */
  rsrc_gaddr(R_TREE,MESSAGES,&Message);

  /*
   *		Calcul de la configuration 
   */
  Parameter = W_GetParameter();					/* Get a block parameter */
  if(!ReadCFG())						/* Doesn't exist desktop */
    Default();

  if(SaveOnExit)						/* Si actif */
    MainMenu[8].State = CHECKED;				/* Place un checkmark */

  /*
   *		Ouverture des �l�ments Menu, Bureau et fenetre
   */
  M_Open(MAINMENU,MainMenu);					/* Create root menu */
  D_Open(BUREAU,Bureau);					/* It's my own Desktop */
    
  Parameter->attributs	= WATTRIBUTS;				/* Window's methods */
  Parameter->op_redraw	= WAffiche;				/* What's displaying... */
  Parameter->op_close	= NULL;					/* Verboten !! */
  Parameter->op_moved	= WGetxywh;				/* */
  Parameter->op_full	= WGetxywh;
  Parameter->op_sized	= WGetxywh;
  Parameter->treename	= IWIND;				/* Icon formular */
  WHandle  = W_Open(Parameter);					/* Opening window */

  rsrc_gaddr(R_TREE,FINFO,&Arbre);				/* Form info tree adr */
  Arbre[FUNSHIP].ob_flags |= HIDETREE;				/* Hide my photo */
  
  /*
   *		Event loop
   */
  Sortir = FALSE;
  do
  {
    A_WaitEvent();						/* Waiting an event	*/
    F_Event();							/* Form Event 		*/
    M_Event();							/* Menu Event		*/
    W_Event();							/* Window Event		*/
  }
  while(!Sortir);

  if(SaveOnExit)						/* If save on exit true */
    SaveCFG();							/* Save current desktop */

  free(Parameter);						/* Lib�re block W_Open  */
  W_Close(WHandle);						/* Ferme la fenetre     */
  F_Close(FINFO);						/* Ferme les formulaires*/
  D_Close();							/* Restore GEM Desktop	*/
  M_Close(MAINMENU);  						/* Close Root Menu	*/
  A_Close();							/* Close Application	*/
  return(NON_ERROR);						/* for the shell 	*/
}

