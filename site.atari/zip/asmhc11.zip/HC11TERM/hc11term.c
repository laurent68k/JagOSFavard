/*
 *	program sous TOS de test du HC11.
 */

#include <stdio.h>
#include <tos.h>
#include <string.h>

#define	DEV_AUX		1
#define	BREAK		0xFF

/*
 *
 */

int SendByte(int byte)
/*
	Send a character if the serial port is ready, and return its status after to send
	this one.
*/
{
	if(Bcostat(DEV_AUX) == -1)
	{
		Bconout(DEV_AUX, byte & 0xFF);
		return 1;
	}
	
	return 0;
}

int GetByte(void)
/*
	Get a character if the serial port is ready or return 0 if not.
*/
{
	int	byte;


	if(Bconstat(DEV_AUX) == -1)
		byte	=	(int)Bconin(DEV_AUX);
	else
		byte	=	0;

	return byte;
}

/*
 *
 */

void SendProgram(char *filename)
{
	int			file;
	char		tampon[2048];
	long		indice, size;

	file	=	open(filename, O_RDONLY);
	if(file > 0)
	{		
		size	=	read(file, tampon + 1L, 1024);
		if(size > 0L)
		{
			tampon[0]	=	0xFF;
			
			printf("\nPress any key when the HC11 will be ready\n");
			Crawcin();

			printf("Transfer in progress...\n");
			for(indice = 0; indice <= size; indice++)
			{
				Bconout(DEV_AUX, tampon[indice] & 0xFF);
			}
			printf("\n%d bytes transfered + BREAK synchronisation\n", (int)(indice));
		}
		else
		{
			printf("This file is empty\n");
		}
	}
	else
	{
		printf("File open error\n");
	}
	close(file);
	printf("Press any key\n");
	Crawcin();
}

void SendBreak(void)
{
	printf("\nSending a break character when hit any key\n");
	Crawcin();
	
	SendByte(BREAK);
}

void Terminal(void)
{
	int	character = 'z';

	printf("\033E\n");
	printf("Each character is send and the HC11 return it to us\n");
	printf("Hit ESC to exit this mode\n\n");

	while(character != 0x1B)
	{
		character	=	GetByte();
		if(character != 0)
		{
			printf("%c", character);
		}
			
		character = (int)Crawio(0xFF);
		if(character != 0)
			SendByte(character);
	}
}

/*
 *
 */

int main(int argc, char **argv)
{
	int		choix = 'a';
	char	filename[256];

	if(argc > 1)
	{
		printf("\033E\n");
		printf("Motorola 68HC11 F1 program loader\n");
		printf("Atari TOS program 04 May 1997\n\n");

		printf("Sending file : %s\n", argv[1]);
		
		strcpy(filename, argv[1]);
		SendProgram(filename);
	}

	while(choix != 'Q' && choix != 'q' && choix != 0x1B)
	{

		printf("\033E\n");
		printf("Motorola 68HC11 F1 program loader\n");
		printf("Atari TOS program 04 May 1997\n\n");

		printf("(S)end a program to 68HC11\n");
		printf("(B)reak send to the 68HC11\n");
		printf("(T)erminal mode\n");
		printf("(Q)uit program or ESC\n\n");

		printf("Enter your choice :");
		choix = (int)Crawcin();
	
		switch(choix)
		{
			case	'S': case 's':
							printf("\nWhat's file ? ");
							scanf("%s",filename);
							SendProgram(filename);
							break;

			case	'B': case 'b':
							SendBreak();
							break;
							
			case	'T': case 't':
			
							Terminal();
							break;
	
			default:		break;
		}
	}

	return 0;
}



