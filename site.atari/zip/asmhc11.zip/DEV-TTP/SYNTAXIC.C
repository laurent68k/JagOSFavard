/*
 * ----------------------------------------------------------------------------------------------
 *			Schema de traduction pour langage d'assemblage general.
 *			(Construit sur une grammaire de type LL(1).)
 *
 *			Universit� de Paris VI, Pierre et Marie Curie (UPMC)
 *
 * 	Auteur 	: 	FAVARD Laurent
 *	Fichier	: 	SYNTAXIC.C
 *	Pays   	: 	FRANCE
 *	Date   	: 	20 Mars 1994
 *	Revision: 	30 Avril 1997
 *	Version : 	2.0
 *	Release : 	2.1
 *	Machine : 	ATARI Falcon030 TOS 4.2
 *
 * ----------------------------------------------------------------------------------------------
 */

#include <stdio.h>					/* Atari system */
#include <stdlib.h>
#include <string.h>

#include "assemble.h"					/* Entete global */
#include "lexicale.h"					/* Interface avec le lexical */
#include "codeur.h"					/* Primitives de production */
#include "tsymbole.h"
#include "erreur.h"
#include "mc68hc11.h"					/* Besoin d'une sp�cificit� */

/* 
 * ----------------------------------------------------------------------------------------------
 * 					Messages
 * ----------------------------------------------------------------------------------------------
 */

#define	PROC_MSG1	"\t; Processor Motorola %s recognized\n"
#define	ERR_OPTPROC	"\t; Processor not supported\0"

/* 
 * ----------------------------------------------------------------------------------------------
 * 					Types definitions
 * ----------------------------------------------------------------------------------------------
 */

typedef struct {					/* Type d'un attribut h�rit� */
		 unsigned long 	valeur;
		 char		lexeme[TAILLE_STRING];
		 int		defini;
	       } Type_Hvaleur;

typedef struct Tposte
	       {
		 unsigned long	Adresse;
		 char		Etiquette[TAILLE_ID];
		 long		Ligne;
		 struct Tposte	*Next;
	       } Type_Poste;

/* 
 * ----------------------------------------------------------------------------------------------
 * 					Publics datas
 * ----------------------------------------------------------------------------------------------
 */

/* Contient l'unit� lexicale courante */
int			symbole;

/* Adresse de d�part de code assembl� par defaut */
unsigned long		CompteurAssemblage	= STARTCODEDEFAULT;

/* Compteur d'assemblage initial et maximum atteind */
unsigned long		StartAdresseAssemblage	= STARTCODEDEFAULT;
unsigned long		MaxAdresseAssemblage	= STARTCODEDEFAULT;

char			TargetProcessor[TAILLE_ID_PROCESSOR];

/*
 *	Definie la syntaxe des instructions Bit set/clear et Bit test and branch
 */

int	ModeEcritureBSC;

#define	ECRITURE_BSC_BTB_6805	1
#define	ECRITURE_BSC_BTB_68HC11	2

/* 
 * ----------------------------------------------------------------------------------------------
 * 					private datas
 * ----------------------------------------------------------------------------------------------
 */

static int  		Exsymbole;			/* Pr�c�dente unit� lexicale  */
static Type_ValLex	ExValLex;			/* Pr�c�dente valeur lexicale */

static Type_Poste	*FileBra,*FileDirect;		/* R�solution des addresses */

/*
 * ----------------------------------------------------------------------------------------------
 *			Prototypes des fonctions de l'analyseur syntaxique
 * ----------------------------------------------------------------------------------------------
 */

int Axiome(void);
static int Def(void);
static int OptProc(void);
static int Code(void);
static int LignInst(void);
static int Adressage(char *hinst);
static int Symbole(void);
static int Complement(char *hinst,Type_Hvaleur *hvaleur);
static int CompSecond(char *hinst,Type_Hvaleur *hvaleur1,Type_Hvaleur *hvaleur2);
static int Term(void);
static int Data(void);
static int DataDesc(void);
static int Suite(int size_data);

/*
 * ----------------------------------------------------------------------------------------------
 *			Primitive pour g�rer les caract�ristiques des processeurs.
 * ----------------------------------------------------------------------------------------------
 */

static int Processor(char *OptionProcesseur, Type_ValLex *ValLex)
{
  if(strcmp(OptionProcesseur, PROCESSOR_6805) == 0)
  {
    strcpy(TargetProcessor, PROCESSOR_6805);
    ModeEcritureBSC = ECRITURE_BSC_BTB_6805;

    fprintf(FileLST, PROC_MSG1, ValLex->lexeme);
    return InitTableAsm(PROCESSOR_6805);
  }
  
  if(strcmp(OptionProcesseur, PROCESSOR_68HC11) == 0)
  {
    strcpy(TargetProcessor, PROCESSOR_68HC11);
    ModeEcritureBSC = ECRITURE_BSC_BTB_68HC11;

    fprintf(FileLST, PROC_MSG1, ValLex->lexeme);
    return InitTableAsm(PROCESSOR_68HC11);
  }
  
  fprintf(FileLST, ERR_OPTPROC);
  return FALSE;    
}

/*
 * ----------------------------------------------------------------------------------------------
 *				Primitives bas niveaux pour l'analyseur
 * ----------------------------------------------------------------------------------------------
 */


static void PrintLexeme(int symbole,Type_ValLex *ValLex)
/*
	Affiche l'unit� lexicale qui vient d'etre accept�.
*/
{
  if(symbole == NB)
    fprintf(FileLST," 0x%lX ",ValLex->numerique);
  else if(symbole == FDL)
    fprintf(FileLST,"\n");
  else if(symbole == ID)
    fprintf(FileLST," %s",ValLex->lexeme);
  else if(symbole == INST)
    fprintf(FileLST,"\t%s ",ValLex->lexeme);
  else 
    fprintf(FileLST," %s ",ValLex->lexeme);
}

static int Accepter(int unitelex)
/*
	Accepte l'unit� lexicale courante et lit la prochainne.
	Ici est r�alis� l'interface avec l'analyseur lexical.
*/
{
  if(symbole == unitelex)
  {
    Exsymbole = symbole;				/* devient pr�c�dent */
    ExValLex.numerique = ValLex.numerique;
    strcpy(ExValLex.lexeme, ValLex.lexeme);
    symbole   = AnalyseLex();				/* prochainne unite lex. */
    if(symbole == LEXERREUR)		return(FALSE); 
    PrintLexeme(Exsymbole,&ExValLex);
  }
  else
  {
    SYNerreur();
    return(FALSE);
  }
  return(TRUE);
}

/*
 * ----------------------------------------------------------------------------------------------
 *	Implantation de l'analyseur syntaxique pre�dictif par descente recursive.
 * ----------------------------------------------------------------------------------------------
 */

static void CalculAttSyn(int symbole,Type_ValLex *valLex,Type_Hvaleur *valeur)
/*
	Calcul le futur attribut h�rit� valeur fonction de l'unit� 
	lexicale pass�e.
	En retour on obtient la valeur num�rique si d�fini
	Sinon le lexeme.
*/
{
  if(symbole == NB)					/* Est un chiffre */			
  {
    valeur->valeur = valLex->numerique;
    valeur->defini = TRUE;
  }
  else if(symbole == ID && EstPresentSymbole(valLex->lexeme))
  {
    valeur->valeur  = ValSymbole(valLex->lexeme);
    valeur->defini  = TRUE;
  }
  else							/* ID non encore d�fini */
  {
    strcpy(valeur->lexeme,valLex->lexeme);		/* Copier �tiquette */
    valeur->defini = FALSE;				/* non d�fini encore */ 
  }
}

static int EstOctet(unsigned long operande)
/*
	Retourne TRUE si la valeur de l'op�rande est sur un octet.
*/
{
  int retour;
  
  retour = (unsigned long)operande == (unsigned long)(0x000000FFL & operande) ? TRUE: FALSE;
  return(retour);
}

static int EstMot(unsigned long operande)
/*
	Retourne TRUE si la valeur de l'op�rande est sur un mot (2 octets).
*/
{
  int retour;
  
  retour = (unsigned long)operande == (unsigned long)(0x0000FFFFL & operande) ? TRUE: FALSE;
  return(retour);
}

static int EstSigneOctet(int operande)
/*
	Retourne TRUE si la valeur de l'op�rande est une valeur 8 bits
	sign�e
*/
{
  int retour;
  
  retour = operande < -128 || operande > 127 ? FALSE : TRUE;
  return(retour);
}

static Type_Poste *Emfiler(Type_Poste *File,unsigned long ComptAsm,long ligne,char *lexeme)
/*
*/
{        		
  Type_Poste	*poste;
  
  poste 	 = malloc(sizeof(Type_Poste));
  poste->Next	 = File;
  poste->Adresse = ComptAsm;
  poste->Ligne   = ligne;
  strcpy(poste->Etiquette,lexeme);
  return(poste);
}

/*
 * ----------------------------------------------------------------------------------------------
 *					 Analyseur Syntaxique
 * ----------------------------------------------------------------------------------------------
 */

int Axiome(void)
{
  /*
  	Initialise les files pour la r�solution des @ssages 
  	post-d�finis: On stocke les valeurs du compteur d'assemblage
  	correspondant aux emplacements d'@ direct/relative non calcul�es
  */
  FileBra    = NULL;
  FileDirect = NULL;
  Lexline    = 0L;
  
  if(!OptProc())			return(FALSE);
  if(!Def()) 				return(FALSE);
  if(!Accepter(TEXT))			return(FALSE);
  if(!Accepter(FDL))			return(FALSE);
  if(!Code())				return(FALSE);
  if(!Term())				return(FALSE);
  return(TRUE);
}

static int OptProc(void)
{
  if(symbole == FDL)
  {
    if(!Accepter(FDL))			return(FALSE);
    return (OptProc());
  }
  
  if(symbole == OPT)
  {
    if(!Accepter(OPT))			return(FALSE);
    if(!Accepter(PARAMDIRECTIVE))	return(FALSE);
    return(Processor(ExValLex.lexeme, &ExValLex));
  }

  SEMerreur(ERR_NOOPT, Lexline, "");
  return FALSE;
}

static int Def(void)
{
  char  etiquette[TAILLE_ID];
    
  if(symbole == ID)
  {
    if(!Accepter(ID))	return(FALSE);	
    if(EstPresentSymbole(ExValLex.lexeme))			/* Ajout ID Table */
    {
      SEMerreur(ERR_DEFINE,Lexline,ExValLex.lexeme);
      return(FALSE);
    }
    else
    {
      AjouterSymbole(ExValLex.lexeme);
      strcpy(etiquette,ExValLex.lexeme);
    }
    if(!Accepter(EQU))	return(FALSE);
    if(!Symbole())	return(FALSE);
    if(Exsymbole == NB)						/* xx equ nb */
      LierSymbole(etiquette,ExValLex.numerique);
    else if(EstPresentSymbole(ExValLex.lexeme))			/* xx equ yy */
      LierSymbole(etiquette,ValSymbole(ExValLex.lexeme));
    else
    {
      SEMerreur(ERR_NODEFINE,Lexline,ExValLex.lexeme); 
      return(FALSE);
    }
    if(!Accepter(FDL))			return(FALSE);
    if(!Def())				return(FALSE);
  }
  else if(symbole == FDL)
  {
    if(!Accepter(FDL))			return(FALSE);
    if(!Def())				return(FALSE);
  }
  else
  {
    /* E-Production */
  }
  return(TRUE);
}

static int Code()
{
  if(symbole == ORG)
  {
    if(!Accepter(ORG))			return(FALSE);
    if(!Symbole())		return(FALSE);
    if(Exsymbole == NB)						/* xx equ nb */
    {
      if(!InitCompteur(ExValLex.numerique))	return(FALSE);
    }
    else if(EstPresentSymbole(ExValLex.lexeme))			/* xx equ yy */
    {
      if(!InitCompteur((unsigned int)ValSymbole(ExValLex.lexeme)))	return(FALSE);
    }
    else
    {
      SEMerreur(ERR_NODEFINE,Lexline,ExValLex.lexeme);			/* L'@ de ORG toto doit etre definie */
      return(FALSE);
    }

    if(!Accepter(FDL))			return(FALSE);
    if(!Code())				return(FALSE);
  }
  else if(symbole == ID)
  {
    if(!Accepter(ID))			return(FALSE);
    if(EstPresentSymbole(ExValLex.lexeme))
    {
      SEMerreur(ERR_DEFINE,Lexline,ExValLex.lexeme);
      return(FALSE);
    }
    else
    {
      AjouterSymbole(ExValLex.lexeme);
      LierSymbole(ExValLex.lexeme, CompteurAssemblage);
    }
    if(!Accepter(DBP))			return(FALSE);
    if(symbole == INST)
    {
      if(!LignInst())			return(FALSE);
      if(!Accepter(FDL))		return(FALSE);
      if(!Code())			return(FALSE);
    }
    else if(symbole == FDL)
    {
      if(!Accepter(FDL))		return(FALSE);
      if(!Code())			return(FALSE);
    }
    else
    {
      SYNerreur();
      return(FALSE);
    }
  }
  else if(symbole == INST)
  {
    if(!LignInst())			return(FALSE);
    if(!Accepter(FDL))			return(FALSE);
    if(!Code())				return(FALSE);
  }
  else if(symbole == FDL)
  {
    if(!Accepter(FDL))			return(FALSE);
    if(!Code())				return(FALSE);
  }
  else
  { 
    /* Vide */
  }
  return(TRUE);
}

static int LignInst()
{
  char instruction[6];
  
  if(!Accepter(INST))			return(FALSE);
  strcpy(instruction,ExValLex.lexeme);			/* Recopie */
  if(!Adressage(instruction))		return(FALSE);
  return(TRUE);
}

static int Adressage(char *hinst)
/*
  Entree: hinst: attribut h�rit� instruction
*/
{
  int					CodeHexa;								/* Recoit le code machine */
  unsigned long	Operande;								/* Recoit op�rande pour l'imm�diat */
  Type_Hvaleur		hvaleur;								/* att. h�rit� */

  /*
   *	ADRESSAGE IMMEDIAT: 8 et 16 bits
   */      
  if(symbole == DIESE)
  {
    if(!Accepter(DIESE))		return(FALSE);
    if(!Symbole())			return(FALSE);

    if(Exsymbole == ID && !EstPresentSymbole(ExValLex.lexeme))
    {
      /* 
         Si Etiquette non definie => Etiquette d'une donnees en partie .DATA
         qui est forcement une adresse sur 16 bits 
      */
      if( Opcode(hinst, MODE_IMMEDIAT16, &CodeHexa))						/* Code existant pour 16 bits ? */
      {
        if(!Coder3("Immediat 16 bits",CodeHexa, 0x00, 0x00))
          return(FALSE);
      }
      else
      {
        SEMerreur(ERR_IMMEDIAT16,Lexline,hinst);
        return(FALSE);
      }
      FileDirect = Emfiler(FileDirect, CompteurAssemblage - 2, Lexline, ExValLex.lexeme);
      return(TRUE);
    } 

    if(Exsymbole == ID)										/* Si ID rechercher la valeur */
      Operande = (unsigned long)ValSymbole(ExValLex.lexeme); 
    else											/* Sinon d�j� disponible */
      Operande = (unsigned long)ExValLex.numerique;

    if(EstOctet(Operande))									/* valeur sur 8 bits */
    {
      if( Opcode(hinst, MODE_IMMEDIAT8, &CodeHexa))						/* Code existant pour 8 bits ? */
      {
        if(!Coder2("Immediat 8 bits", CodeHexa, 0x00FF & (unsigned int)Operande))
          return(FALSE);
      }
      else if( Opcode(hinst, MODE_IMMEDIAT16, &CodeHexa))					/* Code Op existant pour 16 bits ? */
      {
        if(!Coder3("Immediat 16 bits", CodeHexa, 0x00, 0x00FF & (unsigned int)Operande))
          return(FALSE);
      }
      else
      {
	SEMerreur(ERR_IMMEDIAT8,Lexline,hinst);
        return(FALSE);
      }
    }
    else if(EstMot(Operande))									/* valeur sur 16 bits */
    {
      if( Opcode(hinst, MODE_IMMEDIAT16, &CodeHexa))						/* Code existant pour 16 bits ? */
      {
        if(!Coder3("Immediat 16 bits",CodeHexa, (0xFF00 & (unsigned int)Operande) >> 8, 0x00FF & (unsigned int)Operande))
          return(FALSE);
      }
      else
      {
        SEMerreur(ERR_IMMEDIAT16,Lexline,hinst);
        return(FALSE);
      }
    }
    else
    {
      SEMerreur(ERR_DATASUP16,Lexline,"");
      return(FALSE);
    }
  }
  /*
   *	AUTRE MODE D'ADRESSAGE
   */
  else if(symbole == ID || symbole == NB)
  {
    if(!Symbole())			return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&hvaleur);
    if(!Complement(hinst,&hvaleur))	return(FALSE);
  }
  /*
   *	ADRESSAGE INHERANT 
   */
  else							
  {
    /* E-production */
    if(Opcode(hinst, MODE_INHERANT, &CodeHexa))							/* opcode for inherant */
    {
      if(!Coder1("Inherant",CodeHexa))								/* Coder avec 0 op�randes */
      	return FALSE;
    }
    else
    {
      SEMerreur(ERR_INHERANT,Lexline,hinst);		/* mode @ssage interdit */
      return(FALSE);
    }
  }
  return(TRUE);
}

static int Complement(char *hinst,Type_Hvaleur *hvaleur)
/*
  Entr�e: hinst   = Instruction h�rit�
  	  hvaleur = Valeur du premier symbole h�rit�
*/
{
  int		CodeHexa;
  int		Offset;
  Type_Hvaleur 	hvaleur2;									/* att. h�rit� */
        
  if(symbole == VIRG)
  {
    if(!Accepter(VIRG))			return(FALSE);
    if(!Symbole())			return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&hvaleur2);
    if(!CompSecond(hinst,hvaleur,&hvaleur2))	return(FALSE);
  }
  else
  {
    /* E-Production */
    
    /* 
     *		ADRESSAGE RELATIF 
     */
    if( Opcode(hinst, MODE_RELATIF, &CodeHexa))
    {
      if(hvaleur->defini)
      {
        Offset = (unsigned int)(hvaleur->valeur - CompteurAssemblage - 2L);
        if(!EstSigneOctet(Offset))								/* out of range ! */
        {
          SEMerreur(ERR_OFFSET,Lexline,"");
          return(FALSE);
        }
        Offset &= 0x00FF;									/* passage 8 bits */
      }
      else
        Offset = 0x00;
        
      if(!Coder2("Relatif", CodeHexa, Offset))
        return FALSE;
        
      if(!hvaleur->defini)									/* Symbole non d�fini */
      {
        FileBra = Emfiler(FileBra,CompteurAssemblage - 1, Lexline, hvaleur->lexeme);
      }
    }
    else if( Opcode(hinst, MODE_DIRECT, &CodeHexa) || Opcode(hinst, MODE_EXTEND, &CodeHexa) )
    {
      if(hvaleur->defini)
      {
        if((unsigned int)hvaleur->valeur <= (unsigned int)0xFF)	/* Sur 8 bits */
        {
          /* 
           *	ADRESSAGE DIRECT 
           */
	  if( !Opcode(hinst, MODE_DIRECT, &CodeHexa) )
          {
            SEMerreur(ERR_DIRECT,Lexline,hinst);
            return(FALSE);
          }
          if(!Coder2("Direct",CodeHexa, (unsigned int)(0x00FF & hvaleur->valeur)))
            return(FALSE);
        }
        else											/* Sur 16 Bits */
        {
          /* 
           *	ADRESSAGE ETENDU 
           */
	  if( !Opcode(hinst, MODE_EXTEND, &CodeHexa) )
          {
            SEMerreur(ERR_ETENDU,Lexline,hinst);
            return(FALSE);
          }
          if(!Coder3("Extend", CodeHexa, (0xFF00 & (unsigned int)hvaleur->valeur) >> 8, 0x00FF & (unsigned int)hvaleur->valeur
                    )
            )
            return(FALSE);
        }
      }
      else											/* valeur non d�fini */
      {
        /* 
         *	ADRESSAGE ETENDU avec adresse non resolue pour l'instant
         */
        if( !Opcode(hinst, MODE_EXTEND, &CodeHexa) )
        {
          SEMerreur(ERR_ETENDU,Lexline,hinst);
          return(FALSE);
        }
        if(!Coder3("Extend",CodeHexa, 0x00, 0x00))
          return FALSE;
        FileDirect = Emfiler(FileDirect,CompteurAssemblage - 2, Lexline, hvaleur->lexeme);
      }
    }
    else
    {
      SEMerreur(ERR_DIRECT,Lexline,hinst);
      return(FALSE);
    }
  }
  return(TRUE);
}

static int CompSecond(char *hinst,Type_Hvaleur *hvaleur1,Type_Hvaleur *hvaleur2)
{
  int		CodeHexa;
  Type_Hvaleur	valeur3;
  int		Offset;
  Type_Hvaleur	*Exchange;
      
  if(symbole == VIRG)
  {
    if(!Accepter(VIRG))			return(FALSE);
    if(!Symbole())			return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur3);		/* Calcul l'att. synth�tis� */

    if(hvaleur1->defini && hvaleur2->defini)
    { 
      /*	---------------------------------------------------------------------------------- 
       *	BIT TEST AND BRANCH: On appel la function opcode sp�cial au cas ou ce micro calcul
       *	son opcode suivant l'op�rande MASK de bits.
       *
       *	quelque soit la syntaxe:
       *
       *	hvaleur1 = le masque de bits
       *	hvaleur2 = l'adresse de l'operande
       */
      if(OpcodeBITs(hinst, (unsigned int)hvaleur1->valeur, MODE_BTB, &CodeHexa))
      {
        /* Si syntaxe type: Brset PortX, Mask, Rel */
      	if(ModeEcritureBSC == ECRITURE_BSC_BTB_68HC11)
        {
          Exchange = hvaleur1;
          hvaleur1 = hvaleur2;
          hvaleur2 = Exchange;
        }
 
        if(!EstOctet((unsigned int)hvaleur2->valeur))					/* valeur non sur 8 bits */
        {
   	  SEMerreur(ERR_DATASUP8,Lexline,"");
   	  return(FALSE);
   	}
        if(valeur3.defini)								/* @ branch connue */
        {
          /* cas style 6805 => toujours coder sur 3 octets */
          if(ModeEcritureBSC == ECRITURE_BSC_BTB_6805)
            Offset = (unsigned int)(valeur3.valeur - CompteurAssemblage - 3L);
          else
            Offset = HC11btb(hinst, valeur3.valeur, CompteurAssemblage);

          if(!EstSigneOctet(Offset))							/* out of range ! */
          {
            SEMerreur(ERR_OFFSET,Lexline,"");
            return(FALSE);
          }
          Offset &= 0x00FF;								/* passage 8 bits */
        }
        else										/* @ branch inconnue */
          Offset = 0x00;      

        /* ex: brclr ea, mask, relative */         
      	if(ModeEcritureBSC == ECRITURE_BSC_BTB_68HC11)
        {
          if(!Coder4("Bit Test And Branch", CodeHexa, (unsigned int)hvaleur2->valeur, (unsigned int)hvaleur1->valeur, Offset))
            return FALSE;
        }
        /* ex: brclr mask, ea, relative */         
        else
        {
          if(!Coder3("Bit Test And Branch", CodeHexa, (unsigned int)hvaleur2->valeur, Offset))
            return FALSE;
        }

        if(!valeur3.defini)
        {
          FileBra = Emfiler(FileBra,CompteurAssemblage - 1, Lexline, valeur3.lexeme); 
        }
      }
      else
      {
        SEMerreur(ERR_BTB,Lexline,hinst);
        return(FALSE);
      }
    }
    else	/* hvaleur1 ou hvaleur2 non d�fini */
    {
      if(!hvaleur2->defini)      
      {
        SEMerreur(ERR_NODEFINE,Lexline,hvaleur2->lexeme);
        return(FALSE);
      }
      else
      {
        SEMerreur(ERR_NODEFINE,Lexline,hvaleur1->lexeme);
        return(FALSE);
      }
    }
  }
  else
  {
    /* E-Production */
      /*	---------------------------------------------------------------------------------- 
       *	BIT SET/CLEAR: On appel la function opcode sp�cial au cas ou ce micro calcul
       *	son opcode suivant l'operande MASK de bits.
       *
       *	hvaleur1 = le masque de bits
       *	hvaleur2 = l'adresse de l'operande
       */
      if(OpcodeBITs(hinst, (unsigned int)hvaleur1->valeur, MODE_BSC , &CodeHexa))		
      {
        /* Si syntaxe type: Bset PortX, Mask */
      	if(ModeEcritureBSC == ECRITURE_BSC_BTB_68HC11)
        {
          Exchange = hvaleur1;
          hvaleur1 = hvaleur2;
          hvaleur2 = Exchange;
        }
 
        if(!hvaleur1->defini)									/* MASK Doit etre d�fini */ 
        {
          SEMerreur(ERR_NODEFINE,Lexline,hvaleur1->lexeme);					/* L'op�rande doit etre d�finie */    
          return(FALSE);
        }
        
        if(hvaleur2->defini)
        {
          if(!EstOctet((unsigned int)hvaleur2->valeur))						/* valeur non sur 8 bits */
          {
	    SEMerreur(ERR_DATASUP8,Lexline,"");
	    return(FALSE);
	  }

          /* Suivant le processeur, le codage est diff�rent pour la g�n�ration */
          if(ModeEcritureBSC == ECRITURE_BSC_BTB_68HC11)
          {
            if(!Coder3("Bit Set/Clear", CodeHexa, (unsigned int)(0x00FF & hvaleur2->valeur), (unsigned int)(hvaleur1->valeur)))
              return FALSE;
          }
          /* ex: bset mask, porta */
          else
          {
            if(!Coder2("Bit Set/Clear",CodeHexa,(unsigned int)(0x00FF & hvaleur2->valeur)))
              return FALSE;
          }
        }
        else
        {
          SEMerreur(ERR_NODEFINE,Lexline,hvaleur2->lexeme);	/* L'op�rande doit etre d�finie */
          return(FALSE);
        }
      }
      /*	---------------------------------------------------------------------------------- 
       *	MODE INDEX 0, 8 et 16 Bits:
       *	hvaleur1->valeur Contient le deplacement (l'offset)
       *	hvaleur2->lexeme Contient le registre d'index
       */
      else if(	OpcodeINDEX(hinst, MODE_INDEX_NULL, hvaleur2->lexeme, &CodeHexa) ||       	 
      		OpcodeINDEX(hinst, MODE_INDEX_8, hvaleur2->lexeme, &CodeHexa) ||    
      		OpcodeINDEX(hinst, MODE_INDEX_16, hvaleur2->lexeme, &CodeHexa) )
      {
      	
        if(!hvaleur1->defini)					/* MASK Doit etre d�fini */ 
        {
          SEMerreur(ERR_NODEFINE,Lexline,hvaleur1->lexeme);	/* L'op�rande doit etre d�finie */    
          return(FALSE);
        }
        
        /* IDEXED WITH OFFSET NULL */
        if(hvaleur1->valeur == 0x00)
        {
          /* Si existe indexed null with this register */
	  if(OpcodeINDEX(hinst, MODE_INDEX_NULL, hvaleur2->lexeme, &CodeHexa))
	  {
            if(!Coder1("Indexed NULL",CodeHexa))
              return FALSE;                
          }
          /*	Pas d'opcode pour l'indexed null => Essayer l'indexed 8 bits malgr� le 0 offset */
          else if(OpcodeINDEX(hinst, MODE_INDEX_8, hvaleur2->lexeme, &CodeHexa))          
	  {
            if(!Coder2("Indexed 8 bits",CodeHexa,0x00))
              return FALSE;
          }
          else
          {
            SEMerreur(ERR_INDEX0,Lexline,hinst);		/* Index nul interdit */
            return(FALSE);
          }
        }
	/* INDEXED WITH OFFSET 8 bits */
        else if(EstOctet((unsigned int)hvaleur1->valeur))	
        {
	  if(OpcodeINDEX(hinst, MODE_INDEX_8, hvaleur2->lexeme, &CodeHexa))          
	  {
            if(!Coder2("Indexed 8 bits",CodeHexa, (unsigned int)(0x00FF & hvaleur1->valeur)))
              return FALSE;
          }
          else
          {
            SEMerreur(ERR_INDEX8,Lexline,hinst);		/* Index 8 bits interdit */
            return(FALSE);
          }
        }
        /* INDEXED WITH OFFSET 16 bits */
        else							
        {           
	  if(OpcodeINDEX(hinst, MODE_INDEX_16, hvaleur2->lexeme, &CodeHexa))
          {
            if(!Coder3("Indexed 16 bits",CodeHexa, (unsigned int)((0xFF00 & hvaleur1->valeur) >> 8), (unsigned int)(0x00FF & hvaleur1->valeur)))
              return FALSE;
          }
          else
          {
            SEMerreur(ERR_INDEX16,Lexline,hinst);		/* Index 16 bits interdit */
            return(FALSE);
          }
        }          
      }
      else							/* Modes interdits */
      {
        SEMerreur(ERR_INDEX,Lexline,hinst);
        return(FALSE);
      }
  }
  return(TRUE);
}

static int Term()
{
  if(symbole == DATA)
  {
    if(!Accepter(DATA))			return(FALSE);
    if(!Accepter(FDL))			return(FALSE);
    if(!Data())				return(FALSE);
    if(!Accepter(END))			return(FALSE);
  }
  else if(symbole == END)
  {
    if(!Accepter(END))			return(FALSE);
  }
  else
  {
    SYNerreur();
    return(FALSE);
  }
  return(TRUE);
}

static int Data()
{
  /* 
   *	Definitions directive ORG xx
   */
  if(symbole == ORG)
  {
    if(!Accepter(ORG))			return(FALSE);
    if(!Symbole())		return(FALSE);

    if(Exsymbole == NB)						/* xx equ nb */
    {
      if(!InitCompteur(ExValLex.numerique))	return(FALSE);
    }
    else if(EstPresentSymbole(ExValLex.lexeme))			/* xx equ yy */
    {
      if(!InitCompteur((unsigned int)ValSymbole(ExValLex.lexeme)))	return(FALSE);
    }
    else
    {
      SEMerreur(ERR_NODEFINE,Lexline,ExValLex.lexeme);			/* L'@ de ORG toto doit etre definie */
      return(FALSE);
    }

    if(!Accepter(FDL))			return(FALSE);
    if(!Data())				return(FALSE);
  }
  /* 
   *	IDENTIFICATEUR de donnees TOUT TYPES
   */
  else if(symbole == ID)
  {
    if(!Accepter(ID))			return(FALSE);
    if(EstPresentSymbole(ExValLex.lexeme))			/* Ajout ID Table */
    {
      SEMerreur(ERR_DEFINE,Lexline,ExValLex.lexeme);
      return(FALSE);
    }
    else
    {
      AjouterSymbole(ExValLex.lexeme);
      LierSymbole(ExValLex.lexeme, CompteurAssemblage);
    }
    if(!Accepter(DBP))			return(FALSE);
    if(!DataDesc())			return(FALSE);
    if(!Accepter(FDL))			return(FALSE);
    if(!Data())				return(FALSE);
  }
  /* 
   *	Definitions de donnees TYPE BYTES (dcb, dsb) SANS IDENTIFICATEUR
   */
  else if(symbole == DCB || symbole == DSB)
  {
    if(!DataDesc())			return(FALSE);
    if(!Accepter(FDL))			return(FALSE);
    if(!Data())				return(FALSE);
  }
  else if(symbole == FDL)
  {
    if(!Accepter(FDL))			return(FALSE);
    if(!Data())				return(FALSE);
  }
  else
  {
    /* Vide */
  }
  return(TRUE);
}

static int DataDesc()
/*
	Analyse et assemble les donnees de la section .DATA
	Elle comprend:	dcb, dcw, dsb, dsw et les chaines pour dcb
*/
{
  Type_Hvaleur valeur;

  /*
   *	Definitions de donnees constantes BYTES
   */
  if(symbole == DCB)									/* x: dcb 1,2,3[,n...] */
  {  
    if(!Accepter(DCB))			return(FALSE);
    if(symbole == ID || symbole == NB)							/* */
    {
      if(!Symbole())			return(FALSE);
      CalculAttSyn(Exsymbole,&ExValLex,&valeur);					/* Calcul l'att. synth�tis� */
      if(!valeur.defini)								/* Doit etre d�fini ! */
      {
        SEMerreur(ERR_NODEFINE,Lexline,valeur.lexeme);
        return(FALSE);
      }
      if(!Coder1("", (unsigned int)(valeur.valeur & 0x00FF)))
        return FALSE;
      if(!Suite(SIZE_8_BITS))			return(FALSE);
    }
    else if(symbole == STRING)
    {
      if(!Accepter(STRING))		return(FALSE);
      if(!CoderString(ExValLex.lexeme, C_STRING))	return(FALSE);			/* Coder la chaine */
    }
    else
    {
      SYNerreur();
      return(FALSE);
    }
  }
  /*
   *	Definitions d'une zone de donnees constantes BYTES
   */
  else if(symbole == DSB)								/* x: dsb 5 ; 5 octets */
  {
    if(!Accepter(DSB))			return(FALSE);
    if(!Symbole())			return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur);
    if(!valeur.defini)									/* Doit etre d�fini */
    {
      SEMerreur(ERR_NODEFINE,Lexline,valeur.lexeme);
      return(FALSE);
    }
    AvancerCompteur(valeur.valeur & 0x00FF);						/* On r�serve en fait n octets */
  }
  /*
   *	Definitions de donnees constantes WORDS
   */
  else if(symbole == DCW)								/* x: dcb 1,2,3[,n...] */
  {  
    if(!Accepter(DCW))			return(FALSE);
    if(!Symbole())			return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur);						/* Calcul l'att. synth�tis� */
    if(!valeur.defini)									/* Doit etre d�fini ! */
    {
      SEMerreur(ERR_NODEFINE,Lexline,valeur.lexeme);
      return(FALSE);
    }
    if(!Coder2("", (unsigned int)(valeur.valeur >> 8), (unsigned int)(valeur.valeur & 0x00FF)))
      return FALSE;
    if(!Suite(SIZE_16_BITS))			return(FALSE);
  }
  /*
   *	Definitions d'une zone de donnees constantes WORDS
   */
  else if(symbole == DSW)								/* x: dsw 5 ; 10 octets */
  {
    if(!Accepter(DSW))			return(FALSE);
    if(!Symbole())			return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur);
    if(!valeur.defini)									/* Doit etre d�fini */
    {
      SEMerreur(ERR_NODEFINE,Lexline,valeur.lexeme);
      return(FALSE);
    }
    AvancerCompteur( 2 * valeur.valeur);						/* On r�serve en fait 2*n octets */
  }
  else											/* Erreur */
  {
    SYNerreur();
    return(FALSE);
  }
  return(TRUE);
}

static int Suite(int size_data)
/*
	Code les valeurs numeriques ecrites dans les directives dcb, dcw
	En 8 ou 16 bits 
*/
{
  Type_Hvaleur valeur;
  
  if(symbole == VIRG)
  {
    if(!Accepter(VIRG))			return(FALSE);
    if(!Symbole())			return(FALSE);
    CalculAttSyn(Exsymbole,&ExValLex,&valeur);						/* Calcul l'att. synth�tis� */
    if(!valeur.defini)									/* Doit etre d�fini ! */
    {
      SEMerreur(ERR_NODEFINE,Lexline,valeur.lexeme);
      return(FALSE);
    }

    /*
     *	Selon la taille des donnees a coder (selon dcb, dcw)
     */
    if(size_data == SIZE_8_BITS)
    {
      if(!Coder1("", (unsigned int)valeur.valeur))
        return FALSE;									/* Un octet de plus */
      if(!Suite(SIZE_8_BITS))		return(FALSE);
    }
    else if(size_data == SIZE_16_BITS)
    {
      if(!Coder2("", (unsigned int)(valeur.valeur >> 8), (unsigned int)(valeur.valeur & 0x00FF)))
        return FALSE;									/* Un octet de plus */
      if(!Suite(SIZE_16_BITS))		return(FALSE);
    }
    else
    {
      SEMerreur(ERR_TOOLONGDATA,Lexline,valeur.lexeme);
      return(FALSE);
    }
  }
  else
  {
    /* E-Production */
  }
  return(TRUE);
}

static int Symbole()
/*
	Identifie un symbole qui peut etre une valeur num�rique NB ou
	un identificateur ID.
*/
{
  if(symbole == ID)
  {
    if(!Accepter(ID))			
      return(FALSE);
  }
  else if(symbole == NB)
  {
    if(!Accepter(NB))
      return(FALSE);
  }
  else
  {
    SYNerreur();
    return(FALSE);
  }
  return(TRUE);
}

/*
 * ----------------------------------------------------------------------------------------------
 * 					Traitements deuxi�me passe
 * ----------------------------------------------------------------------------------------------
 */

int ResolutionAdressage(void)
/*
	Parcour des listes des adresses fautives Relatives et Directes
	et remplace les valeurs non calcul�es par les valeurs rang�es
	dans la table des symboles.
*/
{
  Type_Poste	*pointeur;
  int		Offset;
    
  pointeur = FileBra;									/* @ relative UN octet */
  while(pointeur!=NULL)
  {
    if(EstPresentSymbole(pointeur->Etiquette))
    {
      
      Offset = (unsigned int)(ValSymbole(pointeur->Etiquette) - (pointeur->Adresse - 1L) - 2L);
      if(Offset < -128 || Offset > 127)							/* out of range ! */
      {
        SEMerreur(ERR_OFFSET,pointeur->Ligne,pointeur->Etiquette);
        return(FALSE);
      }
      Offset &= 0x00FF;									/* passage 8 bits */
      TamponPRG[pointeur->Adresse] = (char)Offset;
    }
    else
    {
      SEMerreur(ERR_NODEFINE,pointeur->Ligne,pointeur->Etiquette);
      return(FALSE);
    }
    pointeur = pointeur->Next;
    free(FileBra);
    FileBra  = pointeur;
  }
  
  pointeur = FileDirect;								/* @ directe DEUX octets */
  while(pointeur!=NULL)
  {
    if(EstPresentSymbole(pointeur->Etiquette))
    {
      TamponPRG[pointeur->Adresse]   = (char)((0xFF00 & (unsigned)ValSymbole(pointeur->Etiquette)) >>8);
      TamponPRG[pointeur->Adresse+1] =  (char)(0x00FF & (unsigned)ValSymbole(pointeur->Etiquette));
    }
    else
    {
      SEMerreur(ERR_NODEFINE,pointeur->Ligne,pointeur->Etiquette);
      return(FALSE);
    }
    pointeur = pointeur->Next;
    free(FileDirect);
    FileDirect  = pointeur;
  }
  return(TRUE);
}

