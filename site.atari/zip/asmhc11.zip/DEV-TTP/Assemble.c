/* 
 * ----------------------------------------------------------------------------------------------
 *				Agressive Assembleur Motorola
 *		Main module to call the Motorola Microcomputers Assembler
 *
 *		Universit� de Paris VI, Pierre et Marie Curie (UPMC)
 *
 * 	Auteur : 	FAVARD Laurent
 *	Fichier: 	ASSEMBLE.C
 *	Pays   : 	FRANCE
 *	Date   : 	10 March 1994
 *	Revision: 	05 May 1997
 *	Version : 	1.0
 *	Release : 	2.0
 *	Machine : 	ATARI Falcon030 TOS 4.2
 * ----------------------------------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "platform.h"

#include "assemble.h"
#include "lexicale.h"
#include "syntaxic.h"
#include "tsymbole.h"

/*
 * ----------------------------------------------------------------------------------------------
 */

#define		OPT_CSTRING		"-s"

/*
 * ----------------------------------------------------------------------------------------------
 */

#define		PATHLONG		512
#define		NB_CODE_PAR_LIGNE	16

/*
 * ----------------------------------------------------------------------------------------------
 */

static 
char		Messages[21][80]={	"CAM Assembler for Atari - Version 2.11",
								"Copyright (c) Favard Laurent 1994-97 Release of 05 May 1997\n",
								"File not found",
				     			"Pass 1 - Reading file and making codes",
								"Pass 2 - Resolving undefined post definitions\n",
								"Making EPROM .ROM file",
								"Making ASCII .ASC file",
								"Witre error",
                                "Usage:\tCam.ttp [filename.ext] [-s]",
                                "Where:\t-s = C string compatibility",
                                "C string compatibility active",
                                "Error - Compilation aborted.",
                                "\nFile          : %s",
                                "\nProcessor     : %s",
                                "Start address : 0x%lX",
                                "End address   : 0x%lX",
                                "Code size     : %ld bytes",
                                "\nCompilation complete",
                                "\nProcessor    : %s",
                                "\nROM hexadecimal dump",
                                "----------------------\n"
				 };
			      
/* 
 * ----------------------------------------------------------------------------------------------
 * 					Public datas
 * ----------------------------------------------------------------------------------------------
 */
 
int			ListingScreen;				/* Affiche 1ere passe */
FILE 		*fichier;					/* Fichier source  */
FILE 		*FileLST;					/* source + codes assembled */
char		*TamponPRG;
int			C_STRING;

/*
 * ----------------------------------------------------------------------------------------------
 * 					Tools procedures
 * ----------------------------------------------------------------------------------------------
 */

static char *Allouer(size_t TailleTamponPRG)
/*
	Alloue un tampon d'octets initialis�s � 0xFF (Contenu d'une Eprom vierge reelle)
*/	
{
  char		*Tampon;
  unsigned long	i;
  
  Tampon = malloc(TailleTamponPRG);					/* Taille Memoire  */
  for(i = 0L; i < TailleTamponPRG; i++)
    Tampon[i] = (char)0xFF;
  return(Tampon);  
}/*EndAllouer*/

/*
 * ----------------------------------------------------------------------------------------------
 * 					File procedures
 * ----------------------------------------------------------------------------------------------
 */

static void CreerASC(FILE *fichier,char *titre, unsigned long TailleTamponPRG)
{
  unsigned int i,j;

  fprintf(fichier, "%s\n", Messages[0]);
  fprintf(fichier, "%s\n", Messages[1]);

  fprintf(fichier, Messages[12], titre);

  fprintf(fichier, Messages[18], TargetProcessor);
  fprintf(fichier, "\n");
  fprintf(fichier, Messages[14], StartAdresseAssemblage);
  fprintf(fichier, "\n");
  fprintf(fichier, Messages[16], TailleTamponPRG);
  fprintf(fichier, "\n");
  fprintf(fichier, Messages[19]);
  fprintf(fichier, "\n");
  fprintf(fichier, Messages[20]);

  fprintf(fichier,"      00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n\n");

  for(i = (unsigned int)StartAdresseAssemblage; i <= (unsigned int)((StartAdresseAssemblage + TailleTamponPRG) / NB_CODE_PAR_LIGNE); i++)
  {
    j = 0;
    fprintf(fichier, "%4Xh:",i*NB_CODE_PAR_LIGNE+j); 

    /*	Ecrire les valeurs en hexadecimal */
    for(j = 0; j < NB_CODE_PAR_LIGNE; j++)
      fprintf(fichier,"%2X ",0x00FF & TamponPRG[i*NB_CODE_PAR_LIGNE+j]);

    fprintf(fichier," ");

    /*	Ecrire les valeurs sous forme ASCII */
    for(j = 0; j < NB_CODE_PAR_LIGNE; j++)
    {
      /* Si est un caractere imprimable */
      if( (0x00FF & TamponPRG[i*NB_CODE_PAR_LIGNE+j]) > 32)
        fprintf(fichier,"%c",0x00FF & TamponPRG[i*NB_CODE_PAR_LIGNE+j]);
      else
        fprintf(fichier," ");

    }

    fprintf(fichier,"\n");
  }      
}

static void CreerROM(int fichier, unsigned long TailleTamponPRG)
/*
	Ecrit dans le fichier le tampon PRG assembl� de TailleTamponPRG
*/
{ 
  write(fichier, (char *)(TamponPRG + StartAdresseAssemblage), (unsigned int)TailleTamponPRG);
   
}/*EndCreerPRM*/

static void EcrireTitreLST(void)
/*
	Ecrit un titre dans le fichier code source + Asm
*/
{
  fprintf(FileLST, "%s\n", Messages[0]);
  fprintf(FileLST, "%s\n", Messages[1]);
  fprintf(FileLST, "\n");
  
}/*EndEcrireTitre*/

void EcrireMessage(char	*p_sMessage)
/*
	Ecrit un message sur l'�cran.
*/
{
	fprintf(stdout,"%s\n", p_sMessage);
}

/*
 * ----------------------------------------------------------------------------------------------
 *					Public procedures
 *				Main fonction to call the assembler
 * ----------------------------------------------------------------------------------------------
 */

int Assemble(	char	*FilenameSource,char *FilenameLST,
		char	*FilenameROM, char *FilenameASC, 
		int	ListingOn,
		int	c_string_compatibility)
{
  int		FileROM;					/* code binaire Eprom */
  FILE		*FileASC;					/* code ASCII Eprom   */
  
  int		AnalyseOk,					/* retour de Axiome   */
  		ResolOk,					/* retour resolution  */
  		FichierOk;					/* Erreurs creation fichiers */
  int		retour;						/* Code de retour assemble() */
      
  
  EcrireMessage(Messages[0]);
  EcrireMessage(Messages[1]);
  
  if( (fichier = fopen(FilenameSource,"r")) == NULL )
  {
    EcrireMessage( Messages[2] );
  }
  else
  {
    if( (FileLST = fopen(FilenameLST,"w")) == NULL)
      FichierOk = FALSE;
    else if( (FileASC = fopen(FilenameASC,"w")) == NULL)
      FichierOk = FALSE;
    else if( (FileROM = (int)creat(FilenameROM,0666)) == -1)
      FichierOk = FALSE;
    else
      FichierOk = TRUE;

    if(FichierOk)
    {
      EcrireTitreLST();  					/* Ecrit quelque infos */

      ListingScreen   = ListingOn;
      C_STRING	= c_string_compatibility;
      InitKeyWords();						/* placer les mots r�serv�s */
      Lexline   = 0L;
      
      TamponPRG = Allouer(BUFFER_SIZE);				/* Alloue et initialise � 0xFF */
    
      EcrireMessage( Messages[3]);
    
      symbole  = AnalyseLex();					/* lire premiere unit� lexicale */
      AnalyseOk = Axiome();					/* Analyse syntaxique+g�n�ration */
      if(AnalyseOk)						/* Pas d'erreurs...*/
      {
        EcrireMessage( Messages[4]);
        ResolOk = ResolutionAdressage();			/* Resolution des @ post-d�finies */
      
        if(ResolOk)
        {
          PrintTable();						/* fichier assembl� <- Tab. Sym. */

          EcrireMessage( Messages[5]);
          
	  /* Produit le fichier binaire de la taille du code assembl� */
          CreerROM(FileROM,MaxAdresseAssemblage - StartAdresseAssemblage);
    								
          EcrireMessage( Messages[6]);
          CreerASC(FileASC, FilenameSource, MaxAdresseAssemblage - StartAdresseAssemblage);		/* fichier ASCII code hexa. */
        }
      }
      ViderSymbole();						/* Vider la table des symboles */ 
      
      fclose(fichier);
      fclose(FileLST);
      fclose(FileASC);
      close(FileROM);
    }
    else
    {
      fclose(fichier);
      EcrireMessage(Messages[7]);
    }
  }
  
  retour = (AnalyseOk && ResolOk && FichierOk) ? TRUE : FALSE;
  return(retour);
}
/*EndAssemble*/

/*
 * ----------------------------------------------------------------------------------------------
 * 					Test main program
 * ----------------------------------------------------------------------------------------------
 */

int main(int argc, char *argv[])
/*
	Point d'entree de la version TTP.
*/
{
 	char	FileSource[256], FileLST[256], FileROM[256], FileASC[256];
    char	freestring[100];
	char	*Position;
	int	Retour, c_string_compatibility;

	if(argc < 2)
	{
	  EcrireMessage(Messages[0]);
          EcrireMessage(Messages[1]);

	  EcrireMessage(Messages[8]);
	  EcrireMessage(Messages[9]);
	  WAIT;
	  return -1;
	}
	
	if(argc >= 3)
    	c_string_compatibility = (strcmp(argv[2], OPT_CSTRING) == 0) ? TRUE : FALSE;
    else
		c_string_compatibility = FALSE;

	if(c_string_compatibility)
	{
		EcrireMessage(Messages[10]);
	}

	strcpy(FileSource, argv[1]);	
	
	strcpy(FileLST, FileSource);
	Position = strrchr(FileLST, '.');
	*Position = '\0';
	strcpy(FileROM, FileLST);
	strcpy(FileASC, FileLST);

	strcat(FileLST, ".lst");
	strcat(FileROM, ".rom");
	strcat(FileASC, ".asc");
	
        /*
         *	Point d'appel de l'assembleur...
         */

	Retour = Assemble(	argv[1], FileLST, FileROM, FileASC, 
				FALSE, c_string_compatibility
			 );


	if(Retour)
	{
          sprintf(freestring, Messages[12], FileSource);
	  EcrireMessage(freestring);

          sprintf(freestring, Messages[13], TargetProcessor);
          EcrireMessage(freestring);

          sprintf(freestring, Messages[14], StartAdresseAssemblage);
          EcrireMessage(freestring);

          sprintf(freestring, Messages[15], MaxAdresseAssemblage);
	  EcrireMessage(freestring);

          sprintf(freestring, Messages[16], MaxAdresseAssemblage - StartAdresseAssemblage);
          EcrireMessage(freestring);
          
	  EcrireMessage(Messages[17]);
	}
	else
	{
          sprintf(freestring, Messages[12], FileSource);
	  EcrireMessage(freestring);

	  EcrireMessage(Messages[11]);
	}
	WAIT;
	return 0;
}
