/*
 * ----------------------------------------------------------------------------------------------
 *				GESTION DES SPECIFICTES DU MC 68HC11.
 *		Dans le cas 68HC11, la sp�cificit� n'est li� uniquement au calcul de la
 *		valeur relative de branchement des modes BTB qui est fonction
 *		de la longueur en octets du codages des Brclr Brset.
 *	
 * 	Auteur 	:	FAVARD Laurent
 *	Fichier	:	MC6805.C
 *	Pays   	:	FRANCE
 *	Date   	:	17 October 1994
 *	Revision:	17 October 1996
 *	Version :	1.0
 *	Release :	1.0
 *	Machine :	ATARI Falcon030 TOS 4.2
 * ----------------------------------------------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>

#define	TRUE	1
#define	FALSE	0

/*
 * ----------------------------------------------------------------------------------------------
 * 			Calcul de la valeur relative,  PARTIVULIER 68HC11
 * ----------------------------------------------------------------------------------------------
 */

int HC11btb(char *Instruction, unsigned long AdresseCible, unsigned long CompteurAssemblage)
/*
*/
{
  int	Offset;
  
  if(strcmp(Instruction, "BRCLRY") == 0 || strcmp(Instruction, "BRSETY") == 0)
    Offset = (unsigned int)(AdresseCible - CompteurAssemblage - 5L);
  else
    Offset = (unsigned int)(AdresseCible - CompteurAssemblage - 4L);
  return Offset;  
}

