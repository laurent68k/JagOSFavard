/*
 * ----------------------------------------------------------------------------------------------
 *	Primitives de gestion de generations de codes machines.
 *	Retourne les codes en fonctions des mnemoniques et 
 *	produit le code dans le fichier de sortie.
 *
 * 	Auteur 	:	FAVARD Laurent
 *	Fichier	:	CODEUR.C
 *	Pays   	:	FRANCE
 *	Date   	:	20 March 1994
 *	Revision:	15 November 1996
 *	Version :	1.0
 *	Release :	1.0
 *	Machine :	ATARI Falcon030 TOS 4.2
 * ----------------------------------------------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>

#include "assemble.h"
#include "syntaxic.h"
#include "erreur.h"
#include "lexicale.h"

/*
 *	Processors opcodes supported: List of tables
 */

#include "mc6805.h"				/* Tables d'assemblages hexa. du 6805 */
#include "mc68hc11.h"				/* Tables d'assemblages hexa. du 68HC11 */

/*
 *	Opcodes tables names
 */

#define	TABLEASM_6805		Table6805
#define	TABLEASM_68HC11		Table68HC11


/*	
 *	Pointeur sur la table d'assemblage du processeur cible courant 
 */

Type_CodeMachine	*TableAsm = NULL;

/*
 * ----------------------------------------------------------------------------------------------
 * 				PRIMITIVES PUBLIQUES
 *			Gestion du compteur d'assemblage.
 * ----------------------------------------------------------------------------------------------
 */

#define	MAX(a, b)	(a > b) ?  a : b
#define	MIN(a, b)	(a < b) ?  a : b

int AvancerCompteur(unsigned long addition)
/*
	Avance le compteur d'assemblage de 'addition' octets et
	controle que celui-ci n'exc�de pas la limite autoris�e
	par l'espace m�moire du Tampon d'assemblage.
*/
{
  CompteurAssemblage += addition;
  if(CompteurAssemblage >= BUFFER_SIZE)
  {
    SEMerreur(ERR_CPTASM,Lexline,"");
    return(FALSE);
  }
  MaxAdresseAssemblage = MAX(MaxAdresseAssemblage, CompteurAssemblage);
  return(TRUE);
}

int InitCompteur(unsigned long valeur)
/*
	Initial start address code.
*/
{
  CompteurAssemblage	=	valeur;
  StartAdresseAssemblage=	MIN(StartAdresseAssemblage, valeur);
  MaxAdresseAssemblage	=   	MAX(MaxAdresseAssemblage, CompteurAssemblage);
  if(CompteurAssemblage >= BUFFER_SIZE)
  {
    SEMerreur(ERR_CPTASM,Lexline,"");
    return(FALSE);
  }
  return(TRUE);
}

/*
 * ----------------------------------------------------------------------------------------------
 * 					PRIMITIVES PUBLIQUES
 *			Primitives de calcul des codes machines
 *			Suivant l'instruction et son mode d'adressage
 * ----------------------------------------------------------------------------------------------
 */

int Opcode(char *Instruction, char *Adressage, int *CodeHexa)
/*
	Return TRUE and the opcode into 'CodeHexa', if the 'instruction' 
	for the addressing mode 'Adressage' was found.

*/
{
  int indice = 0;
  int retour;
  
 /*
  *	Tant que non(instruction sentinnelle OU instruction trouv�e)
  */
  while(!(  strcmp(TableAsm[indice].Inst,"") == 0 ||
  	    (
  	      strcmp(TableAsm[indice].Inst, Instruction) == 0 &&
  	      strcmp(TableAsm[indice].ModeAdressage, Adressage) == 0
  	    )
         )
       )
  {
    indice++;
  }
  
  retour = ( strcmp(TableAsm[indice].Inst, Instruction) == 0 && 
  	     strcmp(TableAsm[indice].ModeAdressage, Adressage) == 0 ) ? TRUE : FALSE;
  	     
  *CodeHexa = TableAsm[indice].CodeMachine;
  return(retour);
}

int OpcodeINDEX(char *Instruction, char *Adressage, char *RegIndex, int *CodeHexa)
/*
	Return TRUE and the opcode into 'CodeHexa', if the 'instruction' 
	for the addressing mode 'Adressage' was found with the index 'RegIndex'.

*/
{
  int	indice = 0;
  int	retour;
  char	ModeAdrIndex[20];
  
  strcpy(ModeAdrIndex, Adressage);
  strcat(ModeAdrIndex, "_");
  strcat(ModeAdrIndex, RegIndex);

 /*
  *	Tant que non(instruction sentinnelle OU instruction trouv�e)
  */
  while(!(  strcmp(TableAsm[indice].Inst,"") == 0 ||
  	    (
  	      strcmp(TableAsm[indice].Inst, Instruction) == 0 &&
  	      strcmp(TableAsm[indice].ModeAdressage, ModeAdrIndex) == 0
  	    )
         )
       )
  {
    indice++;
  }
  
  retour = ( strcmp(TableAsm[indice].Inst, Instruction) == 0 && 
  	     strcmp(TableAsm[indice].ModeAdressage, ModeAdrIndex) == 0 ) ? TRUE : FALSE;
  	     
  *CodeHexa = TableAsm[indice].CodeMachine;
  return(retour);
}

int OpcodeBITs(char *Instruction,int Operande, char *Adressage, int *CodeHexa)
/*
	Sp�cial procedure for all extra-opcode addressing mode.
	Return TRUE and the opcode into 'CodeHexa', if the 'instruction' 
	for the addressing mode 'Adressage' was found.

	- Gestion du cas du 68705 pour les instructions sur bits (Test, Branch)
*/
{
  /*
   *	Cas du 68705
   */
  if(strcmp(TargetProcessor, PROCESSOR_6805) == 0)
  {
    /*	Si intruction EXISTE dans Mode BIT SET OR CLEAR */
    if(strcmp(Adressage, MODE_BSC) == 0 && Opcode(Instruction, MODE_BSC, CodeHexa))
    {
      BSC6805(Instruction, Operande, CodeHexa);
      if(Operande < 0 || Operande > 7)
      {
        SEMerreur(ERR_BIT,Lexline,"");			/* n'est pas dans [0,7] */
        return(FALSE);
      }
      return TRUE;
    }
    /*	Si intruction EXISTE dans Mode BIT TEST AND BRANCH */
    else if(strcmp(Adressage, MODE_BTB) == 0 && Opcode(Instruction, MODE_BSC, CodeHexa))
    {
      BTB6805(Instruction, Operande, CodeHexa);
      if(Operande < 0 ||  Operande > 7)
      {
        SEMerreur(ERR_BIT,Lexline,"");		/* n'est pas dans [0,7] */
        return(FALSE);
      }
      return TRUE;
    }
  }
  /*
   *	Sinon appeler la function standard de recherche d'opcode...
   */

  return Opcode(Instruction, Adressage, CodeHexa);
}

int InitTableAsm(char	*Processeur)
/*
	Suivant le processeur pass� en param�tre, TableAsm pointera la table
	des opcodes de celui-ci.
*/
{
  if(strcmp(Processeur, PROCESSOR_6805) == 0)
  {
    TableAsm = TABLEASM_6805;
    return TRUE;
  }
  else if(strcmp(Processeur, PROCESSOR_68HC11) == 0)
  {
    TableAsm = TABLEASM_68HC11;
    return TRUE;
  }
  else
    return FALSE;
}

int EstInst(char *lexeme)
/*
	Retourne TRUE si le lexeme pass� est une instruction appartenant
	au langage d'assemblage du MOTOROLA. Primitive utilis�e par la partie analyse
	lexicale pour identifier une instruction d'un identificateur quelconque.
*/
{
  int indice=0;
  int retour;

  /*	Si la table des instructions est encore vide => FAUX */
  if(TableAsm == NULL)
    return FALSE;
    
  while(!( strcmp(TableAsm[indice].Inst,"") == 0 || strcmp(TableAsm[indice].Inst, lexeme) == 0 ))
  {
    indice++;
  }
  
  retour = (strcmp(TableAsm[indice].Inst, lexeme) == 0 ) ? TRUE : FALSE;
  return(retour);
}


/*
 * ----------------------------------------------------------------------------------------------
 * 					Primitives de production
 * ----------------------------------------------------------------------------------------------
 */

/*
 * ----------------------------------------------------------------------------------------------
 *			Primitive pour coder une instruction sur UN valeur.
 * ----------------------------------------------------------------------------------------------
 */

int Coder1(char *texte,int CodeHexa)
{
  fprintf(FileLST,"\t$%lX: $%X\t\t; %s",CompteurAssemblage,CodeHexa,texte);
  if((CodeHexa & 0xFF00) > 0)			    	/* Si code op sur 16 bits */
  {
    TamponPRG[CompteurAssemblage]   = (char)((CodeHexa & 0xFF00) >> 8);
    TamponPRG[CompteurAssemblage+1] = (char)(CodeHexa & 0x00FF);
    return AvancerCompteur(2);
  }
  else
  {
    TamponPRG[CompteurAssemblage] = (char)(CodeHexa);
    return AvancerCompteur(1);
  }
}

/*
 * ----------------------------------------------------------------------------------------------
 *			Primitive pour coder une instruction sur DEUX valeurs.
 * ----------------------------------------------------------------------------------------------
 */

int Coder2(char *texte,int CodeHexa,int operande)
{
  fprintf(FileLST,"\t$%lX: $%X, $%X\t\t; %s",CompteurAssemblage,CodeHexa,operande,texte);
 
  if((CodeHexa & 0xFF00) > 0)			    	/* Si code op sur 16 bits */
  { 				 
    TamponPRG[CompteurAssemblage]   = (char)((CodeHexa & 0xFF00) >> 8);
    TamponPRG[CompteurAssemblage+1] = (char)(CodeHexa & 0x00FF);
    TamponPRG[CompteurAssemblage+2] = (char)(operande);  				
    return AvancerCompteur(3);
  }
  else
  {
    TamponPRG[CompteurAssemblage]   = (char)(CodeHexa);
    TamponPRG[CompteurAssemblage+1] = (char)(operande);  				
    return AvancerCompteur(2);
 }
}

/*
 * ----------------------------------------------------------------------------------------------
 *			Primitive pour coder une instruction sur TROIS valeurs.
 * ----------------------------------------------------------------------------------------------
 */

int Coder3(char *texte,int CodeHexa,int op1,int op2)
{
  fprintf(FileLST,"\t$%lX: $%X, $%X, $%X\t; %s", CompteurAssemblage, CodeHexa, op1, op2, texte);

  if((CodeHexa & 0xFF00) > 0)			    	/* Si code op sur 16 bits */
  {
    TamponPRG[CompteurAssemblage]   = (char)((CodeHexa & 0xFF00) >> 8);
    TamponPRG[CompteurAssemblage+1] = (char)(CodeHexa & 0x00FF);
    TamponPRG[CompteurAssemblage+2] = (char)(op1);  				
    TamponPRG[CompteurAssemblage+3] = (char)(op2);
    return AvancerCompteur(4);
  }
  else
  {  					     	
    TamponPRG[CompteurAssemblage]   = (char)(CodeHexa);
    TamponPRG[CompteurAssemblage+1] = (char)(op1);  				
    TamponPRG[CompteurAssemblage+2] = (char)(op2);
    return AvancerCompteur(3);
  }

}

/*
 * ----------------------------------------------------------------------------------------------
 *			Primitive pour coder une instruction sur TROIS valeurs.
 * ----------------------------------------------------------------------------------------------
 */

int Coder4(char *texte,int CodeHexa,int op1,int op2, int op3)
{
  fprintf(FileLST,"\t$%lX: $%X, $%X, $%X, $%X\t; %s",	CompteurAssemblage, CodeHexa,
  			     				op1, op2, op3, texte);

  if((CodeHexa & 0xFF00) > 0)			    	/* Si code op sur 16 bits */
  {
    TamponPRG[CompteurAssemblage]   = (char)((CodeHexa & 0xFF00) >> 8);
    TamponPRG[CompteurAssemblage+1] = (char)(CodeHexa & 0x00FF);
    TamponPRG[CompteurAssemblage+2] = (char)(op1);  				
    TamponPRG[CompteurAssemblage+3] = (char)(op2);
    TamponPRG[CompteurAssemblage+4] = (char)(op3);
    return AvancerCompteur(5);
  }
  else
  {  					     	
    TamponPRG[CompteurAssemblage]   = (char)(CodeHexa);
    TamponPRG[CompteurAssemblage+1] = (char)(op1);  				
    TamponPRG[CompteurAssemblage+2] = (char)(op2);
    TamponPRG[CompteurAssemblage+3] = (char)(op3);
    return AvancerCompteur(4);
  }
}

/*
 * ----------------------------------------------------------------------------------------------
 *			Primitive pour coder une chaine de caracteres.
 * ----------------------------------------------------------------------------------------------
 */

int CoderString(char *string, int c_string)
/*
	if c_string = TRUE then a '\0' will added at the string end (C string compatibility) else
	no.
*/
{
  strcpy( (char *)(TamponPRG + CompteurAssemblage), string);
  if(c_string)
  {
    return AvancerCompteur(strlen(string) + 1);
  }
  else
  {
    return AvancerCompteur(strlen(string) );
  }
}

