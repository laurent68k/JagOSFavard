/*
 * ----------------------------------------------------------------------------------------------
 *				GESTION DES SPECIFICTES DU MC 6805.
 *		Dans le cas 6805, la sp�cificit� n'est li� uniquement au calcul des codes op.
 *		de BSET, BCLR, BRSET and BRCLR qui tiennent compte du masque de bits.
 *	
 * 	Auteur 	:	FAVARD Laurent
 *	Fichier	:	MC6805.C
 *	Pays   	:	FRANCE
 *	Date   	:	20 Mars 1994
 *	Revision:	29 septembre 1996
 *	Version :	1.0
 *	Release :	1.1
 *	Machine :	ATARI Falcon030 TOS 4.2
 * ----------------------------------------------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>

#define	TRUE	1
#define	FALSE	0

/*
ERR_OPTPROC
 * ----------------------------------------------------------------------------------------------
 * 			MODE d'ADRESSAGE Bit Set or Clear, PARTIVULIER 6805
 * ----------------------------------------------------------------------------------------------
 */

int BSC6805(char *hinst,int valeur,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode Bit Set/Clear.
*/
{
  if(strcmp(hinst, "BSET") == 0)
  {
    *CodeHexa = 0x00FF & (0x10 + 2 * valeur);
    return(TRUE);
  }
  else if(strcmp(hinst, "BCLR") == 0)
  {
    *CodeHexa = 0x00FF & (0x11 + 2 * valeur);
    return(TRUE);
  }
  else
    return(FALSE);
}

/*
 * ----------------------------------------------------------------------------------------------
 * 			MODE d'ADRESSAGE Bit Test and Branch, PARTIVULIER 6805
 * ----------------------------------------------------------------------------------------------
 */

int BTB6805(char *hinst,int valeur,int *CodeHexa)
/*
	Retourne TRUE si on a trouv� le code machine associ� � 
	l'instruction en mode Bit Test And Branch.
*/
{
  if(strcmp(hinst,"BRSET") == 0)
  {
    *CodeHexa = 0x00FF & (2 * valeur);
    return(TRUE);
  }
  else if(strcmp(hinst,"BRCLR") == 0)
  {
    *CodeHexa = 0x00FF & (1 + 2 * valeur);
    return(TRUE);
  }
  else
    return(FALSE);
}
