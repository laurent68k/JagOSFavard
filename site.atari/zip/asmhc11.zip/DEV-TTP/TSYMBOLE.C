/*
 * ---------------------------------------------------------------------------------------------- 
 *
 *				Primitives de gestion de la table des symboles
 *			Et ajoute des mots clefs correspondants � des labels pr�d�finis
 *
 * 	Auteur : 	FAVARD Laurent
 *	Fichier: 	TSYMBOLE.C
 *	Pays   : 	FRANCE
 *	Date   : 	18 Mars 1994
 *	Revision: 	24 Septembre 1996
 *	Version : 	1.0
 *	Release : 	2.0
 *	Machine : 	ATARI Falcon030 TOS 4.2
 *
 * ---------------------------------------------------------------------------------------------- 
 */

#include <stdio.h>
#include <string.h>

#include "platform.h"
#include "assemble.h"

/*
 * ---------------------------------------------------------------------------------------------- 
 */
 
typedef struct {						/* Type entr�e TableSymbole */
		 char		lexeme[TAILLE_ID];		/* Lexeme associ� */
		 unsigned long	valeur;				/* valeur OU Adresse */
	       } Type_Symbole;

static int		TbSymDebut;				/* D�but des entr�es libres Users */
static int		TbSymIndice=0;				/* Prochainne entr�e libre */
static Type_Symbole	TableSymbole[TAILLETBLSYMBOLE];		/* La Table */

/*
  ----------------------- Primitives priv�es ------------------------------
*/

static int RechercheSymbole(char *lexeme)
/*
	Retourne l'indice dans la table o� se trouve le lexeme.
	ATTENTION, � n'appeler qu'ap�s avoir v�rifier si le lexeme
	�tait bien pr�sent.
*/
{
  int i=0;
  
  while(i<TbSymIndice && strcmp(lexeme,TableSymbole[i].lexeme)!=0)
    i++;
  return(i);
}

/*
  ----------------------- Primitives publiques ------------------------------
*/

void ViderSymbole(void)
{
  TbSymIndice = 0;
}

int EstPresentSymbole(char *lexeme)
/*
	Retourne TRUE si le lexeme est d�j� pr�sent dans la table des
	symboles.
*/
{
  int i=0;
  int retour;
  
  while(i<TbSymIndice && strcmp(lexeme,TableSymbole[i].lexeme)!=0)
    i++;
  retour = strcmp(TableSymbole[i].lexeme,lexeme)==0 && i < TbSymIndice ? TRUE : FALSE;  
  return(retour);
}

void AjouterSymbole(char *lexeme)
/*
	Ajoute le lexeme dans la table des symboles si il n'est pas d�j�
	pr�sent, sinon aucune action.
*/
{
  if(!EstPresentSymbole(lexeme) && TbSymIndice < TAILLETBLSYMBOLE)
    strcpy(TableSymbole[TbSymIndice++].lexeme,lexeme);
}

void LierSymbole(char *lexeme,unsigned long valeur)
/*
	Attache au symbole lexeme la valeur numerique pass�e.
*/
{
  int entree;
  
  entree = RechercheSymbole(lexeme);
  TableSymbole[entree].valeur = valeur;
}

unsigned long ValSymbole(char *lexeme)
/*
	Retourne la valeur num�rique associ�e � l'identificateur
	lexeme rang� dans la table des symboles.
	Attention: L'identificateur DOIT exist� !
*/
{
  return(TableSymbole[RechercheSymbole(lexeme)].valeur);
}

/*
  ----------------------- Primitives particuli�res -------------------
*/

void InitKeyWords(void)
/*
	Ajoute dans la table des symboles, les mots clefs correspondants aux mots r�serv�s pour d�signer les registres plac�s en m�moire
	du Micro-Conrtolleur, tel que PortA, DDRA, etc...
*/
{
  /*	cette ligne est un exemple d'initialisation...(Comme avant pour les 6805):
   *	AjouterSymbole("PORTA"); LierSymbole("PORTA",0x00);
   */

  TbSymDebut = TbSymIndice;		/* D�but entr�es libres */
}

void PrintTable(void)
/*
	Imprime la table des symboles dans le fichier FileOut
*/
{
  int i;
  fprintf(FileLST,"\n\nContents of Symboles table\n");
  fprintf(FileLST,    "--------------------------\n");
  for(i=TbSymDebut;i<TbSymIndice;i++)
  {
    fprintf(FileLST," %s",TableSymbole[i].lexeme);
    fprintf(FileLST,"\t\t$%lX\n",TableSymbole[i].valeur);
  }
}
