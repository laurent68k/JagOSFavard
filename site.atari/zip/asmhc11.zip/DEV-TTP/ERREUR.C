/*
 * ----------------------------------------------------------------------------------------------
 *
 *					Gestion des erreurs.
 *
 * 	Auteur 	: 	FAVARD Laurent
 *	Fichier	: 	ERREUR.C
 *	Pays   	: 	FRANCE
 *	Date   	: 	10 Avril 1994
 *	Revision: 	19 November 1996
 *	Version : 	2.0
 *	Release : 	
 *	Machine :	ATARI Falcon030 TOS 4.2
 * ----------------------------------------------------------------------------------------------
 */

#include <stdio.h>

#include "lexicale.h"
#include "syntaxic.h"
#include "erreur.h"				/* Pour avoir les constantes d'erreurs */

/*
 * ----------------------------------------------------------------------------------------------
 *			Messages d'erreurs standarts lexicales	
 * ----------------------------------------------------------------------------------------------
 */

static 
char Mess_Lex[10][80]={		"Too long identifier",			  
			 	"Illegal character",
				"Too large decimal value",
			 	"Too large hexadecimal value",
			 	"Too large binary value",
			 	"Identifier already declared",
				"Expected quote not found after a character",
				"Too long string",
				"No terminate string"
			};

/*
 * ----------------------------------------------------------------------------------------------
 * 			Messages d'erreurs standarts syntaxiques
 * ----------------------------------------------------------------------------------------------
 */

static 
char Mess_Syn[6][80]={		"No expected value",
			  	"No expected end of line",
			  	"End of file whitout <End> directive",
			  	"No expected instruction: ",
			  	"No expected identifier: ",
			  	"No expected text: "
			 };			  

/*
 * ----------------------------------------------------------------------------------------------
 *			Messages d'erreurs standarts semantiques
 * ----------------------------------------------------------------------------------------------
 */

static 
char Mess_Sem[22][80]={		"Identifier already declared",
			  	"No defined Identifier",
			  	"Adressing mode inherant not allowed for",
			  	"Adressing mode immediat not allowed for",
			  	"Adressing mode relatif not allowed for",
			  	"Adressing mode direct not allowed for",
			  	"Adressing mode extended not allowed for",
			  	"Adressing mode indexed not allowed for",
			  	"Adressing mode indexed null not allowed for",
			  	"Adressing mode indexed 8 bits not allowed for",
			  	"Adressing mode indexed 16 bits not allowed for",
			  	"Illegal specified index register",
			  	"Adressing mode Bit Test And Branch not allowed for",
			  	"Operand extend 16 bits range allowed for",
			  	"Offset must be a signed byte",
			  	"Program exceding ROM size used",
			  	"Specified bit out of range [0,7] values",
			  	"Immediat 8 or 16 bits adressing mode not allowed for",
			  	"Immediat 16 bits adressing mode not allowed for",
			  	"Operand extend 8 bits range allowed for",
			  	"OPT directive to select target processor not found",
			  	"Too long data specified into dcb or dcw directive"
		       };

/*
 * ----------------------------------------------------------------------------------------------
 *				Gestion d'erreurs S�mantique
 * ----------------------------------------------------------------------------------------------
 */

void SEMerreur(int no_erreur,long ligne,char *information)
{
  char	texte1[80],
  	texte2[80];
  
  sprintf(texte1,"Semantic error at line %ld, ",ligne);
  sprintf(texte2,"%s %s",Mess_Sem[no_erreur],information);

  EcrireMessage( texte1);
  EcrireMessage( texte2);
}

/*
 * ----------------------------------------------------------------------------------------------
 *				Gestion d'erreurs Syntaxique
 * ----------------------------------------------------------------------------------------------
 */

void SYNerreur(void)
/*
	Module de gestion d'erreur
*/
{
  char	texte[80];
  
  sprintf(texte,"Syntaxic error at line %ld",Lexline);

  EcrireMessage( texte);
  
  if(symbole == NB)
  {
    sprintf(texte," %d",Mess_Syn[ERR_NOVALUE],ValLex.numerique);
    EcrireMessage( texte);
  }
  else if(symbole == FDL)
    EcrireMessage( Mess_Syn[ERR_NOEOL]);
  else if(symbole == FDF)
    EcrireMessage( Mess_Syn[ERR_NOEND]);
  else if(symbole == INST)
  {
    sprintf(texte,"%s %s",Mess_Syn[ERR_NOINST],ValLex.lexeme);
    EcrireMessage( texte);
  }
  else if(symbole == ID)
  {
    sprintf(texte,"%s %s",Mess_Syn[ERR_NOID],ValLex.lexeme);
    EcrireMessage( texte);
  }
  else
  {
    sprintf(texte,"%s %s",Mess_Syn[ERR_NOTEXT],ValLex.lexeme);
    EcrireMessage( texte);
  }
}

/*
 * ----------------------------------------------------------------------------------------------
 *				estion d'erreurs Lexicales
 * ----------------------------------------------------------------------------------------------
 */

void LEXerreur(int no_erreur)
/*
	Procedure d'affichage des messages standarts d'erreurs pendant
	la phase d'analyse lexicale.
*/
{
  char	texte[80];

  sprintf(texte,"Lexical error at line %ld, %s", Lexline,Mess_Lex[no_erreur]);
  
  EcrireMessage("");
  EcrireMessage( texte);
}
