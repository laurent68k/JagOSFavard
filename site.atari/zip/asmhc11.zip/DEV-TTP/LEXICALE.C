/*
 * ----------------------------------------------------------------------------------------------
 *		Programme d'analyse lexicale pour langage d'assemblage MOTOROLA.
 *
 *
 * 	Auteur  : 	FAVARD Laurent
 *	Fichier	: 	LEXICALE.C
 *	Pays   	: 	FRANCE
 *	Date   	: 	18 Mars 1994
 *	Revision: 	19 November 1996
 *	Version : 	1.0
 *	Release : 	2.0
 *	Machine : 	ATARI Falcon030 TOS 4.2
 * ----------------------------------------------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>

#include "assemble.h"					/* D�finitions globales */
#include "erreur.h"
#include "codeur.h"
			  
/* 
 * ----------------------------------------------------------------------------------------------
 *			Les terminaux propres du langage d'assemblages 
 * ----------------------------------------------------------------------------------------------
 */

static char ListeDirective[11][10]={"EQU","ORG","END","DC.B","DS.B","TEXT",
                                    "DATA","OPT","DC.W","DS.W",""};

static char ListeParamDirective[3][10]={PROCESSOR_6805, PROCESSOR_68HC11, ""};

/* 
 * ----------------------------------------------------------------------------------------------
 *			Les terminaux simples du langages 
 * ----------------------------------------------------------------------------------------------
 */

static char Terminal[10]=",#%$_:\0";	

/*
 * ----------------------------------------------------------------------------------------------
 *		Variables globales pour faire communiquer l'analyseur lexicale
 *		avec l'analyseur syntaxique.
 * ----------------------------------------------------------------------------------------------
 */

Type_ValLex ValLex;	  			 	/* Valeur lexicale de l'unit lex  */
long	    Lexline=1;					/* ligne courante dans le fichier */

/*
 * ----------------------------------------------------------------------------------------------
 *						Divers
 * ----------------------------------------------------------------------------------------------
 */

/* True si caractere replac� dans fichier => non r�affich� */
static int Affiche=TRUE;

/*
 * ----------------------------------------------------------------------------------------------
 *					Primitives bas niveaux
 * ----------------------------------------------------------------------------------------------
 */

static char Upcase(char caractere)
{
  char retour;
  
  retour = (char)((caractere >= 'a' && caractere <= 'z') ? caractere - 'a' + 'A' : caractere);
  return(retour);
}

static int LireCar(void)
/*
	Se charge de lire un caractere en le retournant en majuscule d'office.
*/
{
  char caractere;
  
  caractere = (char)getc(fichier);
  if(Affiche && ListingScreen)					/* Autoris� d'afficher */
   fprintf(stdout,"%c",caractere);
  else								/* non, on n'affiche pas mais */
    Affiche = TRUE;						/* le prochain OUI */
  return(Upcase(caractere));
}

static int LireSimple(void)
/*
	Se charge de lire un caractere dans le fichier sans le modifier.
*/
{
  char caractere;
  
  caractere = (char)getc(fichier);
  if(Affiche && ListingScreen)					/* Autoris� d'afficher */
   fprintf(stdout,"%c",caractere);
  else								/* non, on n'affiche pas mais */
    Affiche = TRUE;						/* le prochain OUI */
  return(caractere);
}

static void UnLire(int caractere,FILE *fichier)
/*
	Se charge de restituer un caractere
*/
{
  ungetc(caractere,fichier);
  Affiche = FALSE;		/* Ne pas le r�afficher */
}

static void LireCh(unsigned long *valeur)
/*
	Se charge de lire une valeur num�rique d�cimale
	(Est appel� apr�s avoir lu un caract�re qui a �t� restitu�
	au fichier)
*/
{
  fscanf(fichier,"%ld",valeur);
  fprintf(stdout,"\033D");					/* curseur -1 � gauche */
  if(ListingScreen)
    fprintf(stdout,"%ld",*valeur);				/* vers l'�cran */
  Affiche = TRUE;						/* r�autoris� */
}

static int EstChiffre(char caractere)	  
/*
	retourne TRUE si caractere repr�sente un chiffre d�cimal.
*/
{
  int retour;
  
  retour = (caractere >= '0' && caractere <= '9') ? TRUE : FALSE;
  return(retour);
}

static int EstHexDigit(char caractere)
/*
	retourne TRUE si caractere repr�sente un chiffre hexad�cimal.
*/
{
  int retour;
  
  retour = (caractere >= '0' && caractere <= '9') ||
  	   (caractere >= 'A' && caractere <= 'F') ? TRUE : FALSE;
  return(retour);
}

static int EstCaractere(char caractere)
/*
	retourne TRUE si caractere repr�sente un caractere alphab�tique
	tel que: [a-zA-Z]
*/
{
  int min, maj;
  
  min = (caractere >= 'a' && caractere <= 'z') ? TRUE : FALSE;
  maj = (caractere >= 'A' && caractere <= 'Z') ? TRUE : FALSE;
  
  return( min | maj );
}

static int EstTerminal(char caractere)
/*
	retourne TRUE si caractere repr�sente un terminal simple d�fini
	dans la liste des terminaux simples 'terminal'.
*/
{
  int indice=0;
  
  while(Terminal[indice]!='\0' && Terminal[indice]!=caractere)
    indice++;
  return((Terminal[indice]!='\0') | (EstCaractere(caractere)));    
}  	

static int EstIDAlpha(char caractere)
/*
	retourne TRUE si caractere repr�sente un caractere autoris� pour
	l'�criture des identificateurs.
*/

{
  if( EstCaractere(caractere) || EstChiffre(caractere) || caractere =='_' || caractere =='.')
    return(TRUE);
  else
    return(FALSE);
}

static int EstSeparateur(char caractere)
/*
	retourne TRUE si caractere est un s�parateur de texte, blanc ou
	tabulation.
*/
{
  int retour;
  
  retour = (caractere == ' ' || caractere == '\t' || caractere == (char)EOF) ? TRUE : FALSE;
  return(retour);
}

static int EstNewline(char caractere)
/*
	retourne TRUE si caractere est un code de fin de ligne.
*/
{
  int retour;
  
  retour = (caractere == '\n' || caractere == '\r') ? TRUE : FALSE;
  return(retour);
}

static int IDreconstruir(char *ident)
/*
	reconstruit un identificateur � partir du flot d'entr�e.
	retourne TRUE si reconnue sans erreur d'�criture syntaxique et
	longueur <= � la longueur max. autoris�e TAILLEID.
*/
{
  char caractere;
  int  indice=0;
  
  caractere = (char)LireCar();
  if(EstCaractere(caractere))					/* Premier caractere */
    ident[indice++] = caractere;				/* doit etre alphabetique */
  else
    return(FALSE);

  caractere = (char)LireCar();					/* (Lettre|Chiffre|_)* */
  while(EstIDAlpha(caractere) && indice < TAILLE_ID)
  {
    ident[indice++] = caractere;
    caractere = (char) LireCar();
  }
  ident[indice++] = '\0';
  
  if( !EstIDAlpha(caractere) )
  {
    UnLire(caractere,fichier);
    return(TRUE);
  }
  else
    return(FALSE);
}

static int HEXreconstruir(unsigned long *numerique)
/*
	reconstruit une valeur numerique � partir du flot d'entr�e sous 
	forme hexad�cimale.
	retourne TRUE si reconnue sans erreur, syntaxe correcte et limit�
	� 16 bits.
*/
{
  char caractere;
  char chaine[8];
  int  indice = 0;
  unsigned char digit;

  
  chaine[indice++]='0';
  chaine[indice++]='x';

  caractere = (char)LireCar();
  digit=0;
  while(EstHexDigit(caractere) && digit <= TAILLE4OCTETS)
  {
    chaine[indice++] = caractere;
    digit++;
    caractere = (char)LireCar();
  }
  chaine[indice++] = '\0';

  if(digit <= TAILLE4OCTETS)  
  {
    UnLire(caractere,fichier);
    sscanf(chaine,"%lX",numerique); 
    return(TRUE);
  }
  else
    return(FALSE);
}

static int BINreconstruir(unsigned long *numerique)
/*
	reconstruit une valeur numerique � partir du flot d'entr�e sous 
	forme binaire.
	retourne TRUE si reconnue sans erreur, syntaxe correcte et limit�
	� 16 bits.
*/
{
  char caractere;
  unsigned char digit;
  

  caractere = (char)LireCar();
  digit	     = 0;
  *numerique = 0;
  while((caractere == '1' || caractere == '0') && digit <= TAILLE16BITS)
  {
    if(caractere == '1')
      *numerique = (*numerique << 1) | 1;
    else
      *numerique = (*numerique << 1);
      
    digit++;
    caractere = (char)LireCar();
  }
  
  if(digit <= TAILLE16BITS)  
  {
    UnLire(caractere,fichier);
    return(TRUE);
  }
  else
    return(FALSE);
}

/*
 * ----------------------------------------------------------------------------------------------
 * 				Primitives plus haut niveaux
 * ----------------------------------------------------------------------------------------------
 */

static int EstDirective(char *lexeme)
/*
	Retourne TRUE si le lexeme pass� est une directive du langage
*/
{
  int indice=0;
  int retour;
  
  while( strcmp(ListeDirective[indice],"")!=0  && 
         strcmp(ListeDirective[indice],lexeme)!=0 )
    indice++;
  retour = (strcmp(ListeDirective[indice],"")!=0) ? TRUE : FALSE;
  return(retour);
}

static int Directive(char *lexeme)
/*
	Retourne le code associ� � la directive dans lexeme.
*/
{
  int indice=0;
  
  while( strcmp(ListeDirective[indice],"")!=0  && 
         strcmp(ListeDirective[indice],lexeme)!=0 )
    indice++;
  return(indice+EQU);
}

static int ParamDirective(char *lexeme)
/*
	Retourne True si est un param�tre de directive.
	utilis� pour reconnaitre le param�tre de OPT pour MC68HC11, MC6805, etc...
*/
{
  int indice=0;
  
  while( strcmp(ListeParamDirective[indice], "")!=0  && 
         strcmp(ListeParamDirective[indice], lexeme)!=0 )
    indice++;

  return (strcmp(ListeParamDirective[indice], lexeme) == 0 ? TRUE : FALSE);
}

static int ValTerminal(char caractere)
/*
*/
{
  int indice=0;
  
  while(Terminal[indice] != '\0' && Terminal[indice] != caractere)
    indice++;
  return(indice+VIRG);    
}  	


/*
 * ----------------------------------------------------------------------------------------------
 *					Analyseur lexical lui meme
 * ----------------------------------------------------------------------------------------------
 */

int AnalyseLex(void)
{
  char		caractere;
  int		correct;
  unsigned long	numeriquelong;
  int		compte_char;

  while(TRUE)
  {
    caractere = (char)LireCar();

    if(caractere == (char)EOF)					/* Fin de fichier */
    {
      return(FDF);
    }       
    else if(EstSeparateur(caractere))				/* separateurs blancs+EOF */
    {
    }
    else if(EstNewline(caractere))				/* code nouvelle ligne */
    {
      Lexline++;
      return(FDL);
    }
    else if(caractere == ';' || caractere == '*')		/* Commentaires */
    {								/* Ignorer jusqu'� fin */
      caractere = (char)LireCar();					/* de ligne */
      while(!EstNewline(caractere) && caractere!=(char)EOF)
        caractere = (char)LireCar();
      Lexline++;						/* incr�mente compteur */
      if(caractere == (char)EOF)
        return(FDF);
      else
        return(FDL);
    }
    else if(caractere == '\'')					/* Character specified as: lda #'A' */
    {
      ValLex.numerique = (int)LireCar();;			/* Considere comme un nombre */
      caractere = (char)LireCar();					/* Lire le <'> de fin */
      if(caractere != '\'')
      {
        LEXerreur(ERR_CHAR);
        return(LEXERREUR);
      }
      return(NB);
    }
    else if( EstChiffre(caractere) )				/* Chiffre d�cimal */
    {		
      UnLire(caractere,fichier);
      LireCh(&numeriquelong);
      if(numeriquelong > (unsigned int)0xFFFF)			/* Limit� � 16 bits ? */
      {
        LEXerreur(ERR_DEC);
        return(LEXERREUR);
      }
      else
      {
        ValLex.numerique = (int)numeriquelong;
        return(NB);
      }
    }
    else if( caractere == '$' )					/* Chiffre hexad�cimal */
    {
      correct = HEXreconstruir(&ValLex.numerique);
      if(correct)
        return(NB);
      else
      {
        LEXerreur(ERR_HEX);
        return(LEXERREUR);
      }
    }
   else if( caractere == '%' )					/* Chiffre binaire */
    {
      correct = BINreconstruir(&ValLex.numerique);
      if(correct)
        return(NB);
      else
      {
        LEXerreur(ERR_BIN);
        return(LEXERREUR);
      }
    }
    else if( caractere == '"' )					/* Debut chaine texte */
    {
      caractere = (char)LireSimple();					/* Lire un caract�re brut */
      compte_char = 0;						/* Indice initial */
      while( caractere != '"' && compte_char < TAILLE_STRING )
      {
        ValLex.lexeme[compte_char] = caractere;			/* Le stocker dans la chaine */
        caractere = (char)LireSimple();				/* Next char */
        compte_char++;
      }
      ValLex.lexeme[compte_char] = '\0';
        
      if( compte_char >= TAILLE_STRING )
      {
        LEXerreur(ERR_LENSTRING);
        return(LEXERREUR);
      }
      else if( caractere != '"' )
      {
        LEXerreur(ERR_NODQUOTE);
        return(LEXERREUR);
      }
      else
      {
        return(STRING);
      }
    }
    else if( EstCaractere(caractere) )				/* Identificateur  */
    {
      UnLire(caractere,fichier);
      correct = IDreconstruir(ValLex.lexeme);			/* Reconstruit l'ID */
      if(correct)				
      {
        if(EstDirective(ValLex.lexeme))				/* directive langage */
          return(Directive(ValLex.lexeme));
        else if(ParamDirective(ValLex.lexeme))			/* param�tre de directive */
          return(PARAMDIRECTIVE);
        else if(EstInst(ValLex.lexeme))				/* instruction machine */
          return(INST);
        else							/* indentificateur */
          return(ID);    
      }
      else					
      {
        LEXerreur(ERR_ID);
        return(LEXERREUR);
      }
    }
    else if( EstTerminal(caractere) )				/* terminals du langage */
    {
      ValLex.lexeme[0] = caractere;
      ValLex.lexeme[1] = '\0';					/* Pour permettre un '%s' */
      return(ValTerminal(caractere));
    }
    else 							/* lexeme inconnue */
    {
      LEXerreur(ERR_UNKNOW);
      return(LEXERREUR);
    }
  }
}