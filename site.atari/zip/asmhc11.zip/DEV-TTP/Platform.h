/*
 * ----------------------------------------------------------------------------------------------
 *			Fichier gestion des plate-formes pour l'assembleur.
 *
 * 	Auteur 	: 	FAVARD Laurent
 *	Fichier	:	PLATFORM.H
 *	Pays   	: 	FRANCE
 *	Date   	: 	19 October 1996
 *	Revision: 	19 October 1996
 *	Version : 	1.0
 *	Machine : 	ATARI Falcon030 TOS 4.2
 * ---------------------------------------------------------------------------------------------- 
 */

#ifndef __PLATFORM__
#define __PLATFORM__	__PLATFORM__

/*
 *	Ici mettre la macro __ATARI__ ou __PC__ pour compiler sur la machine d�sir�e.
 */
 
#define	__ATARI__	__ATARI__
/*#define	__PC__	__PC__*/

/*
 * ---------------------------------------------------------------------------------------------- 
 *					Pour Borland PURE-C (Atari)
 * ---------------------------------------------------------------------------------------------- 
 */
 
#ifdef	__ATARI__

#include <tos.h>

#define	WAIT			Crawcin()
#define TAILLETBLSYMBOLE 	4096
#endif

/*
 * ---------------------------------------------------------------------------------------------- 
 *					Pour BORLAND C++ Builder (PC)
 * ---------------------------------------------------------------------------------------------- 
 */

#ifdef	__PC__

#include	<conio.h>
#include	<io.h>

#define	WAIT			getch()
#define TAILLETBLSYMBOLE 	2048

#endif
 
/*
 * ---------------------------------------------------------------------------------------------- 
 */

#endif
