/* Resource Datei Indizes f�r WMDEMO_F */

#define MAINMENU 0   /* Menuebaum */
#define ABOUT    10  /* STRING in Baum MAINMENU */
#define OPEN     19  /* STRING in Baum MAINMENU */
#define SAVE     20  /* STRING in Baum MAINMENU */
#define QUITTER  22  /* STRING in Baum MAINMENU */
#define OPENW2   24  /* STRING in Baum MAINMENU */
#define OPENM2   25  /* STRING in Baum MAINMENU */
#define ATARI    27  /* STRING in Baum MAINMENU */
#define AMIGA    28  /* STRING in Baum MAINMENU */
#define APPLE    29  /* STRING in Baum MAINMENU */
#define NEXT     30  /* STRING in Baum MAINMENU */
#define UNIX     31  /* STRING in Baum MAINMENU */
#define INSTALL  33  /* STRING in Baum MAINMENU */
