/* Resource Datei Indizes f�r MOUSDEMF */

#define MAINMENU 0   /* Menuebaum */
#define ABOUT    8   /* STRING in Baum MAINMENU */
#define QUITTER  17  /* STRING in Baum MAINMENU */
#define NEXT     19  /* STRING in Baum MAINMENU */
#define PREVIOUS 20  /* STRING in Baum MAINMENU */

#define FMAIN    1   /* Formular/Dialog */
#define OK       2   /* BUTTON in Baum FMAIN */
#define BNEXT    6   /* BUTTON in Baum FMAIN */
#define BPREVIOUS 7   /* BUTTON in Baum FMAIN */

#define APPICON  2   /* Formular/Dialog */

#define W1ICON   3   /* Formular/Dialog */
