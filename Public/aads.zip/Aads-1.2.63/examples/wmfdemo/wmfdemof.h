/* Resource Datei Indizes f�r WMFDEMOF */

#define MAINMENU 0   /* Menuebaum */
#define ABOUT    9   /* STRING in Baum MAINMENU */
#define QUITTER  18  /* STRING in Baum MAINMENU */
#define OPENW2   20  /* STRING in Baum MAINMENU */
#define OPENM2   21  /* STRING in Baum MAINMENU */
#define ATARI    23  /* STRING in Baum MAINMENU */
#define AMIGA    24  /* STRING in Baum MAINMENU */
#define APPLE    26  /* STRING in Baum MAINMENU */
#define NEXT     27  /* STRING in Baum MAINMENU */
#define UNIX     29  /* STRING in Baum MAINMENU */

#define OTHERMENU 1   /* Menuebaum */
#define COMPILE  9   /* STRING in Baum OTHERMENU */
#define ENDE     18  /* STRING in Baum OTHERMENU */
#define CLOSEW2  20  /* STRING in Baum OTHERMENU */
#define CLOSEM2  21  /* STRING in Baum OTHERMENU */

#define FMAIN    2   /* Formular/Dialog */
#define OK       2   /* BUTTON in Baum FMAIN */
#define CANCEL   3   /* BUTTON in Baum FMAIN */
#define EDIT2    5   /* FBOXTEXT in Baum FMAIN */
#define EDIT1    6   /* FBOXTEXT in Baum FMAIN */
#define R1       8   /* BUTTON in Baum FMAIN */
#define R2       9   /* BUTTON in Baum FMAIN */
#define R3       10  /* BUTTON in Baum FMAIN */
#define R4       11  /* BUTTON in Baum FMAIN */

#define W2ICON   3   /* Formular/Dialog */

#define APPICON  4   /* Formular/Dialog */

#define W1ICON   5   /* Formular/Dialog */
