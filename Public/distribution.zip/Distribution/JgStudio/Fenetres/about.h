/*
 * ----------------------------------------------------------------------------------------------
 *					Fenetre a propos de l'application
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	About.h
 *	Date    : 	10 December 1996
 *	Release : 	21 Mai 1997
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *								- Copyright Atari FunShip (c) 1994-97 -
 *							- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades -
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__ABOUT_WINDOW__
#define		__ABOUT_WINDOW__		__ABOUT_WINDOW__

extern	void	AboutMe(void);

extern	int		WHInfo;

#endif
