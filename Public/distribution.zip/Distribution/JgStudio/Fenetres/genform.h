/*
 * ----------------------------------------------------------------------------------------------
 *					Fenetre barre d'outils.
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	GENFORM.H
 *	Date    : 	10 December 1996
 *	Release : 	18 August 1998
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *								- Copyright Atari FunShip (c) 1994-97 -
 *							- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades -
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__GENFORM__
#define		__GENFORM__		__GENFORM__

extern	void GenWindow( int TypeObjet );

extern	int		WHGenForm;

#endif
