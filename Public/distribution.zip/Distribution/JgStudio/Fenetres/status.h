/*
 * ----------------------------------------------------------------------------------------------
 *					
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	Status.h
 *	Date    : 	10 December 1996
 *	Release : 	09 may 2000
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *								- Copyright Atari FunShip (c) 1994-97 -
 *							- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades -
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__WStatusH
#define		__WStatusH		__WStatusH

extern	void OpenStatus(void);

extern	int		ActiveStatus;
extern	int		WHStatus;

#endif
