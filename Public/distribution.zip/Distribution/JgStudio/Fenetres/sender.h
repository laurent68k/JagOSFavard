/*
 * ----------------------------------------------------------------------------------------------
 *					Fenetre �mission fichier
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	Sender.h
 *	Date    : 	10 December 1996
 *	Release : 	21 Mai 1997
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *								- Copyright Atari FunShip (c) 1994-97 -
 *							- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades -
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__SENDER_WINDOW__
#define		__SENDER_WINDOW__		__SENDER_WINDOW__

#include	"..\modules\const.h"

extern	void 	OpenSender(TYPE_SENDER_PARAM *SenderParameters);

extern	int		WHSender;

#endif
