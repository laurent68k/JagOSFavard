/*
 * ----------------------------------------------------------------------------------------------
 *					Fenetre quitter application
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	Envr.h
 *	Date    : 	30 December 1998
 *	Release : 	30 December 1998
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *								- Copyright Atari FunShip (c) 1994-97 -
 *							- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades -
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__TRANSFER__
#define		__TRANSFER__		__TRANSFER__

extern	void Envr( void );

#endif
