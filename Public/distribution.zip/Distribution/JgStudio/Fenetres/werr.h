/*
 * ----------------------------------------------------------------------------------------------
 *					Fenetre a propos de l'application
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	About.h
 *	Date    : 	26 April 2000
 *	Release : 	26 April 2000
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *								- Copyright Atari FunShip (c) 1994-97 -
 *							- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades -
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__WerrH
#define		__WerrH		

extern	void WError( int ErrorCode, char *Message );
extern	int		WHInfo;

#endif
