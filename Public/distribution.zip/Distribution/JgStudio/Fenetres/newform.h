/*
 * ----------------------------------------------------------------------------------------------
 *					Fenetre barre d'outils.
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	Toolsbar.h
 *	Date    : 	10 December 1996
 *	Release : 	18 August 1998
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *								- Copyright Atari FunShip (c) 1994-97 -
 *							- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades -
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__NEWFORM__
#define		__NEWFORM__		__NEWFORM__

extern	void 	NewForm(void);
extern	void	CloseNew(void);
extern	int		WHNewForm;

#endif
