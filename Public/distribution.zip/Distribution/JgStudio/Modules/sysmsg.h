/*
 * ----------------------------------------------------------------------------------------------
 *					Help bubbles messages of Application
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	sysmag.h
 *	Date    : 	17 July 1998
 *	Release : 	18 July 1998
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *						- Copyright Atari FunShip (c) 1994-98 -
 *				- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades & Milan -
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__SYSMESSAGE__
#define		__SYSMESSAGE__		__SYSMESSAGE__

#define		ADDCONSOLE		100

#endif

