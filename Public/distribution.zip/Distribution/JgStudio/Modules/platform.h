/*	
 *	VERY IMPORTANT: Here we choice the Target Operating System 
 *	Uncomment the OS you want.
 */

/*#define		__MAGIC_OS__		0
#define		__NAES_OS__			1*/
#define		__TOS_OS__			2
