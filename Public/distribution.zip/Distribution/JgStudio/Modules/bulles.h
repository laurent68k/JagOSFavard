/*
 * ----------------------------------------------------------------------------------------------
 *					Help bubbles messages of Application
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	bulles.h
 *	Date    : 	17 July 1998
 *	Release : 	18 July 1998
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *						- Copyright Atari FunShip (c) 1994-98 -
 *				- Atari ST, STE, TT, Falcon, C-LAB, Medusa, Hades & Milan -
 * ----------------------------------------------------------------------------------------------
 */


#define		GetBulle(a)		a		

#define		BUBBLE1		"Quit JagStudio"
#define		BUBBLE2		"Open a Jaguar program file"
#define		BUBBLE3		"Upload datas to the Jaguar memory"
#define		BUBBLE4		"Perform a ping to the jaguar"
#define		BUBBLE5		"Run a program at any address"
#define		BUBBLE6		"Load a program and execute it"
#define		BUBBLE7		"Help ST-Guide !"
#define		BUBBLE8		"Download from Jaguar memory"
#define		BUBBLE9		"Read or write serial EEPROM"
#define		BUBBLE10	"Your JagBar !!"
#define		BUBBLE49	"Open a source file"
#define		BUBBLE50	"New source file"

#define		BUBBLE11	"your last 'chance' before to upload this one"
#define		BUBBLE12	"If you're not agree with these parameters change them before and send this file after"


#define		BUBBLE13	"This is to accept Jaguar's datas|which will saved on your disk"
#define		BUBBLE14	"This is to accept to send datas|to the Jaguar from your disk"
#define		BUBBLE15	"You can cancelled this request whithout any damnage"

#define		BUBBLE16	"I'm your friend 'Fuji'"

#define		BUBBLE17	"Desktop background template"
#define		BUBBLE18	"Desktop color"
#define		BUBBLE19	"Close it and keep all changes"
#define		BUBBLE20	"Mouse will activate the window without to clic it"
#define		BUBBLE21	"Window will be activate when the mouse"
#define		BUBBLE22	"Window will be activate at any location"
#define		BUBBLE23	"Cludes effects when open or close any window"
#define		BUBBLE24	"Clic to decremente and double clic to go to the min"
#define		BUBBLE25	"Clic to incremente and double clic to go to the max"
#define		BUBBLE26	"Customize your desktop !"

#define		BUBBLE27	"This will run at this address !"
#define		BUBBLE28	"This will download from this address"
#define		BUBBLE29	"Cancel if you're not sure"

#define		BUBBLE30	"All done !"
#define		BUBBLE31	"we'll see that more later"

#define		BUBBLE32	"The standard size of this file"
#define		BUBBLE33	"Show what is the header of this file"
#define		BUBBLE34	"It will be upload at this Jaguar address"
#define		BUBBLE35	"It will be run at this jaguar address"
#define		BUBBLE36	"Number of bytes to pass before start of code"
#define		BUBBLE37	"Lenght found into the header or|Size-Offset if it doesn't"
#define		BUBBLE38	"For JAGR & JAGL it does exist a function code"

#define		BUBBLE39	"If you want to keep these informations"

#define		BUBBLE40	"To send a message when starting"
#define		BUBBLE41	"To send a message whe terminate"
#define		BUBBLE42	"To display a icon when running"
#define		BUBBLE43	"To use another cursor when running"
#define		BUBBLE44	"Load a template"
#define		BUBBLE45	"Save these preferences"
#define		BUBBLE46	"Browse your icon CRY image"
#define		BUBBLE47	"Browse your cursor CRY image"
#define		BUBBLE48	"Start now the generation !"
#define		BUBBLE51	"Set the exchange blocks size | for the jaguar routine !"

