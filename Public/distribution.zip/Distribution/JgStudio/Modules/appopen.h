/*
 * ----------------------------------------------------------------------------------------------
 *			
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	Appopen.H
 *	Date    : 	18 July 199
 *	Release : 	18 July 1998
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *				- Copyright Atari FunShip (c) 1994-96 -
 *	 		     - ATARI ST,STE,TT, Falcon, Medusa et Hades-
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__AppopenH
#define		__AppopenH

extern	int AppOpen(void);
extern	void SaveOptions(void);
extern	void DisplayIcones( void );

#endif