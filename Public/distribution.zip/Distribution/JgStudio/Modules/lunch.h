/*
 * ----------------------------------------------------------------------------------------------
 *					Lancement des applications en parall�le de JagStudio grace a Shel_write().
 *
 * 	Author  : 	FAVARD Laurent, FunShip (c)
 *	File    : 	LUNCH.H
 *	Date    : 	19 January 1999
 *	Release : 	19 January 1999
 *	Version : 	1.0
 *	Country : 	FRANCE
 *			
 *
 *				- Copyright Atari FunShip (c) 1994-96 -
 *	 		     - ATARI ST,STE,TT, Falcon, Medusa et Hades-
 * ----------------------------------------------------------------------------------------------
 */

#ifndef		__APP_LUNCH__
#define		__APP_LUNCH__	__APP_LUNCH__

extern	int EditSource( void );
extern	int AsmSource( void );

#endif