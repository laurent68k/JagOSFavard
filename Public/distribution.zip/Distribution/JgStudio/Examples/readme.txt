Jaguar Studio: Examples
=========================


This folder contains somes examples which run under JagOS.
You need Devpac to assemble them.

* Programs:	contains only the executable file, ready to run.

* sources: the sources file of course !


================================================================
Copyright (c) JagOS and JagStudio. freewares.
France 1997-2000
================================================================

